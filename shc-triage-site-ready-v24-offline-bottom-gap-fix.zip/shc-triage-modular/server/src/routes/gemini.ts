import { Router } from "express";
import { gemini } from "../services/geminiClient";
import type { GeminiConversationMessage, GeminiGenerateRequest, GeminiPart } from "../types/gemini";

export const geminiRouter = Router();

type NativeGeminiPart = { text: string } | { inlineData: { mimeType: string; data: string } };

function normalizeParts(content: string | GeminiPart[]): NativeGeminiPart[] {
  if (typeof content === "string") return [{ text: content }];

  const parts: NativeGeminiPart[] = [];
  for (const part of content) {
    if (part.type === "text") {
      parts.push({ text: part.text });
    } else if (part.type === "inline_data") {
      parts.push({ inlineData: { mimeType: part.mimeType, data: part.data } });
    }
  }
  return parts;
}

function toGeminiContents(messages: GeminiConversationMessage[]) {
  return messages.map((message) => ({
    role: message.role === "model" ? "model" : "user",
    parts: normalizeParts(message.content),
  }));
}

function extractText(response: any): string {
  if (typeof response?.text === "string") return response.text.trim();

  const parts = response?.candidates?.[0]?.content?.parts ?? [];
  return parts
    .map((part: any) => (typeof part?.text === "string" ? part.text : ""))
    .join("")
    .trim();
}

function getFinishReason(response: any): string | undefined {
  return response?.candidates?.[0]?.finishReason;
}

geminiRouter.post("/generate", async (req, res, next) => {
  try {
    const body = req.body as GeminiGenerateRequest;

    if (!Array.isArray(body.messages)) {
      res.status(400).json({ error: "messages must be an array" });
      return;
    }

    const mode = body.mode || "free_text";
    const model = body.model || process.env.GEMINI_MODEL || "gemini-2.5-flash";

    const config: any = {
      systemInstruction: body.systemInstruction || "",
      temperature: body.temperature ?? (mode === "triage_extraction" ? 0 : 0.2),
      maxOutputTokens: body.maxOutputTokens ?? (mode === "document_summary" ? 1200 : 1600),
    };

    // Google-native structured output. No Anthropic translation layer and no server-side fake fallback.
    // The original SHC client remains responsible for parsing the JSON and falling back to offline mode
    // only on real API failures.
    if (mode === "triage_extraction") {
      config.responseMimeType = "application/json";
    }

    const response = await gemini.models.generateContent({
      model,
      contents: toGeminiContents(body.messages),
      config,
    });

    const usage = (response as any)?.usageMetadata;

    res.json({
      model,
      text: extractText(response),
      finishReason: getFinishReason(response),
      usage: {
        inputTokens: usage?.promptTokenCount,
        outputTokens: usage?.candidatesTokenCount,
        totalTokens: usage?.totalTokenCount,
      },
    });
  } catch (error) {
    next(error);
  }
});
