// @ts-nocheck
export const AKINATOR_GATES = {
  tr: [
    { id:"chest",    label:"Göğüs ağrısı",          sub:"Sıkışma, baskı, yanma hissi"          },
    { id:"headache", label:"Baş ağrısı",             sub:"Zonklama, basınç, sürekli ağrı"       },
    { id:"cold",     label:"Burun, boğaz, öksürük",  sub:"Akıntı, hapşırma, ses kısıklığı"     },
    { id:"stomach",  label:"Mide ve karın",           sub:"Bulantı, şişkinlik, yanma, ishal"     },
    { id:"urinary",  label:"İdrar şikayeti",          sub:"Yanma, sık gitme, ağrı"               },
    { id:"fatigue",  label:"Yorgunluk ve halsizlik",  sub:"Bitkinlik, kilo değişimi, üşüme"     },
    { id:"backpain", label:"Sırt ve bel ağrısı",      sub:"Ağrı, uyuşma, tutulma, bacağa vurma" },
    { id:"anxiety",  label:"Kaygı ve çarpıntı",       sub:"Panik, nefes darlığı, stres"         },
    { id:"skin",     label:"Cilt ve döküntü",         sub:"Kızarıklık, kaşıntı, kabarcık"       },
    { id:"eye",      label:"Göz şikayeti",            sub:"Ağrı, kızarıklık, görme değişikliği" },
  ],
  en: [
    { id:"chest",    label:"Chest pain",              sub:"Tightness, pressure, burning"         },
    { id:"headache", label:"Headache",                sub:"Throbbing, pressure, constant ache"   },
    { id:"cold",     label:"Nose, throat, cough",     sub:"Runny nose, sneezing, hoarseness"     },
    { id:"stomach",  label:"Stomach and abdomen",     sub:"Nausea, bloating, heartburn, diarrhoea"},
    { id:"urinary",  label:"Urinary complaint",       sub:"Burning, frequent urge, pain"         },
    { id:"fatigue",  label:"Fatigue and weakness",    sub:"Exhaustion, weight change, cold sensitivity"},
    { id:"backpain", label:"Back and lower back",     sub:"Pain, numbness, stiffness, leg radiation"},
    { id:"anxiety",  label:"Anxiety and palpitations",sub:"Panic, breathlessness, stress"        },
    { id:"skin",     label:"Skin and rash",           sub:"Redness, itching, blisters"           },
    { id:"eye",      label:"Eye complaint",           sub:"Pain, redness, vision change"         },
  ],
};

// Tüm dal soruları — her dal 10-12 soru, derin ayrım
export const AKINATOR_QUESTIONS = [

  // ══ GÖĞÜS DALI ══
  // ACS vs GERD vs Anksiyete ayrımı
  { id:"chest_scale",    ask_if:"chest",   type:"scale", weight:3,
    text_tr:"Şu anki göğüs ağrısını 1'den 10'a değerlendirin.",
    text_en:"Rate the chest pain you feel right now from 1 to 10.",
    scale_trigger:"chest_pain", scale_high_triggers:["chest_pressure","chest_tightness"] },
  { id:"chest_arm",      ask_if:"chest",   type:"yn",    weight:5,
    text_tr:"Sol kolunuzda, omzunuzda ya da çenenizde ağrı veya uyuşma var mı?",
    text_en:"Do you have pain or numbness in your left arm, shoulder or jaw?",
    triggers_yes:["left_arm_pain","jaw_pain","shoulder_pain"] },
  { id:"chest_sweat",    ask_if:"chest",   type:"yn",    weight:4,
    text_tr:"Soğuk terleme oluyor mu?",
    text_en:"Are you breaking out in a cold sweat?",
    triggers_yes:["diaphoresis","cold_sweat"] },
  { id:"chest_breath",   ask_if:"chest",   type:"yn",    weight:3,
    text_tr:"Nefes almak zorlaşıyor mu?",
    text_en:"Is breathing becoming difficult?",
    triggers_yes:["shortness_of_breath"] },
  { id:"chest_nausea",   ask_if:"chest",   type:"yn",    weight:3,
    text_tr:"Bulantı veya kusma var mı?",
    text_en:"Do you feel nauseous or are you vomiting?",
    triggers_yes:["nausea","vomiting"] },
  { id:"chest_burn",     ask_if:"chest",   type:"yn",    weight:3,
    text_tr:"Yemekten sonra veya yatınca daha mı kötü oluyor?",
    text_en:"Does it get worse after eating or when lying down?",
    triggers_yes:["heartburn","acid_reflux","worse_lying_down","worse_after_eating"] },
  { id:"chest_exertion", ask_if:"chest",   type:"yn",    weight:4,
    text_tr:"Eforla — yürüyünce veya merdiven çıkınca — ağrı artıyor mu?",
    text_en:"Does the pain increase with exertion — walking or climbing stairs?",
    triggers_yes:["chest_pain","chest_tightness"] },
  { id:"chest_rest",     ask_if:"chest",   type:"yn",    weight:3, depends_on:"chest_exertion",
    text_tr:"Dinlenince ağrı geçiyor mu?",
    text_en:"Does resting ease the pain?",
    triggers_yes:["chest_pressure"] },
  { id:"chest_duration", ask_if:"chest",   type:"yn",    weight:3, depends_on:"chest_arm",
    text_tr:"Ağrı 20 dakikadan uzun sürüyor mu?",
    text_en:"Has the pain lasted more than 20 minutes?",
    triggers_yes:["chest_pain"] },
  { id:"chest_acid",     ask_if:"chest",   type:"yn",    weight:3, depends_on:"chest_burn",
    text_tr:"Ağız içine ekşi veya acı bir tat geliyor mu?",
    text_en:"Do you get a sour or bitter taste in your mouth?",
    triggers_yes:["acid_reflux","regurgitation","sour_taste"] },
  { id:"chest_palpitat", ask_if:"chest",   type:"yn",    weight:3,
    text_tr:"Kalp çarpıntısı, düzensiz kalp atışı veya panik hissi var mı?",
    text_en:"Do you also have palpitations, irregular heartbeat or a sense of panic?",
    triggers_yes:["palpitations","racing_heart","irregular_heartbeat","panic_attacks","fear","excessive_worry"] },
  { id:"chest_back",     ask_if:"chest",   type:"yn",    weight:4, depends_on:"chest_arm",
    text_tr:"Ağrı sırta veya omuzlara yayılıyor mu?",
    text_en:"Does the pain radiate to your back or shoulders?",
    triggers_yes:["back_pain","shoulder_pain","pain_radiation_back"] },

  // ══ BAŞ AĞRISI DALI ══
  // İnme vs Migren vs Gerilim tipi kesin ayrım
  { id:"head_sudden",    ask_if:"headache",type:"yn",    weight:5,
    text_tr:"Ağrı saniyeler içinde, aniden mi geldi?",
    text_en:"Did the pain come on within seconds — suddenly?",
    triggers_yes:["sudden_headache"] },
  { id:"head_face",      ask_if:"headache",type:"yn",    weight:5,
    text_tr:"Yüzünüzde uyuşma, sarkma veya güçsüzlük var mı?",
    text_en:"Is there numbness, drooping or weakness in your face?",
    triggers_yes:["facial_drooping","numbness_one_side","vision_change"] },
  { id:"head_arm",       ask_if:"headache",type:"yn",    weight:5,
    text_tr:"Bir kolunuzda veya bacağınızda ani güçsüzlük var mı?",
    text_en:"Is there sudden weakness in one arm or leg?",
    triggers_yes:["arm_weakness"] },
  { id:"head_speech",    ask_if:"headache",type:"yn",    weight:5,
    text_tr:"Konuşmanızda bozulma veya kelime bulmakta güçlük var mı?",
    text_en:"Is your speech slurred or are you struggling to find words?",
    triggers_yes:["speech_difficulty"] },
  { id:"head_scale",     ask_if:"headache",type:"scale", weight:3,
    text_tr:"Ağrının şiddetini 1'den 10'a değerlendirin.",
    text_en:"Rate the headache intensity from 1 to 10.",
    scale_trigger:"severe_headache", scale_high_triggers:["throbbing_headache"] },
  { id:"head_side",      ask_if:"headache",type:"yn",    weight:4,
    text_tr:"Ağrı kafanızın sadece bir tarafında mı?",
    text_en:"Is the pain on just one side of your head?",
    triggers_yes:["one_sided_headache"] },
  { id:"head_light",     ask_if:"headache",type:"yn",    weight:4,
    text_tr:"Işık veya ses sizi rahatsız ediyor mu?",
    text_en:"Does light or noise bother you?",
    triggers_yes:["light_sensitivity","sound_sensitivity"] },
  { id:"head_nausea",    ask_if:"headache",type:"yn",    weight:3,
    text_tr:"Bulantı veya kusma var mı?",
    text_en:"Is there nausea or vomiting?",
    triggers_yes:["nausea","vomiting"] },
  { id:"head_throbbing", ask_if:"headache",type:"yn",    weight:3, depends_on:"head_side",
    text_tr:"Ağrı nabız atar gibi zonkluyor mu?",
    text_en:"Does the pain throb or pulse?",
    triggers_yes:["throbbing_headache"] },
  { id:"head_aura",      ask_if:"headache",type:"yn",    weight:3, depends_on:"head_side",
    text_tr:"Ağrıdan önce gözlerinizde parlama, karartı veya çizgiler görüyor muydunuz?",
    text_en:"Before the pain, did you see flashing lights, blind spots or zigzag lines?",
    triggers_yes:["aura","visual_disturbance"] },
  { id:"head_pressure",  ask_if:"headache",type:"yn",    weight:3,
    text_tr:"Ağrı zonklamak yerine kafanızı saran bir baskı veya kuşak gibi mi hissettiriyor?",
    text_en:"Does it feel like pressure or a tight band squeezing your head rather than throbbing?",
    triggers_yes:["bilateral_headache","pressure_headache","band_around_head","neck_muscle_tension","stress_related"] },
  { id:"head_worse_act", ask_if:"headache",type:"yn",    weight:2, depends_on:"head_nausea",
    text_tr:"Hareket edince veya fiziksel aktiviteyle ağrı artıyor mu?",
    text_en:"Does physical activity or movement make the headache worse?",
    triggers_yes:["severe_headache","worsens_with_activity"] },

  // ══ BURUN / BOĞAZ / ÖKSÜRÜK DALI ══
  // Grip vs Soğuk algınlığı vs Pnömoni ayrımı
  { id:"cold_runny",     ask_if:"cold",    type:"yn",    weight:2,
    text_tr:"Burun akıntısı veya burun tıkanıklığı var mı?",
    text_en:"Do you have a runny or blocked nose?",
    triggers_yes:["runny_nose"] },
  { id:"cold_fever",     ask_if:"cold",    type:"yn",    weight:4,
    text_tr:"Ateşiniz var mı?",
    text_en:"Do you have a fever?",
    triggers_yes:["fever"] },
  { id:"cold_body",      ask_if:"cold",    type:"yn",    weight:4,
    text_tr:"Tüm vücudunuz ağrıyor mu?",
    text_en:"Is your whole body aching?",
    triggers_yes:["body_aches"] },
  { id:"cold_onset",     ask_if:"cold",    type:"yn",    weight:4,
    text_tr:"Şikayetler birkaç saat içinde aniden mi geldi?",
    text_en:"Did the symptoms come on suddenly within a few hours?",
    triggers_yes:["sudden_onset"] },
  { id:"cold_throat",    ask_if:"cold",    type:"yn",    weight:3,
    text_tr:"Boğaz ağrısı var mı?",
    text_en:"Do you have a sore throat?",
    triggers_yes:["sore_throat"] },
  { id:"cold_cough",     ask_if:"cold",    type:"yn",    weight:3,
    text_tr:"Öksürük var mı?",
    text_en:"Do you have a cough?",
    triggers_yes:["cough","dry_cough"] },
  { id:"cold_breath",    ask_if:"cold",    type:"yn",    weight:4,
    text_tr:"Nefes darlığı veya nefes alırken güçlük oluyor mu?",
    text_en:"Do you have shortness of breath or difficulty breathing?",
    triggers_yes:["shortness_of_breath","chest_tightness"] },
  { id:"cold_sputum",    ask_if:"cold",    type:"yn",    weight:3, depends_on:"cold_cough",
    text_tr:"Öksürükle balgam veya renkli sekresyon çıkıyor mu?",
    text_en:"Are you coughing up phlegm or discoloured mucus?",
    triggers_yes:["sputum_production","cough"] },
  { id:"cold_smell",     ask_if:"cold",    type:"yn",    weight:3,
    text_tr:"Koku veya tat duyunuz azaldı mı?",
    text_en:"Has your sense of smell or taste decreased?",
    triggers_yes:["loss_of_smell","loss_of_taste"] },
  { id:"cold_rigors",    ask_if:"cold",    type:"yn",    weight:3,
    text_tr:"Kontrol edemediğiniz titreme nöbetleri oluyor mu?",
    text_en:"Are you having uncontrollable shivering fits?",
    triggers_yes:["rigors","chills"] },
  { id:"cold_severity",  ask_if:"cold",    type:"scale", weight:2,
    text_tr:"Kendinizi ne kadar kötü hissediyorsunuz? 1 hafif, 10 yataktan kalkamıyorum.",
    text_en:"How unwell do you feel? 1 = mild, 10 = can't get out of bed.",
    scale_trigger:"fatigue", scale_high_triggers:["headache","body_aches","fever"] },

  // ══ MİDE / KARIN DALI ══
  // GERD vs İBS vs Ülser vs Gastroenterit ayrımı
  { id:"stom_scale",     ask_if:"stomach", type:"scale", weight:3,
    text_tr:"Karın ağrısını 1'den 10'a değerlendirin.",
    text_en:"Rate your abdominal pain from 1 to 10.",
    scale_trigger:"abdominal_pain", scale_high_triggers:["severe_abdominal_pain","cramping"] },
  { id:"stom_nausea",    ask_if:"stomach", type:"yn",    weight:3,
    text_tr:"Bulantı veya kusma var mı?",
    text_en:"Do you have nausea or vomiting?",
    triggers_yes:["nausea","vomiting"] },
  { id:"stom_diarrhea",  ask_if:"stomach", type:"yn",    weight:3,
    text_tr:"İshal var mı?",
    text_en:"Do you have diarrhoea?",
    triggers_yes:["diarrhea"] },
  { id:"stom_upper",     ask_if:"stomach", type:"yn",    weight:3,
    text_tr:"Ağrı üst karında mı — göğüs kemiğinin hemen altında mı?",
    text_en:"Is the pain in the upper abdomen — just below the breastbone?",
    triggers_yes:["epigastric_pain","burning_stomach_pain"] },
  { id:"stom_eating",    ask_if:"stomach", type:"yn",    weight:3, depends_on:"stom_upper",
    text_tr:"Yemek yince ağrı geçiyor mu?",
    text_en:"Does eating ease the pain?",
    triggers_yes:["pain_relieved_by_eating"] },
  { id:"stom_burn",      ask_if:"stomach", type:"yn",    weight:4,
    text_tr:"Göğüste yanma veya ağıza ekşi sıvı geliyor mu?",
    text_en:"Do you have a burning in your chest or acid coming up into your mouth?",
    triggers_yes:["heartburn","acid_reflux","regurgitation","chest_burning"] },
  { id:"stom_lie",       ask_if:"stomach", type:"yn",    weight:3, depends_on:"stom_burn",
    text_tr:"Yatınca veya öne eğilince şikayetler daha mı kötü oluyor?",
    text_en:"Do symptoms get worse when you lie down or bend forward?",
    triggers_yes:["worse_lying_down","worse_after_eating"] },
  { id:"stom_swallow",    ask_if:"stomach", type:"yn",    weight:2, depends_on:"stom_burn",
    text_tr:"Yutkunmakta güçlük veya yutkunurken ağrı var mı?",
    text_en:"Do you have difficulty swallowing or pain when swallowing?",
    triggers_yes:["difficulty_swallowing","sour_taste"] },
  { id:"stom_blood",     ask_if:"stomach", type:"yn",    weight:5,
    text_tr:"Dışkıda kan var mı ya da siyah, katran gibi görünüyor mu?",
    text_en:"Is there blood in your stool, or does it look black and tarry?",
    triggers_yes:["blood_in_stool","black_stool","rectal_bleeding"] },
  { id:"stom_fever",     ask_if:"stomach", type:"yn",    weight:3,
    text_tr:"Ateş var mı?",
    text_en:"Do you have a fever?",
    triggers_yes:["fever"] },
  { id:"stom_bloat",     ask_if:"stomach", type:"yn",    weight:2,
    text_tr:"Belirgin şişkinlik veya gaz şikayeti var mı?",
    text_en:"Do you have noticeable bloating or gas?",
    triggers_yes:["bloating","constipation","alternating_bowel"] },
  { id:"stom_bowel",     ask_if:"stomach", type:"yn",    weight:2, depends_on:"stom_diarrhea",
    text_tr:"Tuvalete gidince ağrı geçiyor mu?",
    text_en:"Does the pain ease after having a bowel movement?",
    triggers_yes:["pain_relieved_by_defecation","urgency"] },
  { id:"stom_hunger",    ask_if:"stomach", type:"yn",    weight:2, depends_on:"stom_upper",
    text_tr:"Ağrı aç kaldığınızda daha mı kötü oluyor?",
    text_en:"Is the pain worse when you are hungry?",
    triggers_yes:["hunger_pain","epigastric_pain"] },

  // ══ İDRAR DALI ══
  // İYE vs Piyelonefrit vs Böbrek taşı ayrımı
  { id:"uri_burn",       ask_if:"urinary", type:"yn",    weight:5,
    text_tr:"İdrar yaparken yanma veya ağrı var mı?",
    text_en:"Do you feel burning or pain when urinating?",
    triggers_yes:["painful_urination","burning_urination"] },
  { id:"uri_freq",       ask_if:"urinary", type:"yn",    weight:4,
    text_tr:"Çok sık tuvalete gidiyor musunuz, her seferinde az mı çıkıyor?",
    text_en:"Are you going very often with little urine each time?",
    triggers_yes:["frequent_urination","urgency"] },
  { id:"uri_appear",     ask_if:"urinary", type:"yn",    weight:4,
    text_tr:"İdrar bulanık, kötü kokulu veya kanlı mı?",
    text_en:"Is the urine cloudy, foul-smelling or bloody?",
    triggers_yes:["cloudy_urine","strong_urine_smell","blood_in_urine"] },
  { id:"uri_fever",      ask_if:"urinary", type:"yn",    weight:4,
    text_tr:"Ateş var mı?",
    text_en:"Do you have a fever?",
    triggers_yes:["fever"] },
  { id:"uri_flank",      ask_if:"urinary", type:"yn",    weight:4,
    text_tr:"Yan tarafınızda veya sırt alt kısmında ağrı var mı?",
    text_en:"Do you have pain in your side or lower back?",
    triggers_yes:["flank_pain","back_pain"] },
  { id:"uri_colicky",    ask_if:"urinary", type:"yn",    weight:4, depends_on:"uri_flank",
    text_tr:"Ağrı dalgalar halinde mi geliyor — şiddetleniyor sonra hafifliyour mu?",
    text_en:"Does the pain come in waves — intensifying then easing?",
    triggers_yes:["colicky_pain","severe_flank_pain"] },
  { id:"uri_groin",      ask_if:"urinary", type:"yn",    weight:3, depends_on:"uri_flank",
    text_tr:"Ağrı kasığa veya uyluğa yayılıyor mu?",
    text_en:"Does the pain radiate to your groin or thigh?",
    triggers_yes:["pain_radiates_groin"] },
  { id:"uri_lower",      ask_if:"urinary", type:"scale", weight:2,
    text_tr:"Alt karın ağrısını 1'den 10'a değerlendirin.",
    text_en:"Rate any lower abdominal pain from 1 to 10.",
    scale_trigger:"lower_abdominal_pain", scale_high_triggers:["urgency"] },
  { id:"uri_nausea",     ask_if:"urinary", type:"yn",    weight:2,
    text_tr:"Bulantı, kusma veya titreme oluyor mu?",
    text_en:"Is there nausea, vomiting or rigors?",
    triggers_yes:["nausea","vomiting","rigors"] },

  // ══ YORGUNLUK DALI ══
  // Hipotiroid vs Anemi vs Depresyon ayrımı
  { id:"fat_scale",      ask_if:"fatigue", type:"scale", weight:3,
    text_tr:"Yorgunluğu 1'den 10'a değerlendirin. 1 hafif, 10 hiç kalkamıyorum.",
    text_en:"Rate your fatigue from 1 to 10. 1 = mild, 10 = can't get up.",
    scale_trigger:"fatigue", scale_high_triggers:["weakness"] },
  { id:"fat_cold",       ask_if:"fatigue", type:"yn",    weight:4,
    text_tr:"Herkesten daha çok üşüyor musunuz?",
    text_en:"Do you feel colder than the people around you?",
    triggers_yes:["cold_intolerance"] },
  { id:"fat_weight_gain",ask_if:"fatigue", type:"yn",    weight:4,
    text_tr:"Son birkaç ayda diyet yapmadan kilo aldınız mı?",
    text_en:"Have you gained weight recently without trying?",
    triggers_yes:["weight_gain"] },
  { id:"fat_pale",       ask_if:"fatigue", type:"yn",    weight:4,
    text_tr:"Cildiniz soluk mu, az hareketle nefes darlığı oluyor mu?",
    text_en:"Is your skin pale, or do you get breathless with little effort?",
    triggers_yes:["pale_skin","breathlessness","dizziness"] },
  { id:"fat_heart",      ask_if:"fatigue", type:"yn",    weight:3, depends_on:"fat_pale",
    text_tr:"Çarpıntı veya hızlı kalp atışı oluyor mu?",
    text_en:"Do you have palpitations or a racing heart?",
    triggers_yes:["palpitations","racing_heart"] },
  { id:"fat_sad",        ask_if:"fatigue", type:"yn",    weight:4,
    text_tr:"Sürekli üzgün, umutsuz veya hiçbir şeyden zevk alamıyor musunuz?",
    text_en:"Do you feel persistently sad, hopeless or unable to enjoy anything?",
    triggers_yes:["persistent_sadness","loss_of_interest","hopelessness"] },
  { id:"fat_sleep",      ask_if:"fatigue", type:"yn",    weight:3, depends_on:"fat_sad",
    text_tr:"Uyku bozukluğu var mı — çok az veya çok fazla uyuma?",
    text_en:"Do you have sleep disturbances — sleeping too little or too much?",
    triggers_yes:["sleep_changes","insomnia"] },
  { id:"fat_appetite",   ask_if:"fatigue", type:"yn",    weight:3, depends_on:"fat_sad",
    text_tr:"İştah değişikliği var mı — yemek istemiyor musunuz veya çok mu yiyorsunuz?",
    text_en:"Has your appetite changed significantly — eating much less or much more?",
    triggers_yes:["appetite_changes","loss_of_appetite"] },
  { id:"fat_concentrate",ask_if:"fatigue", type:"yn",    weight:2, depends_on:"fat_sad",
    text_tr:"Konsantrasyon güçlüğü veya karar vermekte zorlanma oluyor mu?",
    text_en:"Do you have difficulty concentrating or making decisions?",
    triggers_yes:["concentration_problems","memory_problems","social_withdrawal"] },
  { id:"fat_skin",       ask_if:"fatigue", type:"yn",    weight:3, depends_on:"fat_cold",
    text_tr:"Cilt kuru mu, normalden fazla saç mı dökülüyor?",
    text_en:"Is your skin dry, or are you losing more hair than usual?",
    triggers_yes:["dry_skin","hair_loss"] },
  { id:"fat_constip",    ask_if:"fatigue", type:"yn",    weight:2, depends_on:"fat_cold",
    text_tr:"Belirgin kabızlık var mı?",
    text_en:"Do you have noticeable constipation?",
    triggers_yes:["constipation"] },
  { id:"fat_voice",      ask_if:"fatigue", type:"yn",    weight:2, depends_on:"fat_cold",
    text_tr:"Sesiniz kalınlaştı mı ya da yüzünüz şiş görünüyor mu?",
    text_en:"Has your voice become deeper, or does your face look puffy?",
    triggers_yes:["hoarse_voice","puffy_face"] },
  { id:"fat_nails",      ask_if:"fatigue", type:"yn",    weight:2, depends_on:"fat_cold",
    text_tr:"Tırnaklarınız kırılgan mı veya el-ayak soğukluğu oluyor mu?",
    text_en:"Are your nails brittle, or do you have cold hands and feet?",
    triggers_yes:["brittle_nails","cold_hands"] },

  // ══ SIRT / BEL DALI ══
  // Disk fıtığı vs Cauda equina — erken yakalama
  { id:"back_scale",     ask_if:"backpain",type:"scale", weight:3,
    text_tr:"Bel ağrısını 1'den 10'a değerlendirin.",
    text_en:"Rate your back pain from 1 to 10.",
    scale_trigger:"lower_back_pain", scale_high_triggers:["stiffness"] },
  { id:"back_leg",       ask_if:"backpain",type:"yn",    weight:5,
    text_tr:"Ağrı bir bacağınıza yayılıyor mu?",
    text_en:"Does the pain spread down into one leg?",
    triggers_yes:["leg_pain","sciatica","pain_radiates_leg"] },
  { id:"back_numb",      ask_if:"backpain",type:"yn",    weight:5, depends_on:"back_leg",
    text_tr:"Bacakta uyuşma veya karıncalanma var mı?",
    text_en:"Do you have numbness or tingling in your leg?",
    triggers_yes:["numbness_leg","tingling_leg","weakness_leg"] },
  { id:"back_bladder",   ask_if:"backpain",type:"yn",    weight:6,
    text_tr:"İdrar yapmakta güçlük ya da idrarı tutamama oluyor mu?",
    text_en:"Are you having trouble urinating or losing bladder control?",
    triggers_yes:["urinary_retention","bladder_dysfunction"] },
  { id:"back_saddle",    ask_if:"backpain",type:"yn",    weight:6, depends_on:"back_bladder",
    text_tr:"Kasık, iç bacaklar veya kalça bölgesinde uyuşma var mı?",
    text_en:"Do you have numbness in the groin, inner thighs or buttocks?",
    triggers_yes:["saddle_anesthesia"] },
  { id:"back_bowel",     ask_if:"backpain",type:"yn",    weight:5, depends_on:"back_bladder",
    text_tr:"Dışkılamayı kontrol etmekte güçlük var mı?",
    text_en:"Are you having difficulty controlling your bowels?",
    triggers_yes:["bowel_dysfunction","saddle_anesthesia"] },
  { id:"back_both_legs", ask_if:"backpain",type:"yn",    weight:4, depends_on:"back_leg",
    text_tr:"Her iki bacakta da güçsüzlük veya uyuşma var mı?",
    text_en:"Do you have weakness or numbness in both legs?",
    triggers_yes:["bilateral_leg_weakness","numbness_leg"] },
  { id:"back_sit",       ask_if:"backpain",type:"yn",    weight:3, depends_on:"back_leg",
    text_tr:"Oturunca ağrı daha mı kötü oluyor?",
    text_en:"Does sitting make the pain worse?",
    triggers_yes:["worse_sitting"] },
  { id:"back_worse_morn",ask_if:"backpain",type:"yn",    weight:2,
    text_tr:"Sabah kalktığınızda ağrı daha mı şiddetli oluyor?",
    text_en:"Is the pain worse when you first get up in the morning?",
    triggers_yes:["lower_back_pain","stiffness"] },
  { id:"back_duration",  ask_if:"backpain",type:"yn",    weight:2,
    text_tr:"Bu ağrı 6 haftadan uzun süredir devam ediyor mu?",
    text_en:"Has this pain been going on for more than 6 weeks?",
    triggers_yes:["lower_back_pain"] },

  // ══ KAYGI / ÇARPINTI DALI ══
  // Panik bozukluğu vs GAD vs AFib ayrımı
  { id:"anx_chest_pain", ask_if:"anxiety", type:"yn",    weight:5,
    text_tr:"Göğüste ağrı, baskı veya sıkışma hissediyor musunuz?",
    text_en:"Do you have any chest pain, pressure or tightness?",
    triggers_yes:["chest_pain","chest_pressure","chest_tightness"] },
  { id:"anx_palp",       ask_if:"anxiety", type:"yn",    weight:4,
    text_tr:"Kalp çarpıntısı veya hızlı kalp atışı hissediyor musunuz?",
    text_en:"Do you feel your heart pounding or racing?",
    triggers_yes:["racing_heart","palpitations"] },
  { id:"anx_irregular",  ask_if:"anxiety", type:"yn",    weight:4,
    text_tr:"Kalp atışınız düzensiz mi — zaman zaman atlıyor gibi mi?",
    text_en:"Does your heart feel irregular — like it skips beats sometimes?",
    triggers_yes:["irregular_heartbeat","palpitations"] },
  { id:"anx_breath",     ask_if:"anxiety", type:"yn",    weight:4,
    text_tr:"Nefes darlığı veya boğuluyormuş gibi his var mı?",
    text_en:"Do you feel short of breath or like you can't get enough air?",
    triggers_yes:["shortness_of_breath","chest_tightness"] },
  { id:"anx_panic",      ask_if:"anxiety", type:"yn",    weight:4,
    text_tr:"Aniden gelen yoğun korku veya panik atakları oluyor mu?",
    text_en:"Do you have sudden intense fear or panic attacks?",
    triggers_yes:["panic_attacks","fear"] },
  { id:"anx_worry",      ask_if:"anxiety", type:"yn",    weight:3,
    text_tr:"Durduramadığınız, günlük hayatı etkileyen aşırı endişe var mı?",
    text_en:"Do you have uncontrollable worry that affects daily life?",
    triggers_yes:["excessive_worry","muscle_tension"] },
  { id:"anx_scale",      ask_if:"anxiety", type:"scale", weight:3, depends_on:"anx_worry",
    text_tr:"Kaygı veya gerginliğini 1'den 10'a değerlendirin.",
    text_en:"Rate your anxiety or tension from 1 to 10.",
    scale_trigger:"excessive_worry", scale_high_triggers:["panic_attacks","muscle_tension"] },
  { id:"anx_dizziness",  ask_if:"anxiety", type:"yn",    weight:3, depends_on:"anx_palp",
    text_tr:"Baş dönmesi veya bayılacakmış gibi his oluyor mu?",
    text_en:"Do you feel dizzy or like you might faint?",
    triggers_yes:["dizziness"] },
  { id:"anx_physical",   ask_if:"anxiety", type:"yn",    weight:2, depends_on:"anx_panic",
    text_tr:"Titreme, terleme veya bulantı gibi fiziksel belirtiler var mı?",
    text_en:"Do you have physical symptoms like trembling, sweating or nausea?",
    triggers_yes:["trembling","sweating","nausea"] },
  { id:"anx_avoidance",  ask_if:"anxiety", type:"yn",    weight:3, depends_on:"anx_worry",
    text_tr:"Belirli yerlere veya durumlardan kaçınıyor musunuz — toplu taşıma, kalabalık gibi?",
    text_en:"Do you avoid certain places or situations — like public transport or crowds?",
    triggers_yes:["avoidance","excessive_worry","fear"] },
  { id:"anx_exertion",   ask_if:"anxiety", type:"yn",    weight:3, depends_on:"anx_chest_pain",
    text_tr:"Bu belirtiler efor sırasında — yürüyünce — daha mı kötü oluyor?",
    text_en:"Do these symptoms get worse with physical effort — like walking?",
    triggers_yes:["reduced_exercise","shortness_of_breath"] },

  // ══ SÜRE (tüm kapılar) ══
  { id:"dur_chest", ask_if:"chest", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_headache", ask_if:"headache", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset","sudden_headache"] },
  { id:"dur_cold", ask_if:"cold", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_stomach", ask_if:"stomach", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_urinary", ask_if:"urinary", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_fatigue", ask_if:"fatigue", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_backpain", ask_if:"backpain", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_anxiety", ask_if:"anxiety", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_skin", ask_if:"skin", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_eye", ask_if:"eye", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },

  // ══ CİLT / DÖKÜNTÜ DALI ══
  { id:"skin_spread", ask_if:"skin", type:"yn", weight:5,
    text_tr:"Ciltte yayılan ve dokununca sıcak hissedilen bir kızarıklık var mı?",
    text_en:"Is there spreading redness that feels warm to the touch?",
    triggers_yes:["spreading_redness","warm_skin"] },
  { id:"skin_fever", ask_if:"skin", type:"yn", weight:5,
    text_tr:"Ateşiniz ya da titremeniz var mı?",
    text_en:"Do you have fever or chills?",
    triggers_yes:["fever","chills"] },
  { id:"skin_streak", ask_if:"skin", type:"yn", weight:6, depends_on:"skin_spread",
    text_tr:"Kızarıklıktan vücuda doğru çizgi halinde kırmızı hatlar ilerliyor mu?",
    text_en:"Are red streaks spreading from the area toward the body?",
    triggers_yes:["red_streaks"] },
  { id:"skin_hives", ask_if:"skin", type:"yn", weight:4,
    text_tr:"Kaşıntılı, kabarık döküntüler (kurdeşen) var mı?",
    text_en:"Do you have itchy, raised welts (hives)?",
    triggers_yes:["itchy_welts","hives"] },
  { id:"skin_expose", ask_if:"skin", type:"yn", weight:3,
    text_tr:"Yeni bir ürün, yiyecek, ilaç ya da böcek temasından sonra mı başladı?",
    text_en:"Did it start after a new product, food, medication, or insect contact?",
    triggers_yes:["rash_after_exposure"] },
  { id:"skin_swellface", ask_if:"skin", type:"yn", weight:6,
    text_tr:"Dudak veya dilde şişme ya da boğazda daralma hissi var mı?",
    text_en:"Any swelling of the lips or tongue, or tightness in the throat?",
    triggers_yes:["lip_face_swelling","throat_tightness"] },
  { id:"skin_band", ask_if:"skin", type:"yn", weight:5,
    text_tr:"Vücudun tek tarafında bant şeklinde ağrılı kabarcıklar var mı?",
    text_en:"Painful clustered blisters in a band on one side of the body?",
    triggers_yes:["one_sided_band_rash","blisters_cluster"] },
  { id:"skin_burnpain", ask_if:"skin", type:"yn", weight:4, depends_on:"skin_band",
    text_tr:"Döküntüden önce o bölgede yanma ya da karıncalanma var mıydı?",
    text_en:"Was there burning or tingling in that area before the rash appeared?",
    triggers_yes:["burning_pain_before_rash"] },
  { id:"skin_eye", ask_if:"skin", type:"yn", weight:6, depends_on:"skin_band",
    text_tr:"Döküntü göz çevresine ya da burun ucuna yakın mı?",
    text_en:"Is the rash near the eye or the tip of the nose?",
    triggers_yes:["rash_near_eye"] },
  { id:"skin_itchdry", ask_if:"skin", type:"yn", weight:2,
    text_tr:"Söz konusu bölgeler kuru, pullu ve kaşıntılı mı?",
    text_en:"Are the patches dry, scaly, and itchy?",
    triggers_yes:["itchy_rash","dry_scaly_patches","localized_redness"] },

  // ══ GÖZ DALI ══
  { id:"eye_pain", ask_if:"eye", type:"yn", weight:5,
    text_tr:"Gözde belirgin ağrı var mı (batma değil, gerçek ağrı)?",
    text_en:"Is there real pain in the eye (not just a gritty feeling)?",
    triggers_yes:["eye_pain"] },
  { id:"eye_vision", ask_if:"eye", type:"yn", weight:6,
    text_tr:"Görmede ani azalma ya da kayıp oldu mu?",
    text_en:"Has there been a sudden decrease or loss of vision?",
    triggers_yes:["sudden_vision_loss","painless_vision_loss"] },
  { id:"eye_curtain", ask_if:"eye", type:"yn", weight:6,
    text_tr:"Görme alanınıza perde ya da gölge iner gibi oldu mu?",
    text_en:"Did a curtain or shadow seem to come down over your vision?",
    triggers_yes:["curtain_vision"] },
  { id:"eye_flash", ask_if:"eye", type:"yn", weight:5,
    text_tr:"Ani ışık çakmaları ya da yoğun uçuşan noktalar görüyor musunuz?",
    text_en:"Are you seeing flashes of light or a sudden shower of floaters?",
    triggers_yes:["flashes_of_light","sudden_floaters"] },
  { id:"eye_halo", ask_if:"eye", type:"yn", weight:5,
    text_tr:"Işıkların etrafında renkli haleler görüyor musunuz?",
    text_en:"Do you see halos around lights?",
    triggers_yes:["halos_around_lights"] },
  { id:"eye_red", ask_if:"eye", type:"yn", weight:3,
    text_tr:"Gözünüz kızarık mı?",
    text_en:"Is the eye red?",
    triggers_yes:["red_eye"] },
  { id:"eye_disch", ask_if:"eye", type:"yn", weight:3,
    text_tr:"Çapaklanma ya da akıntı var mı?",
    text_en:"Is there discharge or crusting?",
    triggers_yes:["eye_discharge","crusted_lashes"] },
  { id:"eye_fb", ask_if:"eye", type:"yn", weight:4,
    text_tr:"Gözde yabancı cisim batması hissi ya da göz kırparken ağrı var mı?",
    text_en:"A foreign-body sensation, or pain when blinking?",
    triggers_yes:["foreign_body_sensation","pain_on_blinking"] },
  { id:"eye_photo", ask_if:"eye", type:"yn", weight:3,
    text_tr:"Işığa bakmak gözü rahatsız ediyor mu?",
    text_en:"Does light bother the eye?",
    triggers_yes:["light_sensitivity"] },
  { id:"eye_nausea", ask_if:"eye", type:"yn", weight:4, depends_on:"eye_pain",
    text_tr:"Göz ağrısıyla birlikte bulantı ya da kusma var mı?",
    text_en:"Nausea or vomiting along with the eye pain?",
    triggers_yes:["nausea","vomiting"] },
];


// Tüm offline patternlar — tüm gate pattern'larını kapsıyor
export const OFFLINE_PATTERNS = [
  // Kardiyak
  "acs","afib",
  // Nörolojik
  "stroke","migraine","tension_headache",
  // Solunum / enfeksiyon
  "influenza","pneumonia",
  // GIS
  "gerd","ibs","peptic_ulcer",
  // Üriner
  "uti","pyelonephritis","kidney_stones",
  // Endokrin / metabolik
  "hypothyroidism","anemia","depression",
  // Kas-iskelet
  "lumbar_radiculopathy","cauda_equina",
  // Psikiyatrik
  "anxiety",
  "cellulitis","urticaria_allergy","contact_dermatitis","shingles","conjunctivitis","corneal_abrasion","retinal_detachment","acute_glaucoma"];

// Kapı → ilgili patternlar — tümü OFFLINE_PATTERNS'da mevcut
export const GATE_PATTERNS = {
  chest:    ["acs","afib","gerd","anxiety"],
  headache: ["stroke","migraine","tension_headache"],
  cold:     ["influenza","pneumonia"],
  stomach:  ["gerd","ibs","peptic_ulcer"],
  urinary:  ["uti","pyelonephritis","kidney_stones"],
  fatigue:  ["hypothyroidism","anemia","depression"],
  backpain: ["lumbar_radiculopathy","cauda_equina"],
  anxiety:  ["anxiety","afib","acs"],
  skin:     ["cellulitis","urticaria_allergy","contact_dermatitis","shingles"],
  eye:      ["acute_glaucoma","retinal_detachment","conjunctivitis","corneal_abrasion"],
};


export const MIN_QUESTIONS_BEFORE_DECISION = 5;

// Dinamik soru sıralaması — her cevaptan sonra kalan pattern dağılımına göre
// en ayırt edici soruyu seçer (information gain bazlı)
export function pickNextQuestion(askedIds, selectedGate, collectedTriggers, riskMods, answeredNo, absentTriggers) {
  const noSet = new Set(answeredNo || []);
  const pendingQs = AKINATOR_QUESTIONS.filter(q => {
    if (q.ask_if !== selectedGate) return false;
    if (askedIds.includes(q.id)) return false;
    // Ebeveyne hayır denildiyse bu soruyu atla
    if (q.depends_on && noSet.has(q.depends_on)) return false;
    return true;
  });
  if (pendingQs.length === 0) return null;
  if (pendingQs.length === 1) return pendingQs[0];

  const relevantPatterns = GATE_PATTERNS[selectedGate]
    ? [...new Set([...(GATE_PATTERNS[selectedGate] || []), ...OFFLINE_PATTERNS])]
    : OFFLINE_PATTERNS;
  const gateBonus = selectedGate ? (GATE_PATTERNS[selectedGate] || []) : [];
  const absent = absentTriggers || [];
  // SPRT durumu BİR kez hesaplanır; her aday soru bu duruma karşı puanlanır
  const state = runSPRT(relevantPatterns, collectedTriggers, absent, riskMods, gateBonus, PATTERNS);

  let bestQ = pendingQs[0], bestGain = -1;
  for (const q of pendingQs) {
    const g = sprtQuestionGain(q, state, collectedTriggers, absent, relevantPatterns, PATTERNS);
    if (g > bestGain) { bestGain = g; bestQ = q; }
  }
  return bestQ;
}


// Kırmızı bayrak kombinasyonları — pattern tamamlanmasa bile direkt RED
// Her kural: { triggers: [gerekli triggerlar], min_any: kaçı yeterli, pattern, label_tr, label_en }
export const RED_FLAG_RULES = [
  // ACS — göğüs ağrısı + kol/çene/terleme/nefes'ten biri yeterli
  { triggers:["chest_pain","chest_pressure","chest_tightness"],     min_main:1,
    alarm:["left_arm_pain","jaw_pain","diaphoresis","cold_sweat","shortness_of_breath","shoulder_pain"],
    min_alarm:1, pattern:"acs",
    label_tr:"Göğüs ağrısı + eşlik eden belirti — ACS ekarte edilmeli",
    label_en:"Chest pain + accompanying symptom — ACS must be ruled out" },
  // İnme — FAST belirtilerinden 2'si
  { triggers:["facial_drooping","arm_weakness","speech_difficulty","sudden_headache","numbness_one_side"],
    min_main:2, alarm:[], min_alarm:0, pattern:"stroke",
    label_tr:"İnme belirtileri — FAST pozitif",
    label_en:"Stroke signs — FAST positive" },
  // Cauda equina — eyer uyuşması + mesane
  { triggers:["saddle_anesthesia","urinary_retention","bladder_dysfunction","bowel_dysfunction"],
    min_main:2, alarm:[], min_alarm:0, pattern:"cauda_equina",
    label_tr:"Cauda equina — acil cerrahi değerlendirme",
    label_en:"Cauda equina — emergency surgical assessment" },
  // Aort diseksiyonu — yırtılır gibi ağrı + sırt
  { triggers:["tearing_pain","sudden_severe_chest_pain"],
    min_main:1, alarm:["back_pain","pain_radiation_back"],
    min_alarm:1, pattern:"aortic_dissection",
    label_tr:"Yırtılır gibi göğüs/sırt ağrısı — aort diseksiyonu ekarte edilmeli",
    label_en:"Tearing chest/back pain — aortic dissection must be ruled out" },
  // Piyelonefrit + sepsis belirtisi
  { triggers:["fever","flank_pain"],
    min_main:2, alarm:["confusion","rapid_breathing","rapid_heart_rate"],
    min_alarm:1, pattern:"sepsis",
    label_tr:"Ateş + yan ağrısı + sistemik belirti — sepsis riski",
    label_en:"Fever + flank pain + systemic signs — sepsis risk" },
  // Ateş + nefes darlığı + sistemik → Pnömoni/Sepsis
  { triggers:["fever","shortness_of_breath"],
    min_main:2, alarm:["confusion","rigors","chest_pain"],
    min_alarm:2, pattern:"pneumonia",
    label_tr:"Ateş + nefes darlığı + sistemik belirti — acil değerlendirme",
    label_en:"Fever + breathlessness + systemic signs — emergency assessment" },
  // Travma sonrası bilinç kaybı / nöbet — tek başına yeterli
  { triggers:["loss_of_consciousness","seizure_after_injury"],
    min_main:1, alarm:[], min_alarm:0, pattern:"head_injury",
    label_tr:"Travma sonrası bilinç kaybı / nöbet — acil görüntüleme",
    label_en:"Post-injury loss of consciousness / seizure — emergent imaging" },
  // Anafilaksi — hava yolu belirtisi + alerjik bağlam
  { triggers:["throat_tightness","lip_face_swelling"],
    min_main:1, alarm:["hives","itchy_welts","rash_after_exposure","shortness_of_breath","dizziness","breathing_difficulty_allergy"],
    min_alarm:1, pattern:"urticaria_allergy",
    label_tr:"Alerjik reaksiyonda hava yolu tutulumu — anafilaksi yolu",
    label_en:"Airway involvement in allergic reaction — anaphylaxis pathway" },
  // Ani görme kaybı / perde — aynı gün retina
  { triggers:["curtain_vision","sudden_vision_loss","painless_vision_loss"],
    min_main:1, alarm:["flashes_of_light","sudden_floaters","eye_pain","headache","red_eye","blurred_vision"],
    min_alarm:1, pattern:"retinal_detachment",
    label_tr:"Ani görme kaybı / perde inmesi — aynı gün retina değerlendirmesi",
    label_en:"Sudden vision loss / curtain — same-day retina evaluation" },
];

export function checkRedFlags(collectedTriggers, lang) {
  for (const rule of RED_FLAG_RULES) {
    const mainHits = rule.triggers.filter(t => collectedTriggers.includes(t)).length;
    const alarmHits = rule.alarm.filter(t => collectedTriggers.includes(t)).length;
    const mainOk = mainHits >= rule.min_main;
    const alarmOk = rule.min_alarm === 0 || alarmHits >= rule.min_alarm;
    if (mainOk && alarmOk) {
      const p = PATTERNS[rule.pattern];
      return {
        routing: "RED",
        lambda: 15,
        pattern: rule.pattern,
        label: lang === "tr" ? rule.label_tr : rule.label_en,
        diffs: [{
          name: lang==="tr" ? (OFFLINE_PATTERN_NAMES_TR[rule.pattern]||p?.name||rule.pattern) : (p?.name||rule.pattern),
          pct: 85, risk: "critical", source: p?.source||""
        }],
        doctorAlert: p?.doctor_alert || "",
        urgency: lang==="tr" ? OFFLINE_URGENCY_TR["RED"] : OFFLINE_URGENCY_EN["RED"],
      };
    }
  }
  return null;
}

// Offline karar motoru
// ── DETERMINISTIC CLINICAL SAFETY ESCALATION ──
// Hard override: specific red-flag features push YELLOW→RED regardless of score or LLM output.
// These are life-threatening presentations a kiosk cannot rule out, so the system over-triages by design (false-negative-first).
export function clinicalEscalation(routing, conditionId, triggers) {
  if (routing === "RED") return routing;
  const id = (conditionId || "").toLowerCase();
  const has = t => triggers.includes(t);
  const anyOf = (...ts) => ts.some(has);
  const sirs = anyOf("fever","tachycardia","racing_heart","rapid_heartbeat","shortness_of_breath","rapid_breathing","low_blood_pressure");
  // Cholecystitis + jaundice/pale stool → possible biliary obstruction / ascending cholangitis (Charcot triad). Emergency.
  if ((id === "cholecystitis" || id === "k81") && anyOf("jaundice","clay_stool")) return "RED";
  // Acute pancreatitis + any systemic inflammatory sign (SIRS proxy) → risk of severe AP. Emergency.
  if ((id === "pancreatitis" || id === "k85") && sirs) return "RED";
  // Type 1 diabetes + DKA picture (ketotic breath, or vomiting with rapid onset / abdominal pain) → diabetic ketoacidosis. Emergency.
  if ((id === "diabetes_t1" || id === "e10") && (has("fruity_breath") || (has("vomiting") && anyOf("rapid_onset","abdominal_pain")))) return "RED";
  // Adrenal insufficiency / Addison's + hypotension or vomiting+dizziness → adrenal crisis (shock). Emergency.
  if ((id === "addisons" || id === "e27.1") && (has("low_blood_pressure") || (has("vomiting") && has("dizziness")))) return "RED";
  // Appendicitis + rebound tenderness (peritoneal sign) → perforation/peritonitis. Surgical emergency.
  if ((id === "appendicitis" || id === "k37") && has("rebound_tenderness")) return "RED";
  // Kidney stone + fever → infected obstructed stone / urosepsis. Emergency.
  if ((id === "kidney_stones" || id === "n20") && has("fever")) return "RED";
  // DVT + breathlessness/chest pain/hemoptysis → pulmonary embolism. Emergency.
  if ((id === "dvt" || id === "i80.2") && anyOf("shortness_of_breath","chest_pain","coughing_blood","rapid_breathing")) return "RED";
  // ── Travma / cilt / göz eskalasyonları ──
  if ((id === "head_injury" || id === "s06.0") && anyOf("loss_of_consciousness","repeated_vomiting","seizure_after_injury")) return "RED";
  if ((id === "fracture_suspect" || id === "t14.2") && anyOf("open_wound","limb_numb_pale")) return "RED";
  if ((id === "laceration" || id === "s61.9") && has("bleeding_uncontrolled")) return "RED";
  if ((id === "cellulitis" || id === "l03.9") && anyOf("fever","red_streaks")) return "RED";
  if ((id === "shingles" || id === "b02.9") && has("rash_near_eye")) return "RED";
  if ((id === "urticaria_allergy" || id === "l50.9") && anyOf("throat_tightness","lip_face_swelling","breathing_difficulty_allergy")) return "RED";
  return routing;
}
export function escalationNote(conditionId, triggers, lang) {
  const id = (conditionId || "").toLowerCase();
  const has = t => triggers.includes(t);
  if ((id === "cholecystitis" || id === "k81") && (has("jaundice") || has("clay_stool")))
    return lang === "tr"
      ? "ESKALASYON: Sarılık / açık renkli dışkı = olası safra yolu tıkanıklığı veya asendan kolanjit (Charcot triadı). Acil değerlendirme; antibiyotik + acil safra drenajı gerekebilir."
      : "ESCALATION: Jaundice / pale stool = possible biliary obstruction or ascending cholangitis (Charcot triad). Emergency workup; may require antibiotics + urgent biliary drainage.";
  if (id === "pancreatitis" || id === "k85")
    return lang === "tr"
      ? "ESKALASYON: Pankreatit + sistemik enflamasyon işareti (SIRS) = ağır seyir riski. Acil servis değerlendirmesi (lipaz, IV sıvı, izlem)."
      : "ESCALATION: Pancreatitis + systemic inflammatory sign (SIRS) = risk of severe course. Emergency department evaluation (lipase, IV fluids, monitoring).";
  if (id === "diabetes_t1" || id === "e10")
    return lang === "tr"
      ? "ESKALASYON: Tip 1 diyabet + DKA bulguları (asetonlu/meyveli nefes ya da kusma + ani başlangıç). Diyabetik ketoasidoz hayati acildir. Acil glukoz + keton + IV sıvı."
      : "ESCALATION: Type 1 diabetes + DKA features (fruity/acetone breath or vomiting + rapid onset). Diabetic ketoacidosis is life-threatening. Urgent glucose + ketones + IV fluids.";
  if (id === "addisons" || id === "e27.1")
    return lang === "tr"
      ? "ESKALASYON: Adrenal yetmezlik + kriz bulguları (düşük tansiyon ya da kusma + baş dönmesi). Adrenal kriz = şok. Acil IV hidrokortizon + sıvı."
      : "ESCALATION: Adrenal insufficiency + crisis signs (low blood pressure or vomiting + dizziness). Adrenal crisis = shock. Emergency IV hydrocortisone + fluids.";
  if (id === "appendicitis" || id === "k37")
    return lang === "tr"
      ? "ESKALASYON: Apandisit + rebound (geri tepme) hassasiyeti = peritoneal bulgu, olası perforasyon/peritonit. Cerrahi acil."
      : "ESCALATION: Appendicitis + rebound tenderness = peritoneal sign, possible perforation/peritonitis. Surgical emergency.";
  if (id === "kidney_stones" || id === "n20")
    return lang === "tr"
      ? "ESKALASYON: Böbrek taşı + ateş = enfekte tıkalı taş / ürosepsis riski. Acil; tıkanıklığın acil drenajı gerekebilir."
      : "ESCALATION: Kidney stone + fever = infected obstructed stone / urosepsis risk. Emergency; obstruction may need urgent drainage.";
  if (id === "dvt" || id === "i80.2")
    return lang === "tr"
      ? "ESKALASYON: DVT + nefes darlığı / göğüs ağrısı / kan tükürme = olası pulmoner emboli. Acil."
      : "ESCALATION: DVT + breathlessness / chest pain / hemoptysis = possible pulmonary embolism. Emergency.";
  if ((id === "head_injury" || id === "s06.0") && (has("loss_of_consciousness") || has("repeated_vomiting") || has("seizure_after_injury")))
    return lang === "tr"
      ? "ESKALASYON: Travma sonrası bilinç kaybı / tekrarlayan kusma / nöbet = acil BT endikasyonu (Canadian CT Head Rule). Acil servis."
      : "ESCALATION: Post-injury LOC / repeated vomiting / seizure = emergent CT indication (Canadian CT Head Rule). ED now.";
  if ((id === "fracture_suspect" || id === "t14.2") && (has("open_wound") || has("limb_numb_pale")))
    return lang === "tr"
      ? "ESKALASYON: Kırık bölgesinde açık yara veya uyuşuk/soluk uzuv = açık kırık / nörovasküler tehlike. Acil cerrahi değerlendirme."
      : "ESCALATION: Open wound over fracture or numb/pale limb = open fracture / neurovascular compromise. Emergent surgical evaluation.";
  if ((id === "laceration" || id === "s61.9") && has("bleeding_uncontrolled"))
    return lang === "tr"
      ? "ESKALASYON: Basınca rağmen durmayan kanama = acil kanama kontrolü gerekir."
      : "ESCALATION: Bleeding uncontrolled by direct pressure = emergent hemorrhage control.";
  if ((id === "cellulitis" || id === "l03.9") && (has("fever") || has("red_streaks")))
    return lang === "tr"
      ? "ESKALASYON: Selülit + ateş veya kırmızı çizgiler (lenfanjit) = sistemik yayılım. IV antibiyotik / acil değerlendirme."
      : "ESCALATION: Cellulitis + fever or red streaks (lymphangitis) = systemic spread. IV antibiotics / emergency evaluation.";
  if ((id === "shingles" || id === "b02.9") && has("rash_near_eye"))
    return lang === "tr"
      ? "ESKALASYON: Göz çevresinde zona (Hutchinson bulgusu) = görmeyi tehdit eden oftalmik tutulum. Acil göz hastalıkları."
      : "ESCALATION: Zoster near the eye (Hutchinson sign) = sight-threatening ophthalmic involvement. Urgent ophthalmology.";
  if ((id === "urticaria_allergy" || id === "l50.9") && (has("throat_tightness") || has("lip_face_swelling") || has("breathing_difficulty_allergy")))
    return lang === "tr"
      ? "ESKALASYON: Boğaz daralması / dudak-dil şişmesi = anafilaksi yolu. Epinefrin + acil servis."
      : "ESCALATION: Throat tightness / lip-tongue swelling = anaphylaxis pathway. Epinephrine + ED.";
  return "";
}

// ═══════════════════════════════════════════════════════════════════
// SPRT ENGINE v2 — true two-boundary sequential probability ratio test
// Replaces heuristic (hits × sprt_lr × mod). Theory: Math Foundations
// §02 (upper bound h=log(1/α)), §4.2 (lower bound h_lower=log(β)),
// PhD Appendix (Wald forms a=log(β/(1−α)), b=log((1−β)/α)).
// Per-symptom LRs are FIRST-PASS CALIBRATION derived from pattern-level
// sprt_lr; structure accepts per-symptom literature overrides
// (pattern.lrOverrides = { trigger_id: {plus, minus} }) — calibration
// against MIMIC-IV is the PhD-phase task. Guarantees are conditional on
// correctly specified LRs (Pre-Mortem Risk 8).
// ═══════════════════════════════════════════════════════════════════
export const SPRT_CFG = {
  ALPHA: 0.05,                       // max false-RED (Type I)
  BETA: 0.05,                        // max missed-emergency (Type II / FNR)
  B_UPPER: Math.log(0.95 / 0.05),    // ≈ +2.944 — confirm boundary (Wald b)
  A_LOWER: Math.log(0.05 / 0.95),    // ≈ −2.944 — exclude boundary (Wald a)
  PRIOR_CLAMP: 1.5,   // |S₀| ≤ 1.5: prior may nudge, never pre-decide
  MOD_CLAMP: 1.2,     // demographic multiplier contribution cap (log space)
  PREV_W: 0.25, PREV_REF: 5.0, PREV_CLAMP: 0.4,  // relative-prevalence term
  GATE_ON: Math.log(1.4), GATE_OFF: -Math.log(1.4), // gate prior shift
  LR_FLOOR: 1.3,      // floor for sprt_lr<1 patterns (anxiety 0.6 etc.)
  TRIG_W: 0.5,        // non-confirmatory present: y = 0.5·log(LR)
  LRM_CONF: 0.35,     // confirmatory ABSENT → LR⁻ (strong negative evidence)
  LRM_TRIG: 0.7,      // trigger ABSENT → LR⁻ (mild negative evidence)
  ABSTAIN_MARGIN: 0.8, // critical blocks GREEN unless S ≤ A_LOWER+margin
  LEAN_MIN: 1.0,      // unconfirmed lean → provisional routing if S ≥ 1.0
  LAMBDA_MIN: 0.012, LAMBDA_MAX: 95,
};
export const SPRT_SEV = { critical: 3, high: 2, moderate: 1, low: 0 };
export const SPRT_ROUTE_RANK = { RED: 3, GREY: 2, YELLOW: 1, GREEN: 0 };
export const sprtClamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

// log-likelihood contribution of one symptom for one pattern
export function sprtSymptomY(pat, trig, present, conf) {
  const ov = pat.lrOverrides?.[trig];
  let yh;
  if (ov) yh = Math.log(present ? (ov.plus || 1) : (ov.minus || 1));
  else {
    const base = Math.max(pat.sprt_lr || 1, SPRT_CFG.LR_FLOOR);
    const isConf = (pat.confirmatory || []).includes(trig);
    yh = present
      ? (isConf ? 1 : SPRT_CFG.TRIG_W) * Math.log(base)
      : Math.log(isConf ? SPRT_CFG.LRM_CONF : SPRT_CFG.LRM_TRIG);
  }
  // Soft evidence (Tez Bölüm 3.3): beklenen-LR altında entegrasyon.
  // LR_eff = c·e^{y} + (1−c)·1  →  y_soft = log(LR_eff).
  // c = ekstraktörün kalibre olasılığı; c=1 klasik (hard) SPRT'yi BİREBİR verir,
  // c→0 katkıyı sıfıra çeker (log 1 = 0). |y_soft| ≤ |y_hard| her zaman.
  const c = conf == null ? 1 : Math.max(0, Math.min(1, conf));
  if (c >= 1) return yh;
  return Math.log(c * Math.exp(yh) + (1 - c));
}

// clamped prior offset S₀ = demographics + relative prevalence + gate
export function sprtPrior(pat, key, riskMods, gateBonus) {
  const mod = riskMods?.[key] ?? 1.0;
  let s0 = sprtClamp(Math.log(Math.max(mod, 0.05)), -SPRT_CFG.MOD_CLAMP, SPRT_CFG.MOD_CLAMP);
  s0 += sprtClamp(SPRT_CFG.PREV_W * Math.log((pat.base_prevalence || 1) / SPRT_CFG.PREV_REF), -SPRT_CFG.PREV_CLAMP, SPRT_CFG.PREV_CLAMP);
  if (gateBonus && gateBonus.length > 0) s0 += gateBonus.includes(key) ? SPRT_CFG.GATE_ON : SPRT_CFG.GATE_OFF;
  return sprtClamp(s0, -SPRT_CFG.PRIOR_CLAMP, SPRT_CFG.PRIOR_CLAMP);
}

// run parallel SPRTs over patternKeys given present/absent trigger sets
export function runSPRT(patternKeys, present, absent, riskMods, gateBonus, PAT, confMap) {
  // confMap: {trigger_id: P(present|anlatı)} — LLM'in kalibre olasılıkları (online).
  // Varlık kanalı c = p; yokluk kanalı c = 1−p (yokluk iddiasının gücü). Yoksa c=1.
  const cm = confMap || null;
  const per = {};
  const presentSet = new Set(present);
  const absentSet = new Set((absent || []).filter(t => !presentSet.has(t)));
  for (const key of patternKeys) {
    const pat = PAT[key];
    if (!pat) continue;
    const presRel = (pat.triggers || []).filter(t => presentSet.has(t));
    const absRel = (pat.triggers || []).filter(t => absentSet.has(t));
    const reqMet = (pat.required_any || []).length === 0 || pat.required_any.some(r => presentSet.has(r));
    const active = reqMet && presRel.length >= 1;
    if (!active) { per[key] = { active: false, status: "inactive", S: null }; continue; }
    const s0 = sprtPrior(pat, key, riskMods, gateBonus);
    let S = s0;
    const traj = [{ t: "prior", y: s0, S: s0 }];
    for (const t of presRel) { const c = cm && typeof cm[t] === "number" ? cm[t] : 1; const y = sprtSymptomY(pat, t, true, c); S += y; traj.push({ t, y, S, present: true }); }
    for (const t of absRel) { const c = cm && typeof cm[t] === "number" ? (1 - cm[t]) : 1; const y = sprtSymptomY(pat, t, false, c); S += y; traj.push({ t, y, S, present: false }); }
    const status = S >= SPRT_CFG.B_UPPER ? "confirmed" : S <= SPRT_CFG.A_LOWER ? "excluded" : "indeterminate";
    per[key] = { active: true, status, S, s0, traj, presRel, absRel, risk: pat.risk || "moderate" };
  }
  const byS = st => Object.keys(per).filter(k => per[k].status === st)
    .sort((a, b) => (SPRT_SEV[per[b].risk] - SPRT_SEV[per[a].risk]) || (per[b].S - per[a].S));
  return { per, confirmed: byS("confirmed"), indeterminate: byS("indeterminate"), excluded: byS("excluded") };
}

// posterior-share differentials — geniş aday seti (en az 1 trigger eşleşen tüm hipotezler).
// routing kararından BAĞIMSIZ: yalnız doktor-modu tablosu için zengin ayırıcı tanı üretir.
export function sprtDiffs(sprt, lang, PAT, namesTR, present, absent, riskMods, gateBonus) {
  const presentSet = new Set(present || []);
  const absentSet = new Set((absent || []).filter(t => !presentSet.has(t)));
  // Önce runSPRT'nin tam aktif hipotezleri (confirmed/indeterminate skorlarıyla)
  const scored = {};
  for (const [k, v] of Object.entries(sprt.per)) {
    if (v.active && v.S != null) scored[k] = v.S;
  }
  // Sonra: aktif sayılmayan ama ≥1 trigger eşleşen hipotezleri de aday olarak ekle (gevşek skor).
  // Bu yalnız tablo için; required_any karşılanmadıysa hafif ceza ile dahil edilir.
  const candidateKeys = gateBonus && gateBonus.length
    ? [...new Set([...gateBonus, ...Object.keys(scored)])]
    : Object.keys(PAT);
  for (const k of candidateKeys) {
    if (scored[k] != null) continue;
    const pat = PAT[k]; if (!pat) continue;
    const presRel = (pat.triggers || []).filter(t => presentSet.has(t));
    if (presRel.length < 1) continue;
    const reqMet = (pat.required_any || []).length === 0 || pat.required_any.some(r => presentSet.has(r));
    let s = sprtPrior(pat, k, riskMods || {}, gateBonus || []);
    for (const t of presRel) s += sprtSymptomY(pat, t, true, 1);
    for (const t of (pat.triggers || []).filter(t => absentSet.has(t))) s += sprtSymptomY(pat, t, false, 1);
    if (!reqMet) s -= 0.7; // required_any yoksa hafif indirim (aday kalır ama geride)
    scored[k] = s;
  }
  const entries = Object.entries(scored);
  if (entries.length === 0) return [];
  const tot = entries.reduce((acc, [, s]) => acc + Math.exp(s), 0) || 1;
  return entries
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([k, s]) => ({
      name: lang === "tr" ? (namesTR[k] || PAT[k]?.name || k) : (PAT[k]?.name || k),
      pct: Math.round((Math.exp(s) / tot) * 1000) / 10,  // küsuratlı: 85.3 gibi
      risk: PAT[k]?.risk || "moderate",
      source: PAT[k]?.source || "",
    }));
}

// compact doctor-mode narrative of the decision statistic
export function sprtNarrative(key, c) {
  if (!c || !c.traj) return "";
  const terms = c.traj.slice(1, 7).map(s => `${s.present ? "+" : "−"}${s.t} ${s.y >= 0 ? "+" : ""}${s.y.toFixed(2)}`).join(" · ");
  const more = c.traj.length > 7 ? " · …" : "";
  return `[SPRT] ${key}: S₀=${c.s0 >= 0 ? "+" : ""}${c.s0.toFixed(2)} · ${terms}${more} → S=${c.S.toFixed(2)} (bounds ${SPRT_CFG.A_LOWER.toFixed(2)}/${SPRT_CFG.B_UPPER.toFixed(2)}, odds ${Math.exp(c.S).toFixed(1)}:1) → ${c.status}`;
}

export const sprtLambda = S => sprtClamp(Math.exp(S), SPRT_CFG.LAMBDA_MIN, SPRT_CFG.LAMBDA_MAX);

// core decision: returns result object, or null = keep questioning / no match
export function sprtDecide(opts) {
  const { collected, absent, riskMods, askedCount, gate, lang, force,
    patternKeys, PAT, namesTR, urgTR, urgEN, escalateFn, escNoteFn, redFlagFn, minQuestions, confMap} = opts;
  const gateBonus = gate ? (opts.gatePatterns?.[gate] || []) : [];
  const redFlag = redFlagFn(collected, lang);
  if (redFlag) {
    // Routing/label/urgency red-flag'ten gelir; ama ayırıcı tanı + λ'yı SPRT'ten türet.
    const rfSprt = runSPRT(patternKeys, collected, absent, riskMods, gateBonus, PAT, confMap);
    const rfDiffs = sprtDiffs(rfSprt, lang, PAT, namesTR, collected, absent, riskMods, gateBonus);
    // λ: red-flag pattern'inin gerçek SPRT skorundan; yoksa aktif liderden. Red-flag tabanı 9.6 korunur.
    const rfKey = redFlag.pattern;
    const rfS = rfSprt.per[rfKey]?.active ? rfSprt.per[rfKey].S
      : (rfSprt.confirmed[0] ? rfSprt.per[rfSprt.confirmed[0]].S
      : (rfSprt.indeterminate[0] ? rfSprt.per[rfSprt.indeterminate[0]].S : null));
    const rfLambda = rfS != null ? Math.max(9.6, sprtLambda(rfS)) : redFlag.lambda;
    // SPRT yörüngesini de taşı (QR'daki hesap satırı için) — lider hipotezin izini ekle.
    const rfLeadKey = rfSprt.per[rfKey]?.active ? rfKey : (rfSprt.confirmed[0] || rfSprt.indeterminate[0]);
    const rfLead = rfLeadKey ? rfSprt.per[rfLeadKey] : null;
    const rfSprtPayload = rfLead ? { topKey: rfLeadKey, S: rfLead.S, s0: rfLead.s0, traj: rfLead.traj, A: SPRT_CFG.A_LOWER, B: SPRT_CFG.B_UPPER, confirmed: rfSprt.confirmed, excluded: rfSprt.excluded } : null;
    return { ...redFlag, lambda: rfLambda, diffs: rfDiffs.length ? rfDiffs : redFlag.diffs, sprt: rfSprtPayload || redFlag.sprt, engine: "sprt-v2" };
  }
  if (!force && askedCount < minQuestions) return null;

  const sprt = runSPRT(patternKeys, collected, absent, riskMods, gateBonus, PAT, confMap);
  const urg = r => (lang === "tr" ? urgTR : urgEN)[r];
  const diffs = sprtDiffs(sprt, lang, PAT, namesTR, collected, absent, riskMods, gateBonus);

  // ── confirmed hypotheses: worst effective routing wins ──
  if (sprt.confirmed.length > 0) {
    let topKey = null, topRoute = "GREEN", escalatedAny = false;
    for (const k of sprt.confirmed) {
      const base = PAT[k]?.routing_if_confirmed || "YELLOW";
      const eff = escalateFn(base, k, collected);
      if (eff !== base) escalatedAny = true;
      if (!topKey || SPRT_ROUTE_RANK[eff] > SPRT_ROUTE_RANK[topRoute] ||
        (SPRT_ROUTE_RANK[eff] === SPRT_ROUTE_RANK[topRoute] && sprt.per[k].S > sprt.per[topKey].S)) {
        topKey = k; topRoute = eff;
      }
    }
    const c = sprt.per[topKey];
    const escNote = escalatedAny ? escNoteFn(topKey, collected, lang) : "";
    const alertParts = [escNote, sprtNarrative(topKey, c), PAT[topKey]?.doctor_alert || ""].filter(Boolean);
    return {
      routing: topRoute,
      lambda: escalatedAny ? Math.max(9.6, sprtLambda(c.S)) : sprtLambda(c.S),
      diffs, doctorAlert: alertParts.join("\n\n"), urgency: urg(topRoute),
      escalated: escalatedAny, engine: "sprt-v2",
      sprt: { topKey, S: c.S, s0: c.s0, traj: c.traj, A: SPRT_CFG.A_LOWER, B: SPRT_CFG.B_UPPER, confirmed: sprt.confirmed, excluded: sprt.excluded },
    };
  }

  // ── nothing confirmed ──
  if (!force) return null; // sequential: keep questioning

  // Eskalasyon TABANI: belirsizlik (soft evidence) deterministik güvenlik kurallarını
  // susturamaz. Açık (indeterminate) hipotezlerden herhangi biri kural-RED veriyorsa,
  // GREY çekimserliğine düşmeden önce RED'e yükselt — red-flag'lerle aynı doktrin.
  for (const ek of sprt.indeterminate) {
    if (escalateFn("YELLOW", ek, collected) === "RED") {
      const ec = sprt.per[ek];
      const note = escNoteFn(ek, collected, lang) || "";
      const parts = [note, sprtNarrative(ek, ec), PAT[ek]?.doctor_alert || ""].filter(Boolean);
      return {
        routing: "RED", lambda: Math.max(9.6, sprtLambda(ec.S)), diffs,
        doctorAlert: parts.join("\n\n"), urgency: urg("RED"),
        escalated: true, engine: "sprt-v2",
        sprt: { topKey: ek, S: ec.S, s0: ec.s0, traj: ec.traj, A: SPRT_CFG.A_LOWER, B: SPRT_CFG.B_UPPER, confirmed: sprt.confirmed, excluded: sprt.excluded },
      };
    }
  }

  // force-finalize: formal abstention if a critical hypothesis is still open
  const openCritical = sprt.indeterminate.filter(k =>
    (PAT[k]?.risk === "critical") && sprt.per[k].S > SPRT_CFG.A_LOWER + SPRT_CFG.ABSTAIN_MARGIN);
  if (openCritical.length > 0) {
    const k = openCritical[0]; const c = sprt.per[k];
    return {
      routing: "GREY", lambda: sprtLambda(c.S), diffs,
      doctorAlert: `${sprtNarrative(k, c)}\n\n${PAT[k]?.doctor_alert || ""}`,
      urgency: urg("GREY"), escalated: false, engine: "sprt-v2",
      sprt: { topKey: k, S: c.S, s0: c.s0, traj: c.traj, A: SPRT_CFG.A_LOWER, B: SPRT_CFG.B_UPPER, confirmed: [], excluded: sprt.excluded, abstained: true },
    };
  }

  // provisional lean or GREEN fallback
  const open = sprt.indeterminate;
  if (open.length === 0) {
    if (diffs.length === 0) return null; // truly nothing matched — caller message
    return { routing: "GREEN", lambda: 0.05, diffs, doctorAlert: PAT[Object.keys(sprt.per).find(k => sprt.per[k].active)]?.doctor_alert || "", urgency: urg("GREEN"), escalated: false, engine: "sprt-v2", sprt: null };
  }
  const k = open[0]; const c = sprt.per[k];
  let routing = "GREEN";
  if (c.S >= SPRT_CFG.LEAN_MIN) {
    const base = PAT[k]?.routing_if_confirmed || "YELLOW";
    routing = base === "RED" ? "GREY" : base;
  }
  const eff = escalateFn(routing, k, collected);
  const escNote = eff !== routing ? escNoteFn(k, collected, lang) : "";
  return {
    routing: eff, lambda: eff !== routing ? Math.max(9.6, sprtLambda(c.S)) : sprtLambda(c.S), diffs,
    doctorAlert: [escNote, sprtNarrative(k, c), PAT[k]?.doctor_alert || ""].filter(Boolean).join("\n\n"),
    urgency: urg(eff), escalated: eff !== routing, engine: "sprt-v2",
    sprt: { topKey: k, S: c.S, s0: c.s0, traj: c.traj, A: SPRT_CFG.A_LOWER, B: SPRT_CFG.B_UPPER, confirmed: [], excluded: sprt.excluded },
  };
}

// expected discrimination value of asking question q given current SPRT state:
// severity-weighted, plausibility-weighted movement toward either boundary,
// plus discovery value for hypotheses the question could newly activate.
export function sprtQuestionGain(q, state, present, absent, patternKeys, PAT) {
  const yesTrigs = (q.type === "yn" ? (q.triggers_yes || []) : [q.scale_trigger, ...(q.scale_high_triggers || [])]).filter(Boolean);
  const newTrigs = yesTrigs.filter(t => !present.includes(t) && !absent.includes(t));
  if (newTrigs.length === 0) return 0;
  let gain = 0;
  for (const key of patternKeys) {
    const pat = PAT[key]; if (!pat) continue;
    const rel = newTrigs.filter(t => (pat.triggers || []).includes(t));
    if (rel.length === 0) continue;
    const sev = (SPRT_SEV[pat.risk || "moderate"] ?? 1) + 0.5;
    const st = state.per[key];
    if (st && st.active && st.status === "indeterminate") {
      const plaus = Math.exp(Math.min(st.S, 2)); // capped posterior plausibility
      const dYes = rel.reduce((s, t) => s + Math.abs(sprtSymptomY(pat, t, true)), 0);
      const dNo = rel.reduce((s, t) => s + Math.abs(sprtSymptomY(pat, t, false)), 0);
      gain += sev * plaus * (dYes + dNo) / 2;
    } else if (!st || !st.active) {
      if ((pat.required_any || []).some(r => newTrigs.includes(r))) {
        const dYes = rel.reduce((s, t) => s + Math.abs(sprtSymptomY(pat, t, true)), 0);
        gain += sev * 0.4 * dYes; // discovery weight for waking a hypothesis
      }
    }
  }
  return gain * (q.weight || 1);
}
// ═══════════════════════════ END SPRT ENGINE v2 ═══════════════════════════

export function computeOfflineResult(collectedTriggers, riskMods, askedCount, selectedGate, lang, force=false, absentTriggers=[]) {
  const relevantPatterns = GATE_PATTERNS[selectedGate]
    ? [...new Set([...(GATE_PATTERNS[selectedGate] || []), ...OFFLINE_PATTERNS])]
    : OFFLINE_PATTERNS;
  return sprtDecide({
    collected: collectedTriggers, absent: absentTriggers, riskMods, askedCount,
    gate: selectedGate, lang, force,
    patternKeys: relevantPatterns, PAT: PATTERNS,
    namesTR: OFFLINE_PATTERN_NAMES_TR, urgTR: OFFLINE_URGENCY_TR, urgEN: OFFLINE_URGENCY_EN,
    escalateFn: clinicalEscalation, escNoteFn: escalationNote, redFlagFn: checkRedFlags,
    minQuestions: MIN_QUESTIONS_BEFORE_DECISION, gatePatterns: GATE_PATTERNS,
  });
}

export const OFFLINE_PATTERN_NAMES_TR = {
  acs: "Akut Koroner Sendrom", stroke: "İnme / TİA", migraine: "Migren",
  uti: "İdrar Yolu Enfeksiyonu", hypothyroidism: "Hipotiroidizm",
  influenza: "Grip", gerd: "Mide Reflüsü", ibs: "İrritabl Bağırsak",
  lumbar_radiculopathy: "Bel Fıtığı / Sinir Sıkışması",
  cauda_equina: "Cauda Equina Sendromu", anxiety: "Anksiyete / Panik",
  anemia: "Anemi", pyelonephritis: "Böbrek İltihabı",
  head_injury:"Kafa Travması / Beyin Sarsıntısı", fracture_suspect:"Kırık Şüphesi", sprain_strain:"Burkulma / Zorlanma", laceration:"Kesik / Açık Yara",
  cellulitis:"Selülit (Cilt Enfeksiyonu)", urticaria_allergy:"Ürtiker / Alerjik Reaksiyon", contact_dermatitis:"Kontakt Dermatit / Egzama", shingles:"Zona",
  conjunctivitis:"Konjonktivit", corneal_abrasion:"Kornea Çizilmesi / Yabancı Cisim", retinal_detachment:"Retina Dekolmanı / Ani Görme Kaybı", acute_glaucoma:"Akut Glokom",
};
export const OFFLINE_URGENCY_TR = {
  RED: "Hemen 112'yi arayın veya acil servise gidin.",
  YELLOW: "Bugün bir doktora görünün.",
  GREEN: "Belirtiler kötüleşirse, yeni belirti eklenirse veya 48 saat içinde geçmezse bir doktora görünün.",
  GREY: "Örüntü güvenli otomatik karar için yeterince net değil. Lütfen görevli doktora başvurun ya da bugün doktorunuzu arayın.",
};
export const OFFLINE_URGENCY_EN = {
  RED: "Call 911 or go to the ED immediately.",
  YELLOW: "See a doctor today.",
  GREEN: "If symptoms worsen, new symptoms appear, or they don't improve within 48 hours, see a doctor.",
  GREY: "The pattern is not clear enough for a safe automated decision. Please see the on-site doctor or call your doctor today.",
};

export function computeRiskProfile(profile) {
  const {age,sex,bmi,smoking,diabetes,hypertension,familyHistory}=profile;
  const mods={};
  const bmiCat=!bmi?"unknown":bmi<18.5?"underweight":bmi<25?"normal":bmi<30?"overweight":bmi<35?"obese_1":"obese_2";
  const obese = bmiCat==="obese_1"||bmiCat==="obese_2";
  const female = sex==="female";
  const male = sex==="male";
  const older = age>60; const middle = age>40; const young = age<35;

  mods.diabetes_t2=1.0*(bmiCat==="obese_2"?3.2:bmiCat==="obese_1"?2.1:bmiCat==="overweight"?1.5:1.0)*(age>45?1.8:age>35?1.3:1.0)*(familyHistory?1.6:1.0)*(smoking?1.3:1.0);
  mods.diabetes_t1=1.0*(young?2.0:1.0)*(familyHistory?2.0:1.0);
  mods.hypothyroidism=1.0*(female?5.0:1.0)*(older?1.8:1.0);
  mods.hyperthyroidism=1.0*(female?7.0:1.0)*(age>20&&age<50?1.5:1.0);
  mods.cushings=1.0*(female?3.0:1.0)*(obese?1.5:1.0)*(age>20&&age<50?1.5:1.0);
  mods.addisons=1.0*(female?2.0:1.0)*(age>20&&age<50?1.5:1.0);
  mods.pcos=female&&age<50?1.0*(bmiCat==="obese_1"||bmiCat==="obese_2"?1.8:1.0)*(age>13&&age<45?2.0:0.1):0.0;
  mods.acs=1.0*(male?1.8:1.0)*(age>65?3.0:age>50?2.0:age>40?1.4:0.6)*(diabetes?2.0:1.0)*(smoking?1.9:1.0)*(hypertension?1.6:1.0)*(familyHistory?1.5:1.0);
  mods.aortic_dissection=1.0*(male?2.0:1.0)*(age>60?2.5:age>50?1.6:1.0)*(hypertension?2.5:1.0);
  mods.heart_failure=1.0*(age>65?2.5:age>50?1.5:1.0)*(diabetes?1.8:1.0)*(hypertension?2.0:1.0)*(obese?1.6:1.0);
  mods.pe=1.0*(age>50?1.5:1.0)*(obese?1.4:1.0)*(smoking?1.3:1.0);
  mods.stroke=1.0*(age>65?2.5:age>50?1.6:1.0)*(hypertension?2.1:1.0)*(diabetes?1.5:1.0)*(smoking?1.7:1.0);
  mods.hypertensive_crisis=1.0*(age>50?1.8:1.0)*(hypertension?4.0:1.0)*(diabetes?1.4:1.0);
  mods.afib=1.0*(age>65?3.0:age>55?1.8:1.0)*(hypertension?1.8:1.0)*(diabetes?1.4:1.0);
  mods.dvt=1.0*(age>50?1.5:1.0)*(obese?1.5:1.0)*(smoking?1.3:1.0);
  mods.parkinsons=1.0*(age>70?3.0:age>60?2.0:age>50?1.2:0.3)*(male?1.5:1.0);
  mods.essential_tremor=1.0*(age>60?2.0:age>40?1.3:1.0)*(familyHistory?2.0:1.0);
  mods.migraine=1.0*(female?3.0:1.0)*(age>15&&age<55?1.5:0.8);
  mods.ms=1.0*(female?2.5:1.0)*(age>20&&age<40?2.0:0.8);
  mods.epilepsy=1.0*(age<30?1.5:1.0);
  mods.tension_headache=1.0*(female?1.3:1.0)*(middle?1.2:1.0)*(smoking?1.2:1.0);
  mods.lupus=1.0*(female?9.0:1.0)*(age>15&&age<50?2.0:0.6);
  mods.ra=1.0*(female?2.5:1.0)*(age>40&&age<70?1.8:1.0)*(smoking?1.5:1.0)*(familyHistory?1.6:1.0);
  mods.gout=1.0*(male?4.0:1.0)*(age>40?2.0:1.0)*(obese?1.8:1.0)*(diabetes?1.5:1.0);
  mods.fibromyalgia=1.0*(female?7.0:1.0)*(age>30&&age<60?1.5:1.0);
  mods.osteoporosis=1.0*(female?3.0:1.0)*(age>65?3.0:age>50?1.5:0.3)*(bmiCat==="underweight"?2.0:1.0);
  mods.appendicitis=1.0*(age>10&&age<40?2.0:1.0);
  mods.ibd=1.0*(age>15&&age<40?1.8:1.0)*(smoking?1.5:1.0)*(familyHistory?2.0:1.0);
  mods.celiac=1.0*(female?1.5:1.0)*(familyHistory?3.0:1.0);
  mods.peptic_ulcer=1.0*(male?1.5:1.0)*(smoking?2.0:1.0)*(older?1.5:1.0);
  mods.gerd=1.0*(obese?2.5:1.0)*(smoking?1.5:1.0)*(older?1.3:1.0);
  mods.bowel_obstruction=1.0*(older?2.0:1.0);
  mods.cholecystitis=1.0*(female?2.0:1.0)*(obese?2.5:1.0)*(age>40?1.8:1.0);
  mods.pancreatitis=1.0*(male?1.5:1.0)*(age>40?1.5:1.0);
  mods.ibs=1.0*(female?2.0:1.0)*(age>15&&age<50?1.5:1.0);
  mods.nafld=1.0*(bmiCat==="obese_2"?3.5:bmiCat==="obese_1"?2.2:bmiCat==="overweight"?1.5:0.5)*(diabetes?2.0:1.0)*(age>40?1.4:1.0);
  mods.copd=1.0*(smoking?4.0:1.0)*(age>50?2.0:1.0);
  mods.asthma=1.0*(female?1.2:1.0)*(young?1.5:1.0);
  mods.pneumonia=1.0*(older?2.5:1.0)*(smoking?1.5:1.0)*(diabetes?1.5:1.0);
  mods.depression=1.0*(female?1.8:1.0)*(older?1.3:1.0)*(smoking?1.3:1.0);
  mods.anxiety=1.0*(female?2.0:1.0)*(young?1.5:1.0)*(smoking?1.2:1.0);
  mods.bipolar=1.0*(age>15&&age<35?1.8:1.0)*(familyHistory?2.5:1.0);
  mods.ptsd=1.0*(female?2.0:1.0);
  mods.ckd=1.0*(diabetes?2.5:1.0)*(hypertension?2.0:1.0)*(age>60?1.8:1.0);
  mods.kidney_stones=1.0*(male?2.0:1.0)*(age>20&&age<60?1.8:1.0)*(obese?1.4:1.0);
  mods.uti=1.0*(female?10.0:1.0)*(diabetes?2.0:1.0)*(older?1.5:1.0);
  mods.pyelonephritis=1.0*(female?5.0:1.0)*(diabetes?2.5:1.0);
  mods.anemia=1.0*(female?2.5:1.0)*(older?1.5:1.0);
  mods.sleep_apnea=1.0*(bmiCat==="obese_2"?4.0:bmiCat==="obese_1"?2.5:bmiCat==="overweight"?1.6:1.0)*(male?2.0:1.0)*(age>40?1.5:1.0);
  mods.cancer_red_flags=1.0*(age>50?2.5:age>40?1.5:1.0)*(smoking?1.8:1.0)*(familyHistory?1.8:1.0);
  mods.ectopic=female&&age>12&&age<50?1.0:0.0;
  mods.sepsis=1.0*(older?2.0:1.0)*(diabetes?1.8:1.0);
  mods.covid=1.0*(older?2.5:1.0)*(obese?1.5:1.0)*(diabetes?1.6:1.0);
  mods.influenza=1.0*(older?2.0:young?1.3:1.0)*(obese?1.3:1.0);
  mods.lumbar_radiculopathy=1.0*(male?1.3:1.0)*(age>30&&age<65?1.8:1.0)*(obese?1.4:1.0);
  mods.cauda_equina=1.0*(age>30&&age<60?1.5:1.0);
  mods.cellulitis=1.0*(diabetes?2.5:1.0)*(obese?1.5:1.0)*(older?1.4:1.0);
  mods.psoriasis=1.0*(age>15&&age<40?1.5:1.0)*(familyHistory?2.5:1.0)*(smoking?1.4:1.0);
  mods.acute_glaucoma=1.0*(age>50?2.5:1.0)*(female?1.3:1.0);

  return{mods,bmiCat};
}

export const PATTERNS = {
  hyperthyroidism:{name:"Hyperthyroidism / Graves",icd:"E05.0",base_prevalence:1.3,sprt_lr:2.8,risk:"moderate",triggers:["tremor","weight_loss","palpitations","heat_intolerance","sweating","anxiety","hair_loss","eye_changes","eye_bulging","frequent_bowel","insomnia","restlessness","increased_appetite"],required_any:["tremor","weight_loss","palpitations","heat_intolerance"],confirmatory:["tremor","weight_loss","palpitations"],routing_if_confirmed:"YELLOW",doctor_alert:"TSH + free T4 indicated. Three-symptom cluster (tremor + weight loss + palpitations) consistent with hyperthyroidism. Graves disease 60-80% of cases.",source:"AAFP 2025; ATA"},
  hypothyroidism:{name:"Hypothyroidism",icd:"E03.9",base_prevalence:4.6,sprt_lr:2.2,risk:"low",triggers:["fatigue","weight_gain","cold_intolerance","constipation","dry_skin","hair_loss","depression","slow_heart_rate","muscle_weakness","hoarse_voice","memory_problems","puffy_face","brittle_nails"],required_any:["fatigue","weight_gain","cold_intolerance","dry_skin"],confirmatory:["fatigue","weight_gain","cold_intolerance"],routing_if_confirmed:"YELLOW",doctor_alert:"TSH screening recommended. Hypothyroidism 5x more common in women. Pattern: fatigue + weight gain + cold intolerance.",source:"AAFP; ATA 2014"},
  diabetes_t2:{name:"Type 2 Diabetes",icd:"E11",base_prevalence:10.5,sprt_lr:3.1,risk:"moderate",triggers:["thirst","frequent_urination","fatigue","weight_loss","blurred_vision","tingling","slow_healing","hunger","frequent_infections","dark_skin_patches","numbness_feet","recurrent_thrush"],required_any:["thirst","frequent_urination","fatigue","weight_loss"],confirmatory:["thirst","frequent_urination","weight_loss"],routing_if_confirmed:"YELLOW",doctor_alert:"Classic triad (polyuria + polydipsia + fatigue/weight loss) highly suggestive of T2DM. Fasting glucose or HbA1c. ADA 2025.",source:"ADA Standards 2025"},
  diabetes_t1:{name:"Type 1 Diabetes",icd:"E10",base_prevalence:0.5,sprt_lr:3.8,risk:"high",triggers:["thirst","frequent_urination","weight_loss","fatigue","blurred_vision","abdominal_pain","nausea","fruity_breath","vomiting","rapid_onset"],required_any:["thirst","frequent_urination","weight_loss"],confirmatory:["thirst","frequent_urination","weight_loss"],routing_if_confirmed:"YELLOW",doctor_alert:"Rapid onset + younger age suggests T1DM vs T2DM. Urgent glucose + ketones. DKA risk.",source:"ADA 2025"},
  cushings:{name:"Cushing Syndrome",icd:"E24",base_prevalence:0.02,sprt_lr:3.2,risk:"moderate",triggers:["weight_gain","round_face","hump_back","stretch_marks","easy_bruising","high_blood_pressure","fatigue","depression","irregular_periods","muscle_weakness","acne","slow_healing"],required_any:["weight_gain","round_face","hump_back","stretch_marks"],confirmatory:["weight_gain","round_face","stretch_marks"],routing_if_confirmed:"YELLOW",doctor_alert:"Central obesity + facial rounding + purple striae: Cushing workup. 24h urine cortisol or overnight dexamethasone suppression.",source:"Endocrine Society 2022"},
  addisons:{name:"Adrenal Insufficiency (Addison's)",icd:"E27.1",base_prevalence:0.02,sprt_lr:3.5,risk:"high",triggers:["fatigue","weight_loss","low_blood_pressure","dizziness","nausea","vomiting","abdominal_pain","skin_darkening","salt_craving","muscle_weakness","depression"],required_any:["fatigue","skin_darkening","low_blood_pressure"],confirmatory:["fatigue","skin_darkening","weight_loss"],routing_if_confirmed:"YELLOW",doctor_alert:"Adrenal crisis risk. Morning cortisol + ACTH stimulation test. Salt craving + hyperpigmentation = classic Addison's.",source:"Endocrine Society 2016"},
  pcos:{name:"PCOS",icd:"E28.2",base_prevalence:8.0,sprt_lr:2.5,risk:"moderate",triggers:["irregular_periods","excess_hair","acne","weight_gain","thinning_hair","difficulty_conceiving","pelvic_pain","oily_skin","mood_changes"],required_any:["irregular_periods","excess_hair","acne"],confirmatory:["irregular_periods","excess_hair"],routing_if_confirmed:"YELLOW",doctor_alert:"Rotterdam criteria: 2 of 3 (irregular ovulation, hyperandrogenism, polycystic ovaries). Pelvic ultrasound + testosterone + LH/FSH.",source:"ESHRE/ASRM 2023"},
  acs:{name:"Acute Coronary Syndrome",icd:"I21",base_prevalence:19.0,sprt_lr:3.8,risk:"critical",triggers:["chest_pain","chest_tightness","chest_pressure","jaw_pain","left_arm_pain","shortness_of_breath","diaphoresis","nausea","back_pain","shoulder_pain","cold_sweat","dizziness"],required_any:["chest_pain","chest_tightness","chest_pressure","left_arm_pain"],confirmatory:["chest_pain","diaphoresis","shortness_of_breath"],routing_if_confirmed:"RED",doctor_alert:"ACS presentation. ECG + troponin immediately. TIMI score. Missed AMI 2.1% from ED.",source:"AHA/ACC 2021"},
  aortic_dissection:{name:"Aortic Dissection",icd:"I71.0",base_prevalence:0.4,sprt_lr:5.5,risk:"critical",triggers:["sudden_severe_chest_pain","tearing_pain","back_pain","pain_radiation_back","difference_in_arm_pulses","severe_chest_back_pain"],required_any:["sudden_severe_chest_pain","tearing_pain","back_pain"],confirmatory:["tearing_pain","back_pain"],routing_if_confirmed:"RED",doctor_alert:"Aortic dissection: sudden tearing pain sensitivity 84%. Emergency CT angiography. Mortality 1-2%/hour.",source:"ESC 2014; JACC"},
  heart_failure:{name:"Heart Failure",icd:"I50",base_prevalence:2.0,sprt_lr:3.5,risk:"high",triggers:["shortness_of_breath","leg_swelling","fatigue","orthopnea","waking_breathless","rapid_weight_gain","reduced_exercise","ankle_swelling","cough_lying_down"],required_any:["shortness_of_breath","leg_swelling"],confirmatory:["shortness_of_breath","leg_swelling","orthopnea"],routing_if_confirmed:"YELLOW",doctor_alert:"Framingham criteria: orthopnea + PND + leg edema. BNP + ECG + echo. Acute decompensation = emergency.",source:"ESC 2021; AHA 2024"},
  pe:{name:"Pulmonary Embolism",icd:"I26",base_prevalence:2.5,sprt_lr:4.2,risk:"critical",triggers:["shortness_of_breath","chest_pain","tachycardia","coughing_blood","recent_immobility","recent_surgery","leg_swelling_one_sided","low_oxygen","sudden_breathlessness"],required_any:["shortness_of_breath","chest_pain","coughing_blood"],confirmatory:["shortness_of_breath","tachycardia","low_oxygen"],routing_if_confirmed:"RED",doctor_alert:"Wells score. D-dimer if low prob; CT-PA if high. Emergency anticoagulation.",source:"ESC 2019"},
  stroke:{name:"Stroke / TIA",icd:"I64",base_prevalence:0.8,sprt_lr:5.8,risk:"critical",triggers:["facial_drooping","arm_weakness","speech_difficulty","sudden_headache","vision_change","confusion","numbness_one_side","dizziness_sudden","loss_of_balance","sudden_vision_loss"],required_any:["facial_drooping","arm_weakness","speech_difficulty","sudden_headache"],confirmatory:["facial_drooping","arm_weakness","speech_difficulty"],routing_if_confirmed:"RED",doctor_alert:"FAST positive. Thrombolysis window 4.5h. Call emergency immediately. No aspirin before imaging.",source:"AHA/ASA 2019"},
  hypertensive_crisis:{name:"Hypertensive Crisis",icd:"I16",base_prevalence:1.0,sprt_lr:3.8,risk:"critical",triggers:["severe_headache","chest_pain","shortness_of_breath","vision_change","nosebleed","confusion","nausea","vomiting","pulsating_headache"],required_any:["severe_headache","chest_pain","vision_change"],confirmatory:["severe_headache","vision_change","chest_pain"],routing_if_confirmed:"RED",doctor_alert:"BP >180/120. End-organ damage assessment: ECG, troponin, creatinine, fundoscopy. IV antihypertensive if symptomatic.",source:"ESC 2018"},
  afib:{name:"Atrial Fibrillation",icd:"I48",base_prevalence:2.0,sprt_lr:2.8,risk:"high",triggers:["palpitations","irregular_heartbeat","racing_heart","shortness_of_breath","fatigue","dizziness","chest_discomfort","reduced_exercise"],required_any:["palpitations","irregular_heartbeat","racing_heart"],confirmatory:["palpitations","irregular_heartbeat","shortness_of_breath"],routing_if_confirmed:"YELLOW",doctor_alert:"ECG urgently. CHA2DS2-VASc for stroke risk. Anticoagulation decision. Rate vs rhythm control.",source:"ESC 2020"},
  dvt:{name:"Deep Vein Thrombosis",icd:"I80.2",base_prevalence:1.5,sprt_lr:3.2,risk:"high",triggers:["leg_swelling_one_sided","leg_pain","leg_warmth","leg_redness","recent_immobility","recent_surgery","calf_pain","tenderness"],required_any:["leg_swelling_one_sided","leg_pain","leg_warmth"],confirmatory:["leg_swelling_one_sided","leg_pain","leg_redness"],routing_if_confirmed:"YELLOW",doctor_alert:"Wells DVT score. Doppler ultrasound. D-dimer if low probability. PE risk: anticoagulate if confirmed.",source:"ACCP 2016"},
  parkinsons:{name:"Parkinson Disease",icd:"G20",base_prevalence:0.3,sprt_lr:3.4,risk:"moderate",triggers:["tremor","stiffness","slow_movement","balance_problems","small_handwriting","loss_of_smell","sleep_disorder","constipation","soft_voice","masked_face","shuffling_gait"],required_any:["tremor","stiffness","slow_movement"],confirmatory:["tremor","stiffness","slow_movement"],routing_if_confirmed:"YELLOW",doctor_alert:"MDS criteria: bradykinesia + resting tremor or rigidity. Pill-rolling 4-6Hz tremor specific. Neurology referral.",source:"MDS Criteria 2015"},
  essential_tremor:{name:"Essential Tremor",icd:"G25.0",base_prevalence:4.0,sprt_lr:1.2,risk:"low",triggers:["tremor","tremor_with_action","head_tremor","voice_tremor","worsens_with_movement","improves_at_rest"],required_any:["tremor","tremor_with_action"],confirmatory:["tremor_with_action"],routing_if_confirmed:"GREEN",doctor_alert:"Action tremor vs resting tremor differentiates from Parkinson. Family history + alcohol responsiveness typical. Neurology if disabling.",source:"MDS; AAFP 2022"},
  migraine:{name:"Migraine",icd:"G43",base_prevalence:12.0,sprt_lr:1.8,risk:"low",triggers:["severe_headache","one_sided_headache","nausea","light_sensitivity","sound_sensitivity","aura","visual_disturbance","throbbing_headache","vomiting","worsens_with_activity"],required_any:["severe_headache","one_sided_headache"],confirmatory:["one_sided_headache","nausea","light_sensitivity"],routing_if_confirmed:"YELLOW",doctor_alert:"IHS criteria: 5+ attacks of unilateral throbbing 4-72h + nausea or photophobia. Rule out SAH if sudden onset worst-ever headache.",source:"IHS 2018"},
  meningitis:{name:"Meningitis",icd:"G03",base_prevalence:0.1,sprt_lr:5.2,risk:"critical",triggers:["severe_headache","neck_stiffness","fever","photophobia","vomiting","rash_non_blanching","confusion","sudden_onset_headache","jolt_sign"],required_any:["severe_headache","neck_stiffness","fever"],confirmatory:["fever","neck_stiffness","severe_headache"],routing_if_confirmed:"RED",doctor_alert:"Classic triad: fever + neck stiffness + altered consciousness. Non-blanching rash = meningococcal. Emergency IV antibiotics before LP.",source:"IDSA 2004; NICE NG240 2023"},
  ms:{name:"Multiple Sclerosis",icd:"G35",base_prevalence:0.3,sprt_lr:2.9,risk:"high",triggers:["vision_loss_one_eye","double_vision","numbness","tingling","weakness","balance_problems","fatigue","bladder_problems","cognitive_problems","heat_worsens"],required_any:["vision_loss_one_eye","numbness","weakness","balance_problems"],confirmatory:["vision_loss_one_eye","numbness","balance_problems"],routing_if_confirmed:"YELLOW",doctor_alert:"McDonald criteria. MRI brain + spine. Optic neuritis = classic first presentation. Neurology urgently.",source:"McDonald 2017; ECTRIMS"},
  epilepsy:{name:"Epilepsy / Seizure",icd:"G40",base_prevalence:1.2,sprt_lr:4.1,risk:"high",triggers:["seizure","convulsion","loss_of_consciousness","blank_staring","jerking_movements","confusion_after_event","tongue_biting","urinary_incontinence","post_ictal"],required_any:["seizure","convulsion","loss_of_consciousness"],confirmatory:["seizure","convulsion","jerking_movements"],routing_if_confirmed:"RED",doctor_alert:"New seizure = emergency workup. EEG + MRI. Rule out structural, metabolic, toxic causes. Status epilepticus = immediate IV benzodiazepine.",source:"ILAE 2017"},
  tension_headache:{name:"Tension-Type Headache",icd:"G44.2",base_prevalence:38.0,sprt_lr:0.8,risk:"low",triggers:["bilateral_headache","pressure_headache","band_around_head","mild_moderate_pain","stress_related","no_nausea","neck_muscle_tension"],required_any:["bilateral_headache","pressure_headache","band_around_head"],confirmatory:["bilateral_headache","pressure_headache"],routing_if_confirmed:"GREEN",doctor_alert:"Differentiate from migraine: bilateral, pressing/tightening, mild-moderate, no nausea. NSAIDs first-line. Rule out secondary causes if new pattern.",source:"IHS 2018"},
  lupus:{name:"Systemic Lupus (SLE)",icd:"M32.9",base_prevalence:0.1,sprt_lr:3.6,risk:"high",triggers:["butterfly_rash","joint_pain","fatigue","fever","hair_loss","mouth_sores","sun_sensitivity","chest_pain_pleurisy","kidney_symptoms","photosensitivity","rash_after_sun"],required_any:["butterfly_rash","joint_pain","sun_sensitivity"],confirmatory:["butterfly_rash","joint_pain","fatigue"],routing_if_confirmed:"YELLOW",doctor_alert:"EULAR/ACR 2019: ANA >= 1:80 sensitivity 98%. Multi-organ. Rheumatology referral. SLE mainly women 15-45.",source:"EULAR/ACR 2019"},
  ra:{name:"Rheumatoid Arthritis",icd:"M06.9",base_prevalence:1.0,sprt_lr:2.9,risk:"moderate",triggers:["joint_pain","morning_stiffness","joint_swelling","symmetric_joints","fatigue","joint_warmth","grip_weakness","small_joint_involvement","wrist_pain"],required_any:["joint_pain","morning_stiffness"],confirmatory:["joint_pain","morning_stiffness","symmetric_joints"],routing_if_confirmed:"YELLOW",doctor_alert:"ACR/EULAR 2010 criteria. RF + anti-CCP. Early DMARD prevents joint destruction. Rheumatology referral.",source:"ACR/EULAR 2010"},
  gout:{name:"Gout",icd:"M10",base_prevalence:3.9,sprt_lr:2.2,risk:"moderate",triggers:["joint_pain","big_toe_pain","sudden_joint_pain","red_swollen_joint","joint_warm","pain_at_night","tophi","recurrent_attacks"],required_any:["big_toe_pain","sudden_joint_pain","red_swollen_joint"],confirmatory:["big_toe_pain","sudden_joint_pain"],routing_if_confirmed:"YELLOW",doctor_alert:"Serum uric acid + joint aspiration if diagnostic uncertainty. NSAIDs or colchicine first-line. Allopurinol for prophylaxis.",source:"ACR 2020"},
  fibromyalgia:{name:"Fibromyalgia",icd:"M79.3",base_prevalence:2.0,sprt_lr:1.8,risk:"moderate",triggers:["widespread_pain","fatigue","sleep_problems","cognitive_difficulties","tender_points","headache","ibs_symptoms","depression","anxiety","pain_all_over"],required_any:["widespread_pain","fatigue","tender_points"],confirmatory:["widespread_pain","fatigue","sleep_problems"],routing_if_confirmed:"YELLOW",doctor_alert:"ACR 2010 criteria: widespread pain index ≥7 + symptom severity ≥5. Rule out inflammatory arthritis, thyroid disease. Multidisciplinary management.",source:"ACR 2016"},
  osteoporosis:{name:"Osteoporosis",icd:"M81",base_prevalence:10.0,sprt_lr:1.4,risk:"moderate",triggers:["back_pain","height_loss","fracture_low_trauma","stooped_posture","fragility_fracture","hip_pain","spine_pain"],required_any:["back_pain","height_loss","fracture_low_trauma"],confirmatory:["height_loss","fracture_low_trauma"],routing_if_confirmed:"YELLOW",doctor_alert:"DEXA scan. FRAX score. Risk: postmenopausal female, age >65, low BMI, smoking, steroids, family history. Calcium + Vit D + bisphosphonates.",source:"NOF 2023; USPSTF"},
  appendicitis:{name:"Appendicitis",icd:"K37",base_prevalence:5.3,sprt_lr:2.1,risk:"high",triggers:["abdominal_pain","right_lower_pain","nausea","vomiting","fever","pain_worsens_moving","loss_of_appetite","rebound_tenderness","pain_moves_to_right"],required_any:["abdominal_pain","right_lower_pain"],confirmatory:["right_lower_pain","nausea","fever"],routing_if_confirmed:"YELLOW",doctor_alert:"Alvarado score. Peritoneal signs = surgical emergency. WBC >10k LR+ 2.1. CT abdomen. Misdiagnosed 33% in women of childbearing age.",source:"AAFP 2008"},
  ibd:{name:"IBD (Crohn / UC)",icd:"K50",base_prevalence:0.4,sprt_lr:2.5,risk:"moderate",triggers:["chronic_diarrhea","blood_in_stool","abdominal_pain","weight_loss","fatigue","joint_pain","skin_rash","mouth_sores","night_sweats","rectal_bleeding","urgency"],required_any:["chronic_diarrhea","blood_in_stool","abdominal_pain"],confirmatory:["chronic_diarrhea","blood_in_stool","weight_loss"],routing_if_confirmed:"YELLOW",doctor_alert:"Fecal calprotectin + colonoscopy referral. Urgent if severe bleeding, toxic megacolon, or systemic deterioration.",source:"ACG IBD 2019"},
  celiac:{name:"Celiac Disease",icd:"K90.0",base_prevalence:1.0,sprt_lr:2.3,risk:"moderate",triggers:["diarrhea","bloating","weight_loss","fatigue","anemia","bone_pain","skin_rash","mouth_sores","gluten_triggered","abdominal_cramps","pale_stool"],required_any:["diarrhea","bloating","fatigue"],confirmatory:["diarrhea","weight_loss","fatigue"],routing_if_confirmed:"YELLOW",doctor_alert:"tTG-IgA serology (sensitivity 98%) — test BEFORE starting gluten-free diet. Duodenal biopsy to confirm. HLA-DQ2/DQ8.",source:"ACG Celiac 2023"},
  peptic_ulcer:{name:"Peptic Ulcer Disease",icd:"K25",base_prevalence:4.0,sprt_lr:1.6,risk:"moderate",triggers:["burning_stomach_pain","hunger_pain","pain_relieved_by_eating","nausea","vomiting","bloating","black_stool","nsaid_use","epigastric_pain"],required_any:["burning_stomach_pain","hunger_pain","epigastric_pain"],confirmatory:["burning_stomach_pain","pain_relieved_by_eating"],routing_if_confirmed:"YELLOW",doctor_alert:"H.pylori test + treat. Black/tarry stools = upper GI bleed, urgent endoscopy. Stop NSAIDs. PPI empiric.",source:"ACG 2017"},
  gerd:{name:"GERD / Acid Reflux",icd:"K21",base_prevalence:20.0,sprt_lr:1.4,risk:"low",triggers:["heartburn","acid_reflux","chest_burning","regurgitation","difficulty_swallowing","worse_lying_down","worse_after_eating","sour_taste","chronic_cough"],required_any:["heartburn","acid_reflux","chest_burning"],confirmatory:["heartburn","regurgitation","worse_lying_down"],routing_if_confirmed:"GREEN",doctor_alert:"PPI trial 4-8 weeks. Alarm symptoms (dysphagia, weight loss, bleeding) → urgent endoscopy. Barrett's esophagus surveillance if chronic.",source:"ACG GERD 2022"},
  bowel_obstruction:{name:"Bowel Obstruction",icd:"K56",base_prevalence:2.5,sprt_lr:3.2,risk:"critical",triggers:["severe_abdominal_pain","abdominal_distension","vomiting","no_bowel_movement","no_flatus","colicky_pain","nausea","vomiting_fecal"],required_any:["severe_abdominal_pain","no_bowel_movement","abdominal_distension"],confirmatory:["severe_abdominal_pain","no_bowel_movement","abdominal_distension"],routing_if_confirmed:"RED",doctor_alert:"Obstruction triad: pain + distension + obstipation. Upright AXR + CT. NPO + NGT + surgery consult. Strangulation = emergency.",source:"AAFP; StatPearls"},
  cholecystitis:{name:"Cholecystitis / Gallstones",icd:"K81",base_prevalence:3.0,sprt_lr:2.8,risk:"high",triggers:["right_upper_pain","pain_after_fatty_meal","nausea","vomiting","fever","pain_radiates_shoulder","right_shoulder_pain","jaundice","clay_stool"],required_any:["right_upper_pain","pain_after_fatty_meal"],confirmatory:["right_upper_pain","nausea","fever"],routing_if_confirmed:"YELLOW",doctor_alert:"Murphy's sign. Abdominal ultrasound. Acute cholecystitis = surgical referral. ERCP if choledocholithiasis suspected.",source:"WSES 2020"},
  pancreatitis:{name:"Acute Pancreatitis",icd:"K85",base_prevalence:0.5,sprt_lr:3.5,risk:"high",triggers:["severe_abdominal_pain","pain_radiates_back","nausea","vomiting","fever","abdominal_tenderness","worse_lying_flat","better_leaning_forward","alcohol_history"],required_any:["severe_abdominal_pain","pain_radiates_back"],confirmatory:["severe_abdominal_pain","nausea","pain_radiates_back"],routing_if_confirmed:"YELLOW",doctor_alert:"Lipase >3x ULN. CT abdomen for severity. NPO + IV fluids + analgesia. Gallstone = ERCP. Alcohol = abstinence counseling.",source:"ACG 2013"},
  ibs:{name:"Irritable Bowel Syndrome",icd:"K58",base_prevalence:11.0,sprt_lr:1.2,risk:"low",triggers:["abdominal_pain","bloating","diarrhea","constipation","alternating_bowel","pain_relieved_by_defecation","urgency","mucus_in_stool"],required_any:["abdominal_pain","bloating"],confirmatory:["abdominal_pain","alternating_bowel","pain_relieved_by_defecation"],routing_if_confirmed:"GREEN",doctor_alert:"Rome IV criteria. Exclude organic pathology (IBD, celiac, colorectal cancer). Low-FODMAP diet trial. No alarm features required for diagnosis.",source:"ACG IBS 2021"},
  copd:{name:"COPD",icd:"J44",base_prevalence:6.5,sprt_lr:2.4,risk:"moderate",triggers:["chronic_cough","progressive_breathlessness","sputum_production","wheezing","smoking_history","reduced_exercise","barrel_chest","morning_cough"],required_any:["chronic_cough","progressive_breathlessness"],confirmatory:["chronic_cough","progressive_breathlessness","smoking_history"],routing_if_confirmed:"YELLOW",doctor_alert:"Spirometry: FEV1/FVC <0.70 post-bronchodilator. GOLD staging. Smoking cessation first priority.",source:"GOLD 2024"},
  asthma:{name:"Asthma",icd:"J45",base_prevalence:8.0,sprt_lr:2.1,risk:"moderate",triggers:["wheezing","breathlessness","chest_tightness","cough","worse_at_night","exercise_triggered","allergen_triggered","variable_symptoms","seasonal_worsening"],required_any:["wheezing","breathlessness","chest_tightness"],confirmatory:["wheezing","breathlessness","exercise_triggered"],routing_if_confirmed:"YELLOW",doctor_alert:"GINA 2024: spirometry + reversibility testing. SpO2 <92% = emergency. Peak flow monitoring.",source:"GINA 2024"},
  pneumonia:{name:"Pneumonia",icd:"J18",base_prevalence:1.5,sprt_lr:3.2,risk:"high",triggers:["fever","cough","sputum","shortness_of_breath","chest_pain","fatigue","sweating","rigors","confusion_elderly"],required_any:["fever","cough","shortness_of_breath"],confirmatory:["fever","cough","shortness_of_breath"],routing_if_confirmed:"YELLOW",doctor_alert:"CURB-65 score. CXR. Blood cultures + sputum. Elderly: confusion may be only sign. Atypical: Legionella, Mycoplasma.",source:"BTS 2009; IDSA/ATS 2019"},
  depression:{name:"Major Depression",icd:"F32",base_prevalence:8.3,sprt_lr:2.0,risk:"moderate",triggers:["persistent_sadness","loss_of_interest","fatigue","sleep_changes","appetite_changes","concentration_problems","hopelessness","worthlessness","crying","social_withdrawal","suicidal_thoughts"],required_any:["persistent_sadness","loss_of_interest"],confirmatory:["persistent_sadness","loss_of_interest","fatigue"],routing_if_confirmed:"YELLOW",doctor_alert:"PHQ-9 recommended. Suicidal ideation = emergency psychiatric assessment. ≥2 weeks consistent with MDD. SSRI + therapy first-line.",source:"DSM-5-TR; APA 2023"},
  anxiety:{name:"Anxiety / Panic Disorder",icd:"F41",base_prevalence:19.1,sprt_lr:0.6,risk:"low",triggers:["racing_heart","chest_tightness","shortness_of_breath","dizziness","trembling","sweating","fear","avoidance","excessive_worry","muscle_tension","panic_attacks"],required_any:["racing_heart","chest_tightness","excessive_worry"],confirmatory:["racing_heart","chest_tightness","shortness_of_breath"],routing_if_confirmed:"GREEN",doctor_alert:"Rule out cardiac cause first (ECG). GAD-7 + PHQ-4. CBT + SSRI first-line. Panic disorder requires ruling out organic cause.",source:"NIMH 2024"},
  bipolar:{name:"Bipolar Disorder",icd:"F31",base_prevalence:2.8,sprt_lr:2.2,risk:"moderate",triggers:["mood_swings","elevated_mood","decreased_sleep","grandiosity","rapid_speech","impulsivity","depression_episodes","risky_behavior","racing_thoughts","irritability"],required_any:["mood_swings","elevated_mood","decreased_sleep"],confirmatory:["elevated_mood","decreased_sleep","rapid_speech"],routing_if_confirmed:"YELLOW",doctor_alert:"MDQ screening. Rule out substance use, thyroid, medications. Mood stabilizer (lithium/valproate). Psychiatry referral.",source:"DSM-5-TR; CANMAT 2023"},
  ptsd:{name:"PTSD",icd:"F43.1",base_prevalence:3.5,sprt_lr:2.0,risk:"moderate",triggers:["flashbacks","nightmares","avoidance","hypervigilance","emotional_numbing","sleep_problems","irritability","memory_problems","trauma_history"],required_any:["flashbacks","nightmares","avoidance","trauma_history"],confirmatory:["flashbacks","nightmares","hypervigilance"],routing_if_confirmed:"YELLOW",doctor_alert:"PCL-5 screening. Trauma-focused CBT or EMDR first-line. SSRIs (sertraline, paroxetine) FDA-approved. Assess for suicidality.",source:"VA/DoD 2023; APA"},
  ckd:{name:"Chronic Kidney Disease",icd:"N18",base_prevalence:15.0,sprt_lr:1.8,risk:"moderate",triggers:["fatigue","leg_swelling","foamy_urine","reduced_urine","back_pain","itching","nausea","loss_of_appetite","pale_skin","muscle_cramps","high_blood_pressure"],required_any:["fatigue","leg_swelling","foamy_urine"],confirmatory:["fatigue","leg_swelling","foamy_urine"],routing_if_confirmed:"YELLOW",doctor_alert:"eGFR + urine albumin-creatinine ratio. Nephrology if eGFR <30. CDC: 90% of CKD patients unaware.",source:"KDIGO 2022"},
  kidney_stones:{name:"Nephrolithiasis (Kidney Stones)",icd:"N20",base_prevalence:3.0,sprt_lr:3.5,risk:"high",triggers:["severe_flank_pain","colicky_pain","blood_in_urine","nausea","vomiting","pain_radiates_groin","urinary_urgency","painful_urination","fever"],required_any:["severe_flank_pain","colicky_pain","blood_in_urine"],confirmatory:["severe_flank_pain","colicky_pain","blood_in_urine"],routing_if_confirmed:"YELLOW",doctor_alert:"CT KUB (non-contrast) gold standard. Analgesics + IV fluids. Stones >6mm usually need urological intervention. Fever + stone = urological emergency.",source:"EAU 2022"},
  uti:{name:"Urinary Tract Infection",icd:"N39.0",base_prevalence:5.0,sprt_lr:2.1,risk:"moderate",triggers:["painful_urination","frequent_urination","urgency","cloudy_urine","blood_in_urine","lower_abdominal_pain","burning_urination","strong_urine_smell"],required_any:["painful_urination","frequent_urination","burning_urination"],confirmatory:["painful_urination","frequent_urination","urgency"],routing_if_confirmed:"YELLOW",doctor_alert:"Urine dipstick + MSU. Nitrofurantoin or trimethoprim first-line uncomplicated UTI. Pyelonephritis (fever + flank pain) = ciprofloxacin.",source:"EAU 2023; PHE"},
  pyelonephritis:{name:"Pyelonephritis",icd:"N10",base_prevalence:0.5,sprt_lr:3.2,risk:"high",triggers:["fever","flank_pain","back_pain","painful_urination","frequent_urination","nausea","vomiting","rigors","confusion"],required_any:["fever","flank_pain"],confirmatory:["fever","flank_pain","painful_urination"],routing_if_confirmed:"YELLOW",doctor_alert:"MSU + blood cultures. IV antibiotics if severe. CT if no response in 48h (rule out abscess/obstruction). Hospitalise if septic.",source:"EAU 2023"},
  nafld:{name:"Fatty Liver (NAFLD/MASLD)",icd:"K76.0",base_prevalence:25.0,sprt_lr:1.5,risk:"moderate",triggers:["fatigue","right_upper_pain","abdominal_fullness","elevated_liver_enzymes","obesity","diabetes","metabolic_syndrome","no_alcohol"],required_any:["fatigue","right_upper_pain","obesity"],confirmatory:["fatigue","obesity","diabetes"],routing_if_confirmed:"YELLOW",doctor_alert:"FIB-4 index (ADA 2025 for all T2DM). Liver ultrasound. Lifestyle modification primary treatment. NASH progression to cirrhosis risk.",source:"ADA 2025; AASLD 2023"},
  anemia:{name:"Anemia",icd:"D64.9",base_prevalence:5.6,sprt_lr:1.9,risk:"moderate",triggers:["fatigue","pale_skin","breathlessness","dizziness","cold_hands","palpitations","brittle_nails","pica","pale_gums","headache","weakness"],required_any:["fatigue","pale_skin","breathlessness"],confirmatory:["fatigue","pale_skin","dizziness"],routing_if_confirmed:"YELLOW",doctor_alert:"CBC with differential. Iron deficiency most common. Rule out GI bleed. B12/folate if macrocytic. WHO: 24.8% global prevalence.",source:"WHO 2023"},
  sleep_apnea:{name:"Obstructive Sleep Apnea",icd:"G47.3",base_prevalence:9.0,sprt_lr:1.9,risk:"moderate",triggers:["loud_snoring","witnessed_apnea","daytime_sleepiness","morning_headache","frequent_waking","obesity","large_neck","hypertension","gasping_sleep","dry_mouth"],required_any:["loud_snoring","daytime_sleepiness"],confirmatory:["loud_snoring","witnessed_apnea","daytime_sleepiness"],routing_if_confirmed:"YELLOW",doctor_alert:"STOP-BANG score. Polysomnography referral. High risk: obesity + HTN + male. Untreated OSA increases CVD risk 2-3x.",source:"AASM 2023"},
  cancer_red_flags:{name:"Cancer Red Flags",icd:"Z12",base_prevalence:0.5,sprt_lr:3.2,risk:"high",triggers:["unexplained_weight_loss","persistent_fatigue","unexplained_bleeding","persistent_cough","lump","change_in_bowel","difficulty_swallowing","night_sweats","bone_pain","blood_in_urine","blood_in_stool"],required_any:["unexplained_weight_loss","unexplained_bleeding","lump","persistent_cough"],confirmatory:["unexplained_weight_loss","persistent_fatigue"],routing_if_confirmed:"YELLOW",doctor_alert:"NICE NG12 2015 criteria. 2-week urgent cancer referral pathway. Specify symptom pattern for targeted workup.",source:"NICE NG12 2015"},
  ectopic_pregnancy:{name:"Ectopic Pregnancy",icd:"O00",base_prevalence:1.2,sprt_lr:4.5,risk:"critical",triggers:["abdominal_pain","pelvic_pain","missed_period","vaginal_bleeding","shoulder_pain","dizziness","fainting","positive_pregnancy_test"],required_any:["pelvic_pain","missed_period","vaginal_bleeding"],confirmatory:["pelvic_pain","missed_period"],routing_if_confirmed:"RED",doctor_alert:"MUST exclude in ALL females of reproductive age with abdominal/pelvic pain. Urine beta-hCG immediately. Ruptured ectopic = hemorrhagic shock.",source:"ACOG 2023"},
  sepsis:{name:"Sepsis",icd:"A41.9",base_prevalence:0.3,sprt_lr:4.9,risk:"critical",triggers:["high_fever","confusion","rapid_breathing","rapid_heart_rate","suspected_infection","extreme_fatigue","mottled_skin","not_urinating","very_cold","low_blood_pressure"],required_any:["high_fever","confusion","rapid_breathing"],confirmatory:["high_fever","rapid_heart_rate","confusion"],routing_if_confirmed:"RED",doctor_alert:"qSOFA ≥2. Sepsis-3. Hour-1 bundle: blood cultures, lactate, IV fluids, antibiotics. Mortality +7% per hour of delay.",source:"Surviving Sepsis 2021"},
  covid:{name:"COVID-19",icd:"U07.1",base_prevalence:2.0,sprt_lr:2.5,risk:"moderate",triggers:["fever","cough","shortness_of_breath","loss_of_smell","loss_of_taste","fatigue","body_aches","sore_throat","headache","diarrhea"],required_any:["fever","cough","loss_of_smell","loss_of_taste"],confirmatory:["fever","cough","loss_of_smell"],routing_if_confirmed:"YELLOW",doctor_alert:"RAT or PCR. High-risk patients (age >65, immunocompromised, comorbidities): antivirals within 5 days. Isolation guidance.",source:"WHO 2023; CDC"},
  influenza:{name:"Influenza",icd:"J11",base_prevalence:5.0,sprt_lr:2.0,risk:"low",triggers:["fever","body_aches","headache","fatigue","dry_cough","sore_throat","runny_nose","sudden_onset","chills"],required_any:["fever","body_aches","sudden_onset","sore_throat","cough","runny_nose"],confirmatory:["fever","body_aches","dry_cough"],routing_if_confirmed:"GREEN",doctor_alert:"Rapid flu test. Oseltamivir within 48h for high-risk. Annual vaccination. Secondary bacterial pneumonia risk.",source:"CDC; IDSA 2018"},
  lumbar_radiculopathy:{name:"Lumbar Disc / Radiculopathy",icd:"M54.4",base_prevalence:5.0,sprt_lr:3.0,risk:"moderate",triggers:["lower_back_pain","leg_pain","sciatica","numbness_leg","tingling_leg","weakness_leg","pain_radiates_leg","worse_sitting","better_walking","straight_leg_raise"],required_any:["lower_back_pain","leg_pain","sciatica"],confirmatory:["lower_back_pain","leg_pain","numbness_leg"],routing_if_confirmed:"YELLOW",doctor_alert:"SLR test sensitivity 80%. MRI if neurological deficit or red flags. Conservative: physio + NSAIDs. Surgery if cauda equina.",source:"NICE NG59; SPINE"},
  cauda_equina:{name:"Cauda Equina Syndrome",icd:"G83.4",base_prevalence:0.01,sprt_lr:6.0,risk:"critical",triggers:["lower_back_pain","saddle_anesthesia","bladder_dysfunction","bowel_dysfunction","bilateral_leg_weakness","sexual_dysfunction","urinary_retention","leg_numbness"],required_any:["saddle_anesthesia","bladder_dysfunction","urinary_retention"],confirmatory:["saddle_anesthesia","bladder_dysfunction","lower_back_pain"],routing_if_confirmed:"RED",doctor_alert:"SURGICAL EMERGENCY. MRI immediately. Decompression within 24-48h critical for recovery. Do not delay.",source:"NICE; BASS"},
  psoriasis:{name:"Psoriasis",icd:"L40",base_prevalence:2.0,sprt_lr:1.8,risk:"low",triggers:["red_plaques","silver_scales","itchy_skin","skin_patches","scalp_involvement","nail_changes","joint_pain","elbow_knee_rash"],required_any:["red_plaques","silver_scales","skin_patches"],confirmatory:["red_plaques","silver_scales"],routing_if_confirmed:"GREEN",doctor_alert:"PASI score. Dermatology if moderate-severe. Psoriatic arthritis in 30%: joint pain + psoriasis = rheumatology referral. Biologics for severe.",source:"BAD; AAD 2020"},
  acute_glaucoma:{name:"Acute Angle-Closure Glaucoma",icd:"H40.2",base_prevalence:0.1,sprt_lr:4.5,risk:"critical",triggers:["eye_pain","sudden_vision_loss","halos_around_lights","red_eye","headache","nausea","vomiting","blurred_vision"],required_any:["eye_pain","sudden_vision_loss","halos_around_lights"],confirmatory:["eye_pain","sudden_vision_loss","halos_around_lights"],routing_if_confirmed:"RED",doctor_alert:"Ophthalmic emergency. IOP measurement. IV acetazolamide + topical pressure-lowering drops. Ophthalmology immediately.",source:"AAO 2020"},
  head_injury:{name:"Head Injury / Concussion (mTBI)",icd:"S06.0",base_prevalence:1.2,sprt_lr:3.0,risk:"high",triggers:["head_trauma","headache","dizziness","nausea","brief_confusion","memory_gap","loss_of_consciousness","repeated_vomiting","seizure_after_injury"],required_any:["head_trauma"],confirmatory:["head_trauma","brief_confusion","memory_gap"],routing_if_confirmed:"YELLOW",doctor_alert:"Canadian CT Head Rule governs imaging. LOC, repeated vomiting, post-injury seizure, GCS drop, anticoagulant use = ED. Observe 24h for deterioration.",source:"Canadian CT Head Rule"},
  fracture_suspect:{name:"Suspected Fracture",icd:"T14.2",base_prevalence:1.5,sprt_lr:3.2,risk:"high",triggers:["injury_mechanism","deformity","unable_bear_weight","severe_swelling","heard_snap","limited_motion","open_wound","limb_numb_pale","bruising"],required_any:["injury_mechanism","deformity","heard_snap","unable_bear_weight"],confirmatory:["deformity","heard_snap","unable_bear_weight"],routing_if_confirmed:"YELLOW",doctor_alert:"Ottawa rules guide X-ray decision. Open wound over fracture site or neurovascular compromise (numb/pale/cold limb) = surgical emergency.",source:"Ottawa Rules"},
  sprain_strain:{name:"Sprain / Strain",icd:"S93.4",base_prevalence:6.0,sprt_lr:2.0,risk:"low",triggers:["injury_mechanism","joint_swelling","pain_on_movement","bruising","twisted_joint"],required_any:["injury_mechanism","twisted_joint"],confirmatory:["twisted_joint","joint_swelling"],routing_if_confirmed:"GREEN",doctor_alert:"RICE protocol. Ottawa criteria negative with partial weight-bearing supports conservative care. Re-assess at 72h if not improving.",source:"Ottawa Rules"},
  laceration:{name:"Laceration / Open Wound",icd:"S61.9",base_prevalence:2.5,sprt_lr:2.8,risk:"moderate",triggers:["open_cut","bleeding","gaping_wound","deep_cut","bleeding_uncontrolled","numb_below_cut"],required_any:["open_cut","bleeding"],confirmatory:["gaping_wound","deep_cut"],routing_if_confirmed:"YELLOW",doctor_alert:"Closure window ~6-12h (face up to 24h). Uncontrolled bleeding, tendon/nerve signs (distal numbness, loss of motion) = ED. Check tetanus status.",source:"ACEP"},
  cellulitis:{name:"Cellulitis",icd:"L03.9",base_prevalence:1.8,sprt_lr:3.5,risk:"high",triggers:["spreading_redness","warm_skin","skin_pain","skin_swelling","fever","red_streaks","chills"],required_any:["spreading_redness","warm_skin"],confirmatory:["spreading_redness","warm_skin"],routing_if_confirmed:"YELLOW",doctor_alert:"Mark borders to track spread. Fever, red streaks (lymphangitis), rapid progression or immunocompromise = IV antibiotics / ED. Rule out DVT in lower limb.",source:"IDSA 2014"},
  urticaria_allergy:{name:"Urticaria / Allergic Reaction",icd:"L50.9",base_prevalence:4.0,sprt_lr:2.2,risk:"moderate",triggers:["itchy_welts","hives","rash_after_exposure","skin_swelling","lip_face_swelling","throat_tightness","breathing_difficulty_allergy"],required_any:["itchy_welts","hives","rash_after_exposure"],confirmatory:["itchy_welts","hives"],routing_if_confirmed:"GREEN",doctor_alert:"Antihistamines first-line. ANY airway involvement (lip/tongue/throat swelling, stridor, wheeze) = anaphylaxis pathway: epinephrine + ED.",source:"WAO 2020"},
  contact_dermatitis:{name:"Contact Dermatitis / Eczema Flare",icd:"L23.9",base_prevalence:5.0,sprt_lr:1.8,risk:"low",triggers:["itchy_rash","dry_scaly_patches","rash_after_exposure","localized_redness"],required_any:["itchy_rash","localized_redness"],confirmatory:["rash_after_exposure","dry_scaly_patches"],routing_if_confirmed:"GREEN",doctor_alert:"Identify and remove trigger. Topical steroids + emollients. Weeping, honey-colored crust or fever suggests secondary infection.",source:"AAD"},
  shingles:{name:"Herpes Zoster (Shingles)",icd:"B02.9",base_prevalence:0.8,sprt_lr:5.0,risk:"high",triggers:["one_sided_band_rash","burning_pain_before_rash","blisters_cluster","skin_pain","rash_near_eye","fever"],required_any:["one_sided_band_rash","blisters_cluster"],confirmatory:["one_sided_band_rash","burning_pain_before_rash"],routing_if_confirmed:"YELLOW",doctor_alert:"Antivirals most effective <72h from rash onset. Ophthalmic involvement (rash near eye / nose tip, Hutchinson sign) is sight-threatening: urgent ophthalmology.",source:"CDC"},
  conjunctivitis:{name:"Conjunctivitis",icd:"H10.9",base_prevalence:4.5,sprt_lr:2.0,risk:"low",triggers:["red_eye","eye_discharge","gritty_feeling","itchy_eyes","crusted_lashes","watery_eyes"],required_any:["red_eye"],confirmatory:["eye_discharge","crusted_lashes"],routing_if_confirmed:"GREEN",doctor_alert:"Mostly viral and self-limited. True pain (not grit), photophobia, vision change or contact-lens wear = urgent evaluation (keratitis risk).",source:"AAO"},
  corneal_abrasion:{name:"Corneal Abrasion / Foreign Body",icd:"S05.0",base_prevalence:1.5,sprt_lr:3.0,risk:"moderate",triggers:["foreign_body_sensation","eye_pain","tearing","light_sensitivity","red_eye","pain_on_blinking"],required_any:["foreign_body_sensation","pain_on_blinking"],confirmatory:["foreign_body_sensation","pain_on_blinking"],routing_if_confirmed:"YELLOW",doctor_alert:"Fluorescein exam. Never patch contact-lens-related abrasions (pseudomonas). Retained foreign body, rust ring or penetrating mechanism = ophthalmology.",source:"AAO"},
  retinal_detachment:{name:"Retinal Detachment / Acute Vision Loss",icd:"H33.2",base_prevalence:0.1,sprt_lr:6.0,risk:"critical",triggers:["sudden_floaters","flashes_of_light","curtain_vision","painless_vision_loss","sudden_vision_loss"],required_any:["curtain_vision","sudden_vision_loss","painless_vision_loss","sudden_floaters"],confirmatory:["curtain_vision","painless_vision_loss"],routing_if_confirmed:"RED",doctor_alert:"Time-critical: macula-on detachment is a surgical emergency. Curtain/shadow, photopsia with floater shower, painless monocular loss = same-day retina service. Sudden total loss: consider CRAO (stroke pathway).",source:"AAO 2022"},
};

export const TR_TRIGGER_MAP = {
  "bulantı":"nausea","mide bulantısı":"nausea","kusma":"vomiting","ateş":"fever","yorgunluk":"fatigue",
  "halsizlik":"fatigue","baş ağrısı":"severe_headache","şiddetli baş ağrısı":"severe_headache",
  "ani baş ağrısı":"sudden_headache","baş dönmesi":"dizziness","sersemlik":"dizziness","zonklayan baş ağrısı":"throbbing_headache",
  "titreme":"tremor","terleme":"sweating","gece terlemesi":"night_sweats","üşüme":"chills","titiz titreme":"rigors",
  "çarpıntı":"palpitations","kalp çarpıntısı":"palpitations","kalp atışı hızlı":"racing_heart","düzensiz kalp":"irregular_heartbeat",
  "nefes darlığı":"shortness_of_breath","nefes alamıyorum":"shortness_of_breath","nefes almakta güçlük":"breathlessness",
  "ani nefes darlığı":"sudden_breathlessness","egzersizde nefes darlığı":"exercise_triggered",
  "bacak şişliği":"leg_swelling","ayak şişliği":"leg_swelling","tek bacak şişliği":"leg_swelling_one_sided",
  "topuk şişliği":"ankle_swelling","göğüs ağrısı":"chest_pain","göğüste sıkışma":"chest_tightness",
  "göğüste baskı":"chest_pressure","sol kol ağrısı":"left_arm_pain","çene ağrısı":"jaw_pain","omuz ağrısı":"shoulder_pain",
  "sırt ağrısı":"back_pain","bel ağrısı":"lower_back_pain","boyun ağrısı":"neck_pain",
  "karın ağrısı":"abdominal_pain","karın ağrısı sağ alt":"right_lower_pain","sağ alt karın ağrısı":"right_lower_pain",
  "kasık ağrısı":"pelvic_pain","pelvik ağrı":"pelvic_pain","kasık":"pelvic_pain",
  "kilo kaybı":"weight_loss","kilo veriyorum":"weight_loss","açıklanamaz kilo kaybı":"unexplained_weight_loss",
  "kilo aldım":"weight_gain","kilo alıyorum":"weight_gain","iştah kaybı":"loss_of_appetite","iştahsızlık":"loss_of_appetite",
  "susuzluk":"thirst","çok su içiyorum":"thirst","sık idrara çıkıyorum":"frequent_urination","sık tuvalet":"frequent_urination",
  "bulanık görme":"blurred_vision","görme bozukluğu":"vision_change","ani görme kaybı":"sudden_vision_loss",
  "bir gözde görme kaybı":"vision_loss_one_eye","çift görme":"double_vision","ışık hassasiyeti":"light_sensitivity",
  "fotofobiyi":"photophobia","gözde ağrı":"eye_pain","gözde kızarıklık":"red_eye","halo görme":"halos_around_lights",
  "göz fışkırması":"eye_bulging","gözler dışarı çıkıyor":"eye_bulging",
  "boyun tutulması":"neck_stiffness","boyun sertliği":"neck_stiffness","ense sertliği":"neck_stiffness",
  "yüz felci":"facial_drooping","yüzde sarkma":"facial_drooping","ağız eğriliği":"facial_drooping",
  "kol güçsüzlüğü":"arm_weakness","konuşma güçlüğü":"speech_difficulty","slur konuşma":"speech_difficulty",
  "uyuşma":"numbness_one_side","hissizlik":"numbness_one_side","karıncalanma":"tingling","ayaklarda karıncalanma":"numbness_feet",
  "ani baş dönmesi":"dizziness_sudden","denge kaybı":"loss_of_balance","dengeyi kaybediyorum":"balance_problems",
  "nöbet":"seizure","sara nöbeti":"seizure","konvülsiyon":"convulsion","bilinç kaybı":"loss_of_consciousness",
  "boş bakma":"blank_staring","kasılma":"jerking_movements","dil ısırma":"tongue_biting","idrar kaçırma nöbet":"urinary_incontinence",
  "koku alamıyorum":"loss_of_smell","koku kaybı":"loss_of_smell","tat alamıyorum":"loss_of_taste",
  "hafıza problemi":"memory_problems","unutkanlık":"memory_problems","konsantrasyon güçlüğü":"concentration_problems",
  "yavaş hareket":"slow_movement","hareketlerim yavaşladı":"slow_movement","kas sertliği":"stiffness",
  "sürüklenerek yürüme":"shuffling_gait","küçük adımlarla yürüme":"shuffling_gait",
  "eklem ağrısı":"joint_pain","eklem şişliği":"joint_swelling","eklem kızarıklığı":"red_swollen_joint",
  "eklem ısınması":"joint_warmth","sabah tutukluğu":"morning_stiffness","simetrik eklem ağrısı":"symmetric_joints",
  "kavrama güçlüğü":"grip_weakness","el bileği ağrısı":"wrist_pain","küçük eklem ağrısı":"small_joint_involvement",
  "ayak başparmak ağrısı":"big_toe_pain","ani eklem ağrısı":"sudden_joint_pain","gece ağrısı":"pain_at_night",
  "kas ağrısı":"body_aches","yaygın ağrı":"widespread_pain","hassas noktalar":"tender_points",
  "kas güçsüzlüğü":"muscle_weakness","güçsüzlük":"muscle_weakness","kas krampı":"muscle_cramps",
  "bel fıtığı":"lumbar_radiculopathy","sinir sıkışması":"sciatica","bacağa vuran ağrı":"leg_pain","siyatik":"sciatica",
  "bacakta uyuşma":"numbness_leg","bacakta karıncalanma":"tingling_leg","bacak güçsüzlüğü":"weakness_leg",
  "oturuncak ağrı":"worse_sitting","at kuyruğu sendromu":"saddle_anesthesia","idrar yapamıyorum":"urinary_retention",
  "eyer bölgesi uyuşma":"saddle_anesthesia",
  "kelebek döküntü":"butterfly_rash","yüzde döküntü":"butterfly_rash","deri döküntüsü":"skin_rash",
  "solmayan döküntü":"rash_non_blanching","kızarık cilt":"spreading_redness","cilt sıcak":"warm_skin",
  "ciltte şişlik":"skin_swelling","geniş cilt kızarıklığı":"spreading_redness","cilt ağrısı":"skin_tenderness",
  "kırmızı yama":"red_plaques","gümüş pullar":"silver_scales","kaşıntı":"itching","cilt kaşıntısı":"itching",
  "yavaş iyileşme":"slow_healing","kolay morarma":"easy_bruising","germe çizgileri":"stretch_marks",
  "mor çizgiler":"stretch_marks","yuvarlak yüz":"round_face","yağ tümseği":"hump_back","cilt koyulaşması":"skin_darkening",
  "ishal":"diarrhea","kronik ishal":"chronic_diarrhea","dışkıda kan":"blood_in_stool","kanlı dışkı":"blood_in_stool","rektal kanama":"rectal_bleeding",
  "şişkinlik":"bloating","gaz şikayeti":"bloating","kabızlık":"constipation","dışkı yapamıyorum":"no_bowel_movement",
  "gaz çıkaramıyorum":"no_flatus","karın şişliği":"abdominal_distension","kolik ağrı":"colicky_pain",
  "mide yanması":"heartburn","mide ekşimesi":"acid_reflux","göğüste yanma":"chest_burning","regürjitasyon":"regurgitation",
  "yatınca kötüleşiyor":"worse_lying_down","yemekten sonra kötüleşiyor":"worse_after_eating","ekşi tat":"sour_taste",
  "mide ülseri":"burning_stomach_pain","aç karnına ağrı":"hunger_pain","epigastrik ağrı":"epigastric_pain",
  "yemekle geçiyor":"pain_relieved_by_eating","siyah dışkı":"black_stool","katran gibi dışkı":"black_stool",
  "yutma güçlüğü":"difficulty_swallowing","yutarken ağrı":"difficulty_swallowing",
  "sağ üst karın ağrısı":"right_upper_pain","yağlı yemek sonrası ağrı":"pain_after_fatty_meal",
  "sarılık":"jaundice","açık renkli dışkı":"clay_stool","sırta vuran karın ağrısı":"pain_radiates_back",
  "öne eğilince geçiyor":"better_leaning_forward","alkol geçmişi":"alcohol_history",
  "kanlı kusma":"vomiting","safra ile kusma":"vomiting_fecal","karın hassasiyeti":"abdominal_tenderness",
  "öksürük":"cough","kronik öksürük":"chronic_cough","kuru öksürük":"dry_cough","balgamlı öksürük":"sputum_production",
  "hırıltı":"wheezing","hırıltılı nefes":"wheezing","balgam":"sputum_production","fıçı göğüs":"barrel_chest",
  "sabah öksürüğü":"morning_cough","gece kötüleşiyor":"worse_at_night","allerjen tetikliyor":"allergen_triggered",
  "kan öksürme":"coughing_blood","kanlı balgam":"coughing_blood","yatarken nefes darlığı":"orthopnea",
  "yatınca nefes alamıyorum":"orthopnea","hızlı kilo alıyorum":"rapid_weight_gain",
  "boğaz ağrısı":"sore_throat","burun akması":"runny_nose","ani başlangıç":"sudden_onset",
  "köpüklü idrar":"foamy_urine","az idrar":"reduced_urine","idrarda kan":"blood_in_urine","kanlı idrar":"blood_in_urine",
  "yanmalı işeme":"burning_urination","ağrılı işeme":"painful_urination","sık tuvalet ihtiyacı":"urgency",
  "idrar bulanık":"cloudy_urine","idrar kokusu":"strong_urine_smell","alt karın ağrısı":"lower_abdominal_pain",
  "böğür ağrısı":"flank_pain","yan ağrısı":"flank_pain","şiddetli yan ağrısı":"severe_flank_pain",
  "kasığa vuran ağrı":"pain_radiates_groin",
  "kalpte hızlanma":"racing_heart","kalp hızlanması":"racing_heart","taşikardi":"tachycardia",
  "düzensiz nabız":"irregular_heartbeat","egzersiz intoleransı":"reduced_exercise",
  "düşük tansiyon":"low_blood_pressure","yüksek tansiyon":"high_blood_pressure","nabız farkı":"difference_in_arm_pulses",
  "çok ani şiddetli göğüs ağrısı":"sudden_severe_chest_pain","yırtılır gibi ağrı":"tearing_pain",
  "sırta vuran ağrı":"pain_radiation_back","soğuk terleme":"cold_sweat","bayılma hissi":"dizziness",
  "çarpıntı ve nefes darlığı":"palpitations","bacak ağrısı":"leg_pain","baldır ağrısı":"calf_pain",
  "bacak sıcaklığı":"leg_warmth","bacak kızarıklığı":"leg_redness","bacak hassasiyeti":"tenderness",
  "depresyon":"persistent_sadness","üzüntü":"persistent_sadness","mutsuzluk":"persistent_sadness",
  "ilgi kaybı":"loss_of_interest","zevk alamıyorum":"loss_of_interest","umutsuzluk":"hopelessness",
  "değersizlik hissi":"worthlessness","ağlama":"crying","sosyal çekilme":"social_withdrawal",
  "uyku değişikliği":"sleep_changes","insomnia":"insomnia","çok uyuyorum":"sleep_changes",
  "iştah değişikliği":"appetite_changes","intihar düşüncesi":"suicidal_thoughts",
  "endişe":"excessive_worry","panik":"panic_attacks","aşırı endişe":"excessive_worry","korku":"fear",
  "kas gerginliği":"muscle_tension","ani yükselen mod":"elevated_mood",
  "uyku azaldı":"decreased_sleep","grandiözite":"grandiosity","hızlı konuşma":"rapid_speech",
  "impulsivite":"impulsivity","riskli davranış":"risky_behavior","hızlı düşünceler":"racing_thoughts",
  "sinirlilik":"irritability","mod değişimi":"mood_swings","travma geçmişi":"trauma_history",
  "flashback":"flashbacks","kaçınma":"avoidance","aşırı uyanıklık":"hypervigilance","duygusal uyuşma":"emotional_numbing",
  "saç dökülmesi":"hair_loss","kuru cilt":"dry_skin","yavaş nabız":"slow_heart_rate",
  "ses kalınlaştı":"hoarse_voice","soğuğa dayanamıyorum":"cold_intolerance","sıcağa dayanamıyorum":"heat_intolerance",
  "tuz isteği":"salt_craving","akne":"acne","tüylenme fazlalığı":"excess_hair","adet düzensizliği":"irregular_periods",
  "adet gecikmesi":"missed_period","düzensiz adet":"irregular_periods","gebelenemiyorum":"difficulty_conceiving",
  "yağlı cilt":"oily_skin","şişik yüz":"puffy_face","kırılgan tırnak":"brittle_nails",
  "yüksek ateş":"high_fever","konfüzyon":"confusion","bilinç bulanıklığı":"confusion",
  "hızlı nefes":"rapid_breathing","hızlı kalp":"rapid_heart_rate","idrar yapamıyorum":"not_urinating",
  "aşırı soğukluk":"very_cold","aşırı yorgunluk":"extreme_fatigue","benekli cilt":"mottled_skin",
  "şüpheli enfeksiyon":"suspected_infection","ense tutulması":"neck_stiffness",
  "vajinal kanama":"vaginal_bleeding","gebelik testi pozitif":"positive_pregnancy_test",
  "hamile olabilirim":"missed_period",
  "horlama":"loud_snoring","gündüz uykusu":"daytime_sleepiness","sabah baş ağrısı":"morning_headache",
  "gece nefes durması":"witnessed_apnea","sık uyanma":"frequent_waking","ağız kuruluğu":"dry_mouth",
  "büyük boyun":"large_neck","soluk kesilme":"witnessed_apnea",
  "açıklanamaz yorgunluk":"persistent_fatigue","açıklanamaz kanama":"unexplained_bleeding",
  "kitle":"lump","şişlik":"lump","bağırsak değişikliği":"change_in_bowel","kemik ağrısı":"bone_pain",
  "soluk deri":"pale_skin","solgun":"pale_skin","soğuk eller":"cold_hands","çabuk yorulma":"fatigue",
  "nefes nefese kalma":"breathlessness","pika":"pica","diş eti solukluğu":"pale_gums",
  "daha önce kırık":"fracture_low_trauma","uzunluk kaybı":"height_loss","kamburlaşma":"stooped_posture",
  "stres kırığı":"fragility_fracture","kalça ağrısı":"hip_pain","omurga ağrısı":"spine_pain",
  "dizi dirsek döküntü":"elbow_knee_rash","saç derisi tutulumu":"scalp_involvement","tırnak değişimi":"nail_changes",
  "psoriazis":"red_plaques","sedef":"red_plaques","eklem ağrısı ile döküntü":"joint_pain",
  "ağız yaraları":"mouth_sores","güneş hassasiyeti":"sun_sensitivity","böbrek şikayeti":"kidney_symptoms",
  "sık enfeksiyon":"frequent_infections","cilt koyulaşması":"dark_skin_patches","mantar":"recurrent_thrush",
  "mantar tekrarlıyor":"recurrent_thrush","turuncu idrar":"blood_in_urine",
};

export const COLLOQUIAL_MAP = {
  "kalbim sıkışıyor":"chest_tightness","baskı hissediyorum":"chest_pressure",
  "nefesim kesiliyor":"shortness_of_breath","ciğerlerim yanıyor":"chest_pain",
  "başım zonkluyor":"throbbing_headache","kafam zonkluyor":"throbbing_headache",
  "gözlerim kararıyor":"dizziness","yıldızlar görüyorum":"dizziness",
  "içim bulanıyor":"nausea","midem bulanıyor":"nausea",
  "dünya dönüyor":"dizziness","ayakta duramıyorum":"balance_problems",
  "ellerim uyuşuyor":"numbness_one_side","ayaklarım uyuşuyor":"numbness_feet",
  "soluğum daralıyor":"shortness_of_breath","nefes almakta zorlanıyorum":"shortness_of_breath",
  "kalbim atlıyor":"palpitations","kalbim hızlı atıyor":"racing_heart",
  "uyuyamıyorum":"insomnia","geceleri uyanıyorum":"sleep_changes",
  "her şey tuhaf geliyor":"confusion","aklım karışıyor":"confusion",
  "kaslarım tutuldu":"muscle_weakness","kollarım tutuyor":"grip_weakness",
  "kemiklerim ağrıyor":"body_aches","tüm vücudum ağrıyor":"widespread_pain",
  "tight chest":"chest_tightness","heart racing":"racing_heart","heart pounding":"palpitations",
  "can't breathe":"shortness_of_breath","short of breath":"shortness_of_breath",
  "head spinning":"dizziness","room spinning":"dizziness","feel faint":"dizziness",
  "stomach turning":"nausea","feel sick":"nausea","throwing up":"vomiting",
  "legs giving out":"weakness_leg","hands shaking":"tremor","body shaking":"tremor",
  "everything blurry":"blurred_vision","seeing double":"double_vision",
  "can't think straight":"concentration_problems","brain fog":"memory_problems",
  "pins and needles":"tingling","numb all over":"numbness_one_side",
};

export function normalizeTR(text) {
  return text
    .toLowerCase()
    .replace(/ğ/g,"g").replace(/ü/g,"u").replace(/ş/g,"s")
    .replace(/ı/g,"i").replace(/ö/g,"o").replace(/ç/g,"c");
}

export function matchPatterns(st, riskMods) {
  let normalized = st.toLowerCase();
  let englishSt = normalized;

  const colloquialKeys = Object.keys(COLLOQUIAL_MAP).sort((a,b)=>b.length-a.length);
  for (const phrase of colloquialKeys) {
    const normPhrase = normalizeTR(phrase);
    if (normalizeTR(normalized).includes(normPhrase)) {
      englishSt += " " + COLLOQUIAL_MAP[phrase];
    }
  }

  const sortedKeys = Object.keys(TR_TRIGGER_MAP).sort((a,b)=>b.length-a.length);
  for (const tr of sortedKeys) {
    if (normalizeTR(normalized).includes(normalizeTR(tr))) {
      englishSt += " " + TR_TRIGGER_MAP[tr];
    }
  }

  const words = englishSt.toLowerCase().split(/[\s,;.!?_]+/).filter(Boolean);

  const results = [];
  for (const [key,pat] of Object.entries(PATTERNS)) {
    const triggerHits = pat.triggers.filter(t => {
      const tParts = t.split("_");
      return words.some(w =>
        tParts.some(tp =>
          tp === w ||
          (w.length > 4 && tp.length > 4 && (w === tp || w.startsWith(tp) || tp.startsWith(w)))
        )
      );
    }).length;
    const requiredMet = pat.required_any.some(r => {
      const rParts = r.split("_");
      return words.some(w =>
        rParts.some(rp =>
          rp === w ||
          (w.length > 4 && rp.length > 4 && (w === rp || w.startsWith(rp) || rp.startsWith(w)))
        )
      );
    });
    const confirmatoryMet = pat.confirmatory.length > 0 && pat.confirmatory.every(c => {
      const cParts = c.split("_");
      return words.some(w =>
        cParts.some(cp =>
          cp === w ||
          (w.length > 4 && cp.length > 4 && (w === cp || w.startsWith(cp) || cp.startsWith(w)))
        )
      );
    });
    if (!requiredMet || triggerHits < 2) continue;
    const profileMod = riskMods?.[key] ?? 1.0;
    const score = triggerHits * 10 + (confirmatoryMet ? 30 : 0) + Math.log(profileMod + 0.1) * 5;
    results.push({...pat, key, score, confirmatoryMet, triggerHits, profileMod});
  }
  return results.sort((a,b) => b.score - a.score).slice(0, 6);
}

export const ALL_TRIGGERS = new Set(Object.values(PATTERNS).flatMap(p => p.triggers || []));
export const DANGER_TRIGGERS = ["jaundice","clay_stool","fever","tachycardia","shortness_of_breath","vomiting","fruity_breath","rapid_onset","abdominal_pain","low_blood_pressure","dizziness","rebound_tenderness","chest_pain","coughing_blood","loss_of_consciousness","repeated_vomiting","open_wound","limb_numb_pale","bleeding_uncontrolled","red_streaks","rash_near_eye","throat_tightness","lip_face_swelling","curtain_vision","sudden_vision_loss"];

export function buildSystemPrompt(lang, symptomText, profile, matches, followUpHistory, docSummary) {
  const vocab = [...new Set([...matches.flatMap(m => m.triggers || []), ...DANGER_TRIGGERS])].join(", ");
  const langName = lang==="tr"?"Turkish":"English";
  const profileStr = profile?[profile.age&&`Age: ${profile.age}`,profile.sex&&`Sex: ${profile.sex}`,profile.bmi&&`BMI: ${profile.bmi.toFixed(1)}`,profile.smoking&&"Current smoker",profile.diabetes&&"Known diabetes",profile.hypertension&&"Known hypertension",profile.familyHistory&&"Family history"].filter(Boolean).join(", "):"Not collected";
  const matchStr = matches.length>0?matches.map(m=>`${m.name} [ICD ${m.icd}]: ${m.triggerHits} hits, confirmatory: ${m.confirmatoryMet}, profileMod: ${m.profileMod.toFixed(2)}, LR: ${m.sprt_lr}, routing: ${m.routing_if_confirmed}`).join("\n"):"None";
  const fuStr = followUpHistory.length>0?followUpHistory.slice(-6).map(f=>`Q: ${f.q}  A: ${f.a}`).join("\n"):"None";
  const docStr = docSummary ? `\nMEDICAL DOCUMENTS ON FILE:\n${docSummary}\n` : "";
  return `You are SHC (Standard HealthCare), a clinical triage system. CRITICAL: ALL your output text must be in ${langName}. Never switch languages.

PATIENT PROFILE: ${profileStr}
SYMPTOMS: "${symptomText}"
PATTERN MATCHES:\n${matchStr}
FOLLOW-UPS SO FAR:\n${fuStr}${docStr}

TASK:
1. Use pattern matches and profile multipliers to build differential.
2. Ask ONE focused follow-up question unless you have enough for routing.
3. If medical documents are on file, use them to refine your assessment. You may ask the patient to upload relevant documents (lab results, MRI, etc.) if they would meaningfully change your routing.
4. When sufficient info exists, give routing with doctor alert.
5. Tone: calm, direct. Never say "I understand your concern."
6. IMPORTANT: All condition names in "differentials" MUST be in ${langName}. All text fields must be in ${langName}.

SYMPTOM EXTRACTION — the on-device SPRT engine makes the final routing decision; your task is structured extraction, never the decision:
  In "symptoms", report every finding the patient has AFFIRMED or explicitly DENIED across the entire conversation so far (cumulative), mapped to these ids:
  In "confidence", give your calibrated probability of PRESENCE (0.0-1.0) for any id you are NOT fully certain about — ambiguous mentions ("a strange feeling in my chest") belong at 0.4-0.7. Omit ids you are certain of; certainty is assumed at 1.0. The engine integrates these as soft evidence, so honest uncertainty here makes the routing safer.
  ${vocab}
  "present" = affirmed by the patient. "absent" = explicitly denied. Never infer absence from silence. Only use ids from the list.
  Your "routing" and "lambda" fields are ADVISORY — a second opinion shown to the physician. The deterministic engine computes the actual routing from your extracted symptoms and may override you.

ROUTING (advisory only): RED | YELLOW | GREEN | GREY if abstention.boundary=true

MANDATORY SAFETY ESCALATIONS (override the score — these are emergencies a kiosk cannot rule out):
- Head injury + (loss of consciousness | repeated vomiting | post-injury seizure) => routing RED.
- Suspected fracture + (open wound over site | numb/pale/cold limb) => routing RED (open fracture / neurovascular compromise).
- Bleeding that does not stop with direct pressure => routing RED.
- Allergic reaction + any airway sign (throat tightness, lip/tongue swelling, wheeze) => routing RED (anaphylaxis).
- Shingles rash near the eye or nose tip => routing RED (sight-threatening zoster).
- Cellulitis + (fever | red streaks) => routing RED (systemic spread / lymphangitis).
- Sudden vision loss or a curtain over vision => routing RED.
- Cholecystitis / biliary picture (ICD K81) WITH jaundice or pale/clay-colored stool → RED (possible biliary obstruction or ascending cholangitis, Charcot triad; untreated cholangitis is rapidly fatal).
- Acute pancreatitis (ICD K85) WITH any systemic inflammatory sign (fever, tachycardia, breathlessness, low blood pressure / SIRS) → RED (risk of severe acute pancreatitis).
- Type 1 diabetes (ICD E10) WITH DKA features (fruity/acetone breath, or vomiting with rapid onset or abdominal pain) → RED (diabetic ketoacidosis is life-threatening).
- Adrenal insufficiency / Addison's (ICD E27.1) WITH low blood pressure, or vomiting plus dizziness → RED (adrenal crisis / shock).
- Appendicitis (ICD K37) WITH rebound tenderness or peritoneal signs → RED (perforation/peritonitis, surgical emergency).
- Kidney stones (ICD N20) WITH fever → RED (infected obstructed stone / urosepsis).
- DVT (ICD I80.2) WITH breathlessness, chest pain, or coughing up blood → RED (pulmonary embolism).

Respond ONLY in this exact JSON (no markdown fences). Every text field MUST be in ${langName}:
{
  "text": "Reply in ${langName}. 2-3 sentences.",
  "phase": "collecting|decision",
  "differentials": [{"name": "Condition name in ${langName}", "icd": "ICD-10 code", "pct": 75, "risk": "critical|high|moderate|low", "source": "guideline"}],
  "symptoms": {"present": ["trigger_id"], "absent": ["trigger_id"], "confidence": {"trigger_id": 0.0}},
  "routing": null or "RED|YELLOW|GREEN",
  "lambda": null or number,
  "urgency": null or "action string in ${langName}",
  "doctor_alert": null or "doctor note in ${langName}",
  "abstention": {"boundary": false, "multiple": false, "unusual": false}
}`;
}



