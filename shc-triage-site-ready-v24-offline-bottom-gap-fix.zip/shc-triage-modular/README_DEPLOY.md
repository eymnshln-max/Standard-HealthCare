# SHC Triage — Google-native Render deploy

This package uses Google Gemini directly. There is no Anthropic compatibility layer in the runtime request/response path.

## Render settings

Build Command:

```bash
rm -rf shc-triage-modular && unzip -q -o shc-triage-site-ready-v4-google-native.zip && cd shc-triage-modular && corepack enable && corepack prepare pnpm@9.15.4 --activate && pnpm install --no-frozen-lockfile && pnpm run build
```

Start Command:

```bash
cd shc-triage-modular && ./node_modules/.bin/tsx server/src/index.ts
```

Environment variables:

```env
NODE_VERSION=22.12.0
GEMINI_API_KEY=your_google_gemini_api_key
GEMINI_MODEL=gemini-2.5-flash
NODE_ENV=production
```

## Runtime API

Frontend calls:

```text
POST /api/gemini/generate
```

Payload is Google-native for this app:

```json
{
  "mode": "triage_extraction",
  "systemInstruction": "...",
  "messages": [{ "role": "user", "content": "..." }]
}
```

Response:

```json
{
  "model": "gemini-2.5-flash",
  "text": "{...strict triage JSON...}",
  "usage": { "inputTokens": 0, "outputTokens": 0, "totalTokens": 0 }
}
```

The deterministic SPRT engine remains in the frontend clinical engine. Gemini is used for symptom extraction, structured conversation, and document summarization; it is not the final routing authority.


## v15 note
Based on the v9 layout. No composer/bottom safe-area changes. Adds horizontal swipe/overflow locking and keeps Google-native backend.


## v23 note
This build keeps the v20 UI and restores the original SHC engine flow. Claude/Anthropic calls are replaced by native Gemini backend calls only; there is no Anthropic compatibility adapter and no server-side fake triage fallback.
