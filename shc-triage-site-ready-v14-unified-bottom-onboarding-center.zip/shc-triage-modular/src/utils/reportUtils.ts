// @ts-nocheck
import { qrcode } from "./qrcodeGenerator";

export function asciiFold(s) {
  // QR taşınabilirliği için Türkçe karakterleri ASCII'ye indirge (telefon tarayıcı uyumu)
  return (s || "").replace(/[şŞ]/g,"s").replace(/[ıİ]/g,"i").replace(/[ğĞ]/g,"g").replace(/[üÜ]/g,"u").replace(/[öÖ]/g,"o").replace(/[çÇ]/g,"c").replace(/λ/g,"L");
}

// Motor sonucundan belirsizlik bayraklarını türetir (SPRT verisine bağlı, online+offline ortak).
// boundary: routing GREY (motor çekimser) → risk sınırı net değil.
// multiple: ayırıcı tanıda 2+ hipotez kayda değer payda (ikincil ≥ %15).
// unusual: belirtiler var ama hiçbir hipotez confirmed değil (net örüntüye oturmuyor).
export function deriveAbstention(res) {
  if (!res) return { boundary: false, multiple: false, unusual: false };
  const diffs = res.diffs || [];
  const confirmedCount = res.sprt?.confirmed?.length || 0;
  const boundary = res.routing === "GREY";
  const multiple = diffs.length >= 2 && diffs[1] && diffs[1].pct >= 15;
  // unusual yalnız KARARSIZ bölgede anlamlı: net RED (red-flag/escalation) veya GREEN net karardır.
  const unusual = diffs.length > 0 && confirmedCount === 0 && (res.routing === "GREY" || res.routing === "YELLOW") && !res.escalated;
  return { boundary, multiple, unusual };
}

export function buildQRPayload(routing, symptoms, lambda, reason, lang, doctorAlert, diffs, sprt) {
  const L = lang === "tr"
    ? { head:"SHC TRIYAJ OZETI", sl:"Bulgular", gl:"Gerekce", dx:"Ayirici Tani", al:"Klinik Not", lam:"Risk(L)", calc:"SPRT" }
    : { head:"SHC TRIAGE SUMMARY", sl:"Symptoms", gl:"Basis", dx:"Differentials", al:"Clinical Note", lam:"Risk(L)", calc:"SPRT" };
  const sx = asciiFold((symptoms || []).slice(0, 10).join(", ")) || "-";
  const lam = lambda != null ? lambda.toFixed(2) : "-";
  const rsn = asciiFold((reason || "-").slice(0, 90));
  const lines = [
    L.head,
    `${L.lam}: ${routing || "-"} (L=${lam})`,
    `${L.sl}: ${sx}`,
    `${L.gl}: ${rsn}`,
  ];
  // SPRT hesap özeti: S skoru, prior, karar sınırı, olabilirlik oranı (odds). Sığarsa girer.
  if (sprt && typeof sprt.S === "number") {
    const odds = Math.exp(sprt.S);
    const oddsStr = odds >= 1 ? `${odds.toFixed(1)}:1` : `1:${(1/odds).toFixed(1)}`;
    const steps = sprt.traj ? sprt.traj.length - 1 : 0;
    const s0 = typeof sprt.s0 === "number" ? sprt.s0.toFixed(2) : "-";
    lines.push(`${L.calc}: S=${sprt.S.toFixed(2)} (prior ${s0}, ${steps} bulgu, sinir +-2.94) odds ${oddsStr}`);
    // Adım adım birikim: prior + her bulgunun S'e katkısı (λ skorunun nasıl oluştuğu)
    if (sprt.traj && sprt.traj.length) {
      const trace = sprt.traj.map(t => {
        if (t.t === "prior") return `prior ${t.S.toFixed(2)}`;
        const sign = t.present ? "+" : "-";
        const yv = t.y >= 0 ? `+${t.y.toFixed(2)}` : t.y.toFixed(2);
        const short = asciiFold(t.t).replace(/_/g, " ").split(" ")[0].slice(0, 8);
        return `${sign}${short}${yv}`;
      }).join(" ");
      lines.push(`Hesap: ${trace} = ${sprt.S.toFixed(2)}`);
    }
  }
  // Ayırıcı tanı tablosu (ilk 4, yüzde + kaynak)
  if (diffs && diffs.length) {
    const dx = diffs.slice(0, 4).map(d =>
      `${asciiFold(d.name)} ${d.pct}%`
    ).join("; ");
    lines.push(`${L.dx}: ${dx}`);
  }
  // Klinik kılavuz notu — [SPRT] teknik izini at (QR'da gereksiz, panelde zaten var), kalanı kırp
  if (doctorAlert) {
    let note = doctorAlert.replace(/\[SPRT\][^\n]*\n*/g, "").trim();
    note = note.split("\n\n").filter(Boolean).pop() || note; // son anlamlı paragraf (klinik öneri)
    if (note) lines.push(`${L.al}: ${asciiFold(note).slice(0, 160)}`);
  }
  return lines.join("\n");
}
export function qrMatrix(text) {
  const qr = qrcode(0, "M");
  qr.addData(text, "Byte");
  qr.make();
  const n = qr.getModuleCount();
  const m = [];
  for (let r = 0; r < n; r++) { const row = []; for (let c = 0; c < n; c++) row.push(qr.isDark(r, c) ? 1 : 0); m.push(row); }
  return m;
}
