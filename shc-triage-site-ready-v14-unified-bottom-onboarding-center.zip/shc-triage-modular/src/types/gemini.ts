export type GeminiRole = "user" | "model";

export type GeminiTextPart = {
  type: "text";
  text: string;
};

export type GeminiInlineDataPart = {
  type: "inline_data";
  mimeType: string;
  data: string;
};

export type GeminiPart = GeminiTextPart | GeminiInlineDataPart;

export type GeminiConversationMessage = {
  role: GeminiRole;
  content: string | GeminiPart[];
};

export type GeminiGenerateMode = "triage_extraction" | "document_summary" | "free_text";

export type GeminiGenerateRequest = {
  model?: string;
  mode?: GeminiGenerateMode;
  systemInstruction?: string;
  messages: GeminiConversationMessage[];
  maxOutputTokens?: number;
  temperature?: number;
};

export type GeminiGenerateResponse = {
  model: string;
  text: string;
  finishReason?: string;
  usage?: {
    inputTokens?: number;
    outputTokens?: number;
    totalTokens?: number;
  };
};
