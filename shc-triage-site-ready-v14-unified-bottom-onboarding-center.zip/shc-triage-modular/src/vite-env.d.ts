/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_GEMINI_MODEL?: string;
}

interface Window {
  SpeechRecognition?: any;
  webkitSpeechRecognition?: any;
}
