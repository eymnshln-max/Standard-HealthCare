import type { GeminiGenerateRequest, GeminiGenerateResponse } from "../types/gemini";

type RequestOptions = {
  retries?: number;
  timeoutMs?: number;
};

const RETRYABLE_STATUS = new Set([429, 500, 502, 503, 504]);

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function callGeminiBackend(
  payload: GeminiGenerateRequest,
  options: RequestOptions = {},
): Promise<GeminiGenerateResponse> {
  const retries = options.retries ?? 2;
  const timeoutMs = options.timeoutMs ?? 45_000;

  for (let attempt = 0; attempt <= retries; attempt += 1) {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), timeoutMs);

    try {
      const response = await fetch("/api/gemini/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });

      if (response.ok) {
        return await response.json();
      }

      if (RETRYABLE_STATUS.has(response.status) && attempt < retries) {
        await delay(response.status === 429 ? 4_000 : 2_000);
        continue;
      }

      const errorText = await response.text().catch(() => "");
      throw new Error(errorText || `Gemini request failed with HTTP ${response.status}`);
    } catch (error) {
      if (attempt < retries) {
        await delay(1_500);
        continue;
      }
      throw error;
    } finally {
      window.clearTimeout(timeout);
    }
  }

  throw new Error("Gemini request failed");
}
