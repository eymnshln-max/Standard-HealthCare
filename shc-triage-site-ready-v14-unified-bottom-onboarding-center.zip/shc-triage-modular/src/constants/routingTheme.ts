// @ts-nocheck
export function getRouting(dark) { return {
  RED:    { color:"#c0392b", bg:dark?"rgba(192,57,43,0.12)":"#fff5f5", border:"rgba(192,57,43,0.25)", dot:"#c0392b" },
  YELLOW: { color:"#8e8e93", bg:dark?"rgba(160,82,45,0.12)":"#fffaf0", border:"rgba(160,82,45,0.25)", dot:"#92400e" },
  GREEN:  { color:"#1a7a3c", bg:dark?"rgba(26,122,60,0.12)":"#f5fff9",  border:"rgba(26,122,60,0.25)",  dot:"#166534" },
  GREY:   { color:"#8e8e93", bg:dark?"rgba(142,142,147,0.12)":"#f7f7f8", border:"rgba(142,142,147,0.30)", dot:"#8e8e93" },
}; }
