import { Router } from "express";
import { gemini } from "../services/geminiClient";
import type { GeminiConversationMessage, GeminiGenerateRequest, GeminiPart } from "../types/gemini";

export const geminiRouter = Router();

type NativeGeminiPart = { text: string } | { inlineData: { mimeType: string; data: string } };

function normalizeParts(content: string | GeminiPart[]): NativeGeminiPart[] {
  if (typeof content === "string") return [{ text: content }];

  const parts: NativeGeminiPart[] = [];
  for (const part of content) {
    if (part.type === "text") {
      parts.push({ text: part.text });
    } else if (part.type === "inline_data") {
      parts.push({ inlineData: { mimeType: part.mimeType, data: part.data } });
    }
  }
  return parts;
}

function toGeminiContents(messages: GeminiConversationMessage[]) {
  return messages.map((message) => ({
    role: message.role === "model" ? "model" : "user",
    parts: normalizeParts(message.content),
  }));
}

function extractText(response: any): string {
  if (typeof response?.text === "string") return response.text.trim();

  const parts = response?.candidates?.[0]?.content?.parts ?? [];
  return parts
    .map((part: any) => (typeof part?.text === "string" ? part.text : ""))
    .join("")
    .trim();
}

function jsonFromText(text: string): string | null {
  const cleaned = (text || "").replace(/```json|```/g, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end <= start) return null;

  const candidate = cleaned.slice(start, end + 1);
  try {
    JSON.parse(candidate);
    return candidate;
  } catch {
    return null;
  }
}

function safeTriageJson(text: string, systemInstruction: string): string {
  const parsed = jsonFromText(text);
  if (parsed) return parsed;

  const isTr = /Turkish|Türkçe|Turkce/i.test(systemInstruction || "");
  return JSON.stringify({
    text: isTr
      ? "Birkaç ayrıntıya daha ihtiyacım var. Bulantı, kusma, ateş, ishal, dışkıda siyahlık/kan veya idrar yakınmanız var mı?"
      : "I need a few more details. Do you also have nausea, vomiting, fever, diarrhea, black/bloody stool, or urinary symptoms?",
    phase: "collecting",
    differentials: [],
    symptoms: { present: [], absent: [], confidence: {} },
    routing: null,
    lambda: null,
    urgency: null,
    doctor_alert: null,
    abstention: { boundary: false, multiple: false, unusual: false },
  });
}

function triageContract() {
  return `

GOOGLE GEMINI OUTPUT CONTRACT FOR SHC:
You are not the routing decision-maker. The browser-side SPRT engine makes the final routing decision.
Your job is only structured symptom extraction plus exactly one next follow-up question when phase is collecting.
Return one valid JSON object only. No markdown. No prose outside JSON. No code fences.
Use double quotes for all JSON keys and strings. Do not use trailing commas.
If information is insufficient, set phase to "collecting", routing to null, lambda to null, and put exactly one focused follow-up question in text.
Do not repeat a question already answered in the conversation. If onset/duration and severity are already present, ask associated symptoms or red flags next.
`;
}

geminiRouter.post("/generate", async (req, res, next) => {
  try {
    const body = req.body as GeminiGenerateRequest;

    if (!Array.isArray(body.messages)) {
      res.status(400).json({ error: "messages must be an array" });
      return;
    }

    const mode = body.mode || "free_text";
    const model = body.model || process.env.GEMINI_MODEL || "gemini-2.5-flash";
    const systemInstruction = `${body.systemInstruction || ""}${mode === "triage_extraction" ? triageContract() : ""}`;

    const config: any = {
      systemInstruction,
      temperature: body.temperature ?? (mode === "triage_extraction" ? 0 : 0.2),
      maxOutputTokens: body.maxOutputTokens ?? (mode === "document_summary" ? 1200 : 1600),
    };

    if (mode === "triage_extraction") {
      config.responseMimeType = "application/json";
    }

    const response = await gemini.models.generateContent({
      model,
      contents: toGeminiContents(body.messages),
      config,
    });

    const rawText = extractText(response);
    const text = mode === "triage_extraction" ? safeTriageJson(rawText, systemInstruction) : rawText;
    const candidate = (response as any)?.candidates?.[0];
    const usage = (response as any)?.usageMetadata;

    res.json({
      model,
      text,
      finishReason: candidate?.finishReason,
      usage: {
        inputTokens: usage?.promptTokenCount,
        outputTokens: usage?.candidatesTokenCount,
        totalTokens: usage?.totalTokenCount,
      },
    });
  } catch (error) {
    next(error);
  }
});
