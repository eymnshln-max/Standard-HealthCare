import "dotenv/config";
import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import { geminiRouter } from "./routes/gemini";

const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, "../..");
const distDir = path.join(rootDir, "dist");

app.use(cors());
app.use(express.json({ limit: "25mb" }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

app.use("/api/gemini", geminiRouter);

if (process.env.NODE_ENV === "production") {
  app.use(express.static(distDir));
  // Express 5 uses path-to-regexp v6+; string wildcards like "*" throw at startup.
  // A RegExp fallback keeps SPA routing working without crashing Render.
  app.get(/.*/, (_req, res) => {
    res.sendFile(path.join(distDir, "index.html"));
  });
}

app.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  const message = err instanceof Error ? err.message : "Unknown server error";
  console.error(err);
  res.status(500).json({ error: message });
});

const port = Number(process.env.PORT || 3001);
app.listen(port, () => {
  console.log(`SHC Gemini server running on port ${port}`);
});
