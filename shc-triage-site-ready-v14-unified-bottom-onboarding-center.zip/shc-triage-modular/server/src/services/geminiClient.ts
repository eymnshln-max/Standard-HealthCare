import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;

if (!apiKey) {
  throw new Error("GEMINI_API_KEY is missing. Create a .env file and set GEMINI_API_KEY=...");
}

export const gemini = new GoogleGenAI({ apiKey });
