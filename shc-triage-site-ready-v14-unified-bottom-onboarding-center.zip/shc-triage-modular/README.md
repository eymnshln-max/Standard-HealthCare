# Standard Health Triage — Google-native Gemini build

This is a deploy-ready React + Express build of SHC Triage.

Runtime architecture:

- React frontend: UI, profile flow, offline triage, deterministic clinical/SPRT engine.
- Express backend: secure Gemini API proxy.
- Google Gemini: symptom extraction, structured follow-up generation, and document summarization.
- No Anthropic compatibility adapter is used in the runtime request/response path.

## Local run

```bash
npm install
cp .env.example .env
npm run dev
```

Set `.env`:

```env
GEMINI_API_KEY=your_google_gemini_api_key
GEMINI_MODEL=gemini-2.5-flash
PORT=3001
```

## Production

```bash
npm run build
npm start
```

See `README_DEPLOY.md` for Render deployment.


## Mobile viewport fix

This build disables mobile Safari input auto-zoom by using a non-scalable viewport and 16px minimum form-control font size.


## PWA/mobile

The app name is `Standard Health`. PWA icons are provided in `public/icon-192.png`, `public/icon-512.png`, and `public/apple-touch-icon.png`. After changing these, delete the old iPhone home-screen app and add it again so iOS refreshes the cached name/icon/status-bar settings.
