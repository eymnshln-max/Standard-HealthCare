// @ts-nocheck
import { useEffect, useRef, useState } from "react";

import { CloseSessionButton } from "./components/CloseSessionButton";
import { OnboardingScreen } from "./components/OnboardingScreen";
import { T } from "./constants/translations";
import { getRouting } from "./constants/routingTheme";
import { callAnthropicLikeBackend } from "./services/aiClient";
import {
  AKINATOR_GATES,
  AKINATOR_QUESTIONS,
  ALL_TRIGGERS,
  DANGER_TRIGGERS,
  GATE_PATTERNS,
  OFFLINE_PATTERN_NAMES_TR,
  OFFLINE_URGENCY_EN,
  OFFLINE_URGENCY_TR,
  PATTERNS,
  buildSystemPrompt,
  checkRedFlags,
  clinicalEscalation,
  computeOfflineResult,
  computeRiskProfile,
  escalationNote,
  matchPatterns,
  pickNextQuestion,
  sprtDecide,
} from "./utils/clinicalEngine";
import { buildQRPayload, deriveAbstention, qrMatrix } from "./utils/reportUtils";

function App() {
  const [lang, setLang] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [uiPhase, setUiPhase] = useState("profiling");
  const [profileAnswers, setProfileAnswers] = useState({});
  const [profileIdx, setProfileIdx] = useState(0);
  const [profile, setProfile] = useState(null);
  const [riskMods, setRiskMods] = useState({});
  const [symptomText, setSymptomText] = useState("");
  const [matches, setMatches] = useState([]);
  const [followUpHistory, setFollowUpHistory] = useState([]);
  const [history, setHistory] = useState([]);
  const [diffs, setDiffs] = useState([]);
  const [routing, setRouting] = useState(null);
  const [lambda, setLambda] = useState(null);
  const [urgency, setUrgency] = useState(null);
  const [doctorAlert, setDoctorAlert] = useState(null);
  const [abstention, setAbstention] = useState({});
  const [panelTab, setPanelTab] = useState("result");
  const [docText, setDocText]   = useState("");
  const [docResult, setDocResult] = useState("");
  const [docLoading, setDocLoading] = useState(false);
  const [docSummary, setDocSummary] = useState("");   // özetlenmiş belge — API context'ine girer
  const [docPhase, setDocPhase]   = useState("idle");
  const [isListening, setIsListening] = useState(false);
  const [doctorMode, setDoctorMode] = useState(false);
  const [dark, setDark] = useState(false);
  const [offlineMode, setOfflineMode] = useState(false);
  const [akinatorAsked, setAkinatorAsked] = useState([]);
  const [akinatorTriggers, setAkinatorTriggers] = useState([]);
  const [akinatorCurrent, setAkinatorCurrent] = useState(null);
  const [akinatorDone, setAkinatorDone] = useState(false);
  const [akinatorScale, setAkinatorScale] = useState(5);
  const [akinatorAnsweredNo, setAkinatorAnsweredNo] = useState([]);
  const [akinatorAbsent, setAkinatorAbsent] = useState([]);
  const [sprtViz, setSprtViz] = useState(null);
  const [akinatorGate, setAkinatorGate] = useState(null);
  const C = dark ? {
    bg:"#1c1c1e",bg2:"#2c2c2e",bg3:"#3a3a3c",surface:"#2c2c2e",
    sep:"rgba(255,255,255,0.08)",text:"#ffffff",text2:"#ebebf5cc",text3:"#ebebf599",
    placeholder:"#636366",userBubble:"#2c2c2e",userText:"#ffffff",
    shcBubble:"#3a3a3c",shcText:"#ffffff",btnBg:"#3a3a3c",
    btnBorder:"rgba(255,255,255,0.12)",accent:"#0a84ff",dot:"#ffffff",
  } : {
    bg:"#ffffff",bg2:"#f5f5f7",bg3:"#efefef",surface:"#ffffff",
    sep:"rgba(0,0,0,0.08)",text:"#1d1d1f",text2:"#1d1d1f",text3:"#6e6e73",
    placeholder:"#aeaeb2",userBubble:"#1d1d1f",userText:"#ffffff",
    shcBubble:"#f5f5f7",shcText:"#1d1d1f",btnBg:"#ffffff",
    btnBorder:"rgba(0,0,0,0.12)",accent:"#0071e3",dot:"#1d1d1f",
  };
  const bottomRef = useRef(null);
  const scrollRef = useRef(null);
  const textareaRef = useRef(null);
  const fileInputRef = useRef(null);
  const chatFileRef  = useRef(null);
  const recognitionRef = useRef(null);

  useEffect(() => {
    if (!lang) return; // onboarding'de scroll yok
    const sc = scrollRef.current;
    if (!sc) return;
    const id = requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        sc.scrollTo({ top: sc.scrollHeight, behavior: "smooth" });
      });
    });
    return () => cancelAnimationFrame(id);
  }, [messages, loading, akinatorCurrent, akinatorGate, akinatorDone, routing, lang]);

  // Body + theme-color'ı app temasına eşitle (alt safe-area boşluğu app arka planıyla aynı olsun)
  useEffect(() => {
    const c = dark ? "#1c1c1e" : "#ffffff";
    document.documentElement.style.setProperty("background", c, "important");
    document.body.style.setProperty("background", c, "important");
    const root = document.getElementById("root");
    if (root) root.style.setProperty("background", c, "important");
    let meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", c);
    const sb = document.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]');
    if (sb) sb.setAttribute("content", dark ? "black" : "default");
  }, [dark]);
  function addMsg(text, role="shc") { setMessages(m => [...m, {role, text, ts:Date.now()}]); }

  function doReset() {
    setMessages([]); setInput(""); setLoading(false); setUiPhase("profiling");
    setProfileAnswers({}); setProfileIdx(0); setProfile(null); setRiskMods({});
    setSymptomText(""); setMatches([]); setFollowUpHistory([]); setHistory([]);
    setDiffs([]); setRouting(null); setLambda(null); setUrgency(null); setSprtViz(null);
    setDoctorAlert(null); setAbstention({}); setPanelTab("result"); setLang(null);
    setDocText(""); setDocResult(""); setDocLoading(false);
    setDocSummary(""); setDocPhase("idle");
    setOfflineMode(false); setAkinatorAsked([]); setAkinatorTriggers([]); setAkinatorCurrent(null); setAkinatorDone(false); setAkinatorScale(5); setAkinatorAnsweredNo([]); setAkinatorAbsent([]); setAkinatorGate(null); setSprtViz(null);
  }

  function startSession(selectedLang, isOffline=false) {
    setLang(selectedLang);
    setOfflineMode(isOffline);
    setUiPhase("profiling");
    const t = T[selectedLang];
    setTimeout(() => { addMsg(t.profileIntro.trim() + "\n\n" + t.questions[0].q); }, 100);
  }

  function toggleListen() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }
    const rec = new SR();
    rec.lang = lang === "tr" ? "tr-TR" : "en-US";
    rec.continuous = false;
    rec.interimResults = false;
    rec.onresult = (e) => {
      const transcript = e.results[0]?.[0]?.transcript || "";
      if (transcript) setInput(prev => prev ? prev + " " + transcript : transcript);
    };
    rec.onend = () => setIsListening(false);
    rec.onerror = () => setIsListening(false);
    recognitionRef.current = rec;
    rec.start();
    setIsListening(true);
  }

  async function send() {
    const text = input.trim();
    if (!text || loading) return;
    setInput("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";
    addMsg(text, "user");
    const t = T[lang];
    const isProfilingDone = profileIdx >= t.questions.length;
    if (uiPhase === "profiling" && !isProfilingDone) { await handleProfileAnswer(text); return; }
    if (uiPhase === "doc_upload") {
      const isNone = /^(yok|no|none|hayır|nope|-)$/i.test(text.trim());
      if (isNone) {
        setDocPhase("done");
        setUiPhase("symptoms");
        setTimeout(() => addMsg(T[lang].profileComplete(false)), 200);
      } else {
        // Belge var — özetle
        setLoading(true);
        setDocPhase("uploading");
        const summary = await summarizeDoc(text, profile);
        if (summary === "NOT_MEDICAL") {
          const warn = lang==="tr"
            ? "Bu metin tıbbi bir belge gibi görünmüyor. Kan tahlili, MR raporu veya muayene notu yapıştırabilirsiniz. Devam etmek için \"yok\" yazın."
            : "This doesn't look like a medical document. You can paste a lab result, MRI report, or clinic note. Type \"none\" to continue without a document.";
          addMsg(warn);
          setDocPhase("asking");
          setUiPhase("doc_upload");
        } else if (summary) {
          setDocSummary(summary);
          setDocResult(summary);
          const ack = lang==="tr"
            ? `Belgenizi aldım, özetledim ve değerlendirmeme dahil ettim.\n\nŞimdi bana neden geldiğinizi anlatın — sizi en çok ne rahatsız ediyor?`
            : `Got it — I've summarized your document and included it in my assessment.\n\nNow tell me what brought you in — what's been bothering you most?`;
          addMsg(ack);
          setDocPhase("done");
          setUiPhase("symptoms");
        } else {
          const fail = lang==="tr"
            ? "Belgeyi işleyemedim ama devam edebiliriz.\n\nBana neden geldiğinizi anlatın."
            : "Couldn't process the document, but we can continue.\n\nTell me what's been bothering you.";
          addMsg(fail);
          setDocPhase("done");
          setUiPhase("symptoms");
        }
        setLoading(false);
      }
      return;
    }
    await handleSymptomTurn(text);
  }

  function handleKey(e) { if (e.key==="Enter" && !e.shiftKey) { e.preventDefault(); send(); } }

  function validateProfileAnswer(key, type, text) {
    const tv = text.trim().toLowerCase();
    const t = T[lang];
    if (!tv) return {ok:false, hint:t.validation.empty};
    if (type==="choice") return {ok:true};
    if (type==="number") {
      const n = parseFloat(tv);
      if (isNaN(n)||n<=0) return {ok:false, hint:t.validation.number};
      if (key==="age"&&n<18) return {ok:false, hint:t.validation.age};
      if (key==="age"&&n>120) return {ok:false, hint:t.validation.age_over};
      if (key==="height_cm"&&(n<50||n>250)) return {ok:false, hint:t.validation.height};
      if (key==="weight_kg"&&(n<10||n>400)) return {ok:false, hint:t.validation.weight};
    }
    return {ok:true};
  }

  async function summarizeDoc(rawText, profileData, pdfBase64) {
    const pStr = profileData ? [profileData.age&&`${profileData.age}y`, profileData.sex, profileData.bmi&&`BMI ${profileData.bmi.toFixed(0)}`, profileData.diabetes&&"DM", profileData.hypertension&&"HTN"].filter(Boolean).join(", ") : "";
    const sys = lang==="tr"
      ? `Sen klinik bir asistansın. Verilen belgenin tıbbi bir belge olup olmadığını önce kontrol et (kan tahlili, MR/BT raporu, epikriz, muayene notu, reçete, laboratuvar sonucu vb.). Eğer tıbbi bir belge DEĞİLSE, sadece şunu yaz: "NOT_MEDICAL". Tıbbi belgeyse doktor için özetle. Hasta: ${pStr}. Çıktı: önemli bulgular, anormal değerler, doktor için dikkat çekici noktalar. Maksimum 300 kelime. Sadece özet yaz.`
      : `You are a clinical assistant. First check if the document is a medical document (blood work, MRI/CT report, discharge summary, clinic note, prescription, lab result, etc.). If it is NOT a medical document, respond only with: "NOT_MEDICAL". If it is medical, summarize it for a doctor. Patient: ${pStr}. Output: key findings, abnormal values, clinically notable points. Max 300 words. Output summary only.`;
    const userContent = pdfBase64
      ? [{type:"document", source:{type:"base64", media_type:"application/pdf", data:pdfBase64}}, {type:"text", text:"Check if this is a medical document and summarize as instructed."}]
      : `Document:\n\n${rawText.trim()}`;
    try {
      const data = await callAPI(sys, [{role:"user", content:userContent}]);
      const result = data?.content?.map(b=>b.text||"").join("").trim() || "";
      if (result === "NOT_MEDICAL") return "NOT_MEDICAL";
      return result;
    } catch { return ""; }
  }

  async function readFileAsBase64(file) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result.split(",")[1]);
      r.onerror = rej;
      r.readAsDataURL(file);
    });
  }

  async function handleFileUpload(file, source) {
    // source: "chat" | "panel"
    if (!file) return;
    const isPdf = file.type === "application/pdf";
    const isText = file.type.startsWith("text/");
    if (!isPdf && !isText) {
      if (source === "chat") addMsg(lang==="tr" ? "Sadece PDF veya metin dosyası yükleyebilirsiniz." : "Only PDF or text files are supported.");
      return;
    }
    if (source === "chat") {
      addMsg(lang==="tr" ? `📄 ${file.name}` : `📄 ${file.name}`, "user");
      setLoading(true);
    } else {
      setDocLoading(true); setDocResult("");
    }
    let summary = "";
    if (isPdf) {
      const b64 = await readFileAsBase64(file);
      summary = await summarizeDoc("", profile, b64);
    } else {
      const text = await file.text();
      summary = await summarizeDoc(text, profile);
    }
    if (summary === "NOT_MEDICAL") {
      const warn = lang==="tr"
        ? "Bu belge tıbbi bir belge gibi görünmüyor. Lütfen kan tahlili, MR/BT raporu, epikriz veya muayene notu yükleyin."
        : "This doesn't look like a medical document. Please upload a lab result, MRI/CT report, discharge summary, or clinic note.";
      if (source === "chat") addMsg(warn);
      else setDocResult(warn);
    } else if (summary) {
      setDocSummary(prev => prev ? prev + "\n\n---\n\n" + summary : summary);
      setDocResult(summary);
      if (source === "chat") {
        const ack = lang==="tr"
          ? `Belgenizi okudum ve değerlendirmeme dahil ettim.\n\nDevam edelim — sizi en çok ne rahatsız ediyor?`
          : `I've read your document and included it in my assessment.\n\nLet's continue — what's been bothering you most?`;
        addMsg(ack);
        if (uiPhase === "doc_upload") { setDocPhase("done"); setUiPhase("symptoms"); }
      }
    } else {
      const fail = lang==="tr" ? "Belge okunamadı." : "Couldn't read the document.";
      if (source === "chat") addMsg(fail);
      else setDocResult(fail);
    }
    setLoading(false); setDocLoading(false);
  }

  async function handleProfileAnswer(text) {
    const t = T[lang];
    const q = t.questions[profileIdx];
    if (!q) { await handleSymptomTurn(text); return; }
    const validation = validateProfileAnswer(q.key, q.type, text);
    if (!validation.ok) { setTimeout(() => addMsg(`${validation.hint}\n\n${q.q}`), 150); return; }
    const newAnswers = {...profileAnswers, [q.key]: text};
    setProfileAnswers(newAnswers);
    const nextIdx = profileIdx + 1;
    setProfileIdx(nextIdx);
    if (nextIdx < t.questions.length) {
      setTimeout(() => addMsg(t.questions[nextIdx].q), 200);
    } else {
      const p = parseProfile(newAnswers);
      setProfile(p);
      const {mods} = computeRiskProfile({age:p.age,sex:p.sex,bmi:p.bmi,smoking:p.smoking,diabetes:p.diabetes,hypertension:p.hypertension,familyHistory:p.familyHistory});
      setRiskMods(mods);
      if (!offlineMode) {
        // Online modda önce belge sorusu
        setDocPhase("asking");
        const docQ = lang==="tr"
          ? `Teşekkürler, bilgilerinizi aldım.\n\nDevam etmeden önce: Mevcut bir tıbbi belgeniz var mı? (Kan tahlili, MR/BT raporu, epikriz, muayene notu vb.)\n\nVarsa aşağıdaki alana yapıştırabilirsiniz. Yoksa "yok" yazın.`
          : `Got it, thank you.\n\nBefore we continue: do you have any medical documents on hand? (Blood work, MRI/CT report, discharge summary, clinic note, etc.)\n\nIf so, paste it below. If not, just type "none".`;
        setTimeout(() => { addMsg(docQ); setUiPhase("doc_upload"); }, 200);
      } else {
        setTimeout(() => {
          addMsg(t.profileComplete(offlineMode));
          setUiPhase("symptoms");
        }, 200);
      }
    }
  }

  function startAkinator() {
    setAkinatorAsked([]);
    setAkinatorTriggers([]);
    
    setAkinatorAnsweredNo([]);
    setAkinatorAbsent([]);
    setAkinatorGate(null);
    setAkinatorDone(false);
    setAkinatorScale(5);
    setAkinatorCurrent(null);
  }

  function handleGateSelect(gateId) {
    const gates = AKINATOR_GATES[lang] || AKINATOR_GATES.tr;
    const gate = gates.find(g => g.id === gateId);
    if (!gate) return;
    setAkinatorGate(gateId);
    addMsg(gate.label, "user");
    const firstQ = pickNextQuestion([], gateId, [], riskMods, [], []);
    if (firstQ) {
      setAkinatorCurrent(firstQ);
      setTimeout(() => addMsg(lang==="tr" ? firstQ.text_tr : firstQ.text_en), 250);
    }
  }

  function handleAkinatorAnswer(answer, scaleVal) {
    if (!akinatorCurrent) return;
    const q = akinatorCurrent;
    const newAsked = [...akinatorAsked, q.id];
    let newTriggers = [...akinatorTriggers];
    let newAnsweredNo  = [...akinatorAnsweredNo];
    let newAbsent = [...akinatorAbsent];

    if (q.type === "yn") {
      if (answer === "yes") {
        newTriggers = [...newTriggers, ...(q.triggers_yes||[])];
      } else {
        newAnsweredNo = [...newAnsweredNo, q.id];
        // Negatif kanıt: yalnızca açık "hayır" yokluk sayılır; "emin değilim" nötrdür
        if (answer === "no") newAbsent = [...newAbsent, ...(q.triggers_yes || [])];
      }
    } else if (q.type === "scale") {
      const val = scaleVal ?? akinatorScale;
      if (val >= 7) newTriggers = [...newTriggers, ...(q.scale_high_triggers||[])];
      if (val >= 4) newTriggers = [...newTriggers, q.scale_trigger];
    }

    const labelMap = {
      yes:   lang==="tr" ? "Evet" : "Yes",
      no:    lang==="tr" ? "Hayır" : "No",
      unsure:lang==="tr" ? "Emin Değilim" : "Unsure",
    };
    const displayLabel = q.type==="scale"
      ? `${scaleVal ?? akinatorScale}/10`
      : labelMap[answer];
    addMsg(displayLabel, "user");

    setAkinatorAsked(newAsked);
    setAkinatorTriggers(newTriggers);
    setAkinatorAnsweredNo(newAnsweredNo);
    setAkinatorAbsent(newAbsent);

    const MAX_QUESTIONS = 12; // SPRT erken durdurma + negatif kanıtla 12 yeterli; limitte GREY/karar
    const result = computeOfflineResult(newTriggers, riskMods, newAsked.length, akinatorGate, lang, false, newAbsent);

    const finalize = (res, forced=false) => {
      setAkinatorDone(true);
      setAkinatorCurrent(null);
      if (res) {
        setRouting(res.routing);
        setLambda(res.lambda);
        setDiffs(res.diffs);
        setSprtViz(res.sprt || null);
        setDoctorAlert(res.doctorAlert);
        setAbstention(deriveAbstention(res));
        setUrgency(res.urgency);
        setUiPhase("decision");
        setPanelTab("result");
        const routingLabel = T[lang].routing[res.routing];
        const prefix = forced
          ? (lang==="tr" ? `Tüm sorular tamamlandı.` : `Assessment complete.`)
          : (lang==="tr" ? `Değerlendirme tamamlandı.` : `Assessment complete.`);
        addMsg(`${prefix}\n\n▸ ${routingLabel.label}`);
      } else {
        addMsg(lang==="tr"
          ? "Tüm sorular tamamlandı. Bu kategoride net bir örüntü eşleşmesi bulunamadı. Lütfen bir sağlık uzmanına başvurun."
          : "All questions complete. No clear pattern match found in this category. Please consult a healthcare professional."
        );
      }
    };

    if (result) { finalize(result, false); return; }
    if (newAsked.length >= MAX_QUESTIONS) {
      finalize(computeOfflineResult(newTriggers, riskMods, 999, akinatorGate, lang, true, newAbsent), true);
      return;
    }

    const nextQ = pickNextQuestion(newAsked, akinatorGate, newTriggers, riskMods, newAnsweredNo, newAbsent);
    if (nextQ) {
      setAkinatorCurrent(nextQ);
      setAkinatorScale(5);
      const totalQs = AKINATOR_QUESTIONS.filter(q => q.ask_if === akinatorGate).length;
      setTimeout(() => addMsg(lang==="tr" ? nextQ.text_tr : nextQ.text_en), 250);
    } else {
      // Bu kapının soruları bitti — zorla karar ver
      finalize(computeOfflineResult(newTriggers, riskMods, 999, akinatorGate, lang, true, newAbsent), true);
    }
  }

  function parseProfile(answers) {
    const p = {};
    for (const [k,v] of Object.entries(answers)) {
      const n = parseFloat(v);
      if (k==="age"&&!isNaN(n)) p.age=n;
      else if (k==="height_cm"&&!isNaN(n)) p.height=n;
      else if (k==="weight_kg"&&!isNaN(n)) p.weight=n;
      else if (k==="sex") p.sex = /female|kadın|kadin/i.test(v) ? "female" : "male";
      else if (k==="smoking") p.smoking = /yes|evet/i.test(v);
      else if (k==="diabetes") p.diabetes = /yes|evet/i.test(v);
      else if (k==="hypertension") p.hypertension = /yes|evet/i.test(v);
      else if (k==="family_history") p.familyHistory = /yes|evet/i.test(v);
    }
    if (p.height && p.weight) p.bmi = p.weight / Math.pow(p.height/100, 2);
    return p;
  }

  const EMERGENCY_PATTERNS = {
    tr: /bilinç kaybı|bayılıyorum|nefes duruyor|kalp durdu|felç geçiriyorum|ölüyorum|çok şiddetli kanama/i,
    en: /unconscious|not breathing|heart stopped|having a stroke|i'm dying|severe bleeding/i,
  };

  function trimHistory(hist) {
    const MAX_TURNS = 12;
    if (hist.length <= MAX_TURNS) return hist;
    return [hist[0], ...hist.slice(-(MAX_TURNS - 1))];
  }

  async function callAPI(system, messages, retries = 2) {
    return callAnthropicLikeBackend({
      model: import.meta.env.VITE_GEMINI_MODEL,
      max_tokens: 1000,
      system,
      messages,
    }, { retries });
  }

  async function handleSymptomTurn(text) {
    if (EMERGENCY_PATTERNS[lang]?.test(text)) {
      const emergencyMsg = lang === "tr"
        ? "Anlattıklarınız acil bir durum işareti taşıyor.\n\nLütfen hemen 112'yi arayın veya en yakın acil servise gidin. SHC'yi beklemeyin."
        : "What you've described may be an emergency.\n\nPlease call 911 immediately or go to your nearest ED. Do not wait for SHC.";
      addMsg(emergencyMsg);
      setLoading(false);
      return;
    }

    // Çevrimdışı modda Akinator başlat
    if (offlineMode) {
      startAkinator();
      return;
    }

    setLoading(true);
    const allSymptoms = (symptomText + " " + text).trim();
    setSymptomText(allSymptoms);
    const newMatches = matchPatterns(allSymptoms, riskMods);
    setMatches(newMatches);

    const rawHistory = [...history, {role:"user", content:text}];
    const trimmedHistory = trimHistory(rawHistory);
    setHistory(rawHistory);

    try {
      const data = await callAPI(
        buildSystemPrompt(lang, allSymptoms, profile, newMatches, followUpHistory, docSummary),
        trimmedHistory
      );
      const raw = data.content?.map(b=>b.text||"").join("") || "";
      let parsed;
      try {
        // Strip markdown fences, leading/trailing whitespace, and any text before first {
        const cleaned = raw.replace(/```json|```/g,"").trim();
        const jsonStart = cleaned.indexOf("{");
        const jsonEnd = cleaned.lastIndexOf("}");
        const jsonStr = jsonStart >= 0 && jsonEnd > jsonStart
          ? cleaned.slice(jsonStart, jsonEnd + 1)
          : cleaned;
        parsed = JSON.parse(jsonStr);
      } catch {
        // Parse failed — show a neutral message, never show raw JSON to user
        const fallbackMsg = lang === "tr"
          ? "Birkaç ayrıntıya daha ihtiyacım var. Şikayetiniz ne zamandır var ve şiddeti 1-10 arasında kaç?"
          : "I need a few more details. How long has this been going on, and how severe is it from 1 to 10?";
        parsed = {text: fallbackMsg, phase:"collecting", differentials:[], routing:null};
      }
      // Never show raw JSON or code as text — if text looks like JSON, replace it
      const displayText = (parsed.text && !parsed.text.trim().startsWith("{") && !parsed.text.trim().startsWith("["))
        ? parsed.text
        : (lang === "tr" ? "Değerlendiriyorum..." : "Processing...");
      addMsg(displayText);
      setHistory(h => [...h, {role:"assistant", content:displayText}]);
      if (parsed.differentials?.length) setDiffs(parsed.differentials);
      if (parsed.lambda != null) setLambda(parsed.lambda);
      if (parsed.routing) {
        // Deterministic clinical safety net — fires regardless of LLM routing
        const sx = allSymptoms.toLowerCase();
        const dT = [];
        if (/jaundice|yellow(ing)? (skin|eyes)|sarıl|gözler.{0,6}sarı|cild.{0,4}sarı|der.{0,4}sarı/.test(sx)) dT.push("jaundice");
        if (/clay.?colou?red stool|pale stool|acholic|açık renkli dışkı|beyaz dışkı|kil renginde/.test(sx)) dT.push("clay_stool");
        if (/fever|febrile|ateş|titreme|üşüme|rigor/.test(sx)) dT.push("fever");
        if (/tachycardi|racing heart|rapid heart|heart racing|kalp.{0,8}hızl|çarpıntı/.test(sx)) dT.push("tachycardia");
        if (/short(ness)? of breath|breathless|nefes darlığı|nefes alam/.test(sx)) dT.push("shortness_of_breath");
        if (/vomit|throwing up|kusma|kusuyor|kustu/.test(sx)) dT.push("vomiting");
        if (/fruity breath|aceton|keton|asetonlu nefes|meyve.{0,5}nefes|nefes.{0,6}meyve/.test(sx)) dT.push("fruity_breath");
        if (/sudden onset|rapid onset|came on (fast|suddenly)|ani(den)? başla|hızla başla|aniden|birden/.test(sx)) dT.push("rapid_onset");
        if (/abdominal pain|stomach pain|belly pain|karın ağrı|mide ağrı/.test(sx)) dT.push("abdominal_pain");
        if (/low blood pressure|hypotension|düşük tansiyon|tansiyon.{0,4}düşük/.test(sx)) dT.push("low_blood_pressure");
        if (/dizz|lighthead|baş dön|sersem/.test(sx)) dT.push("dizziness");
        if (/rebound|releasing the press|bırakınca ağrı|elini? çekince ağrı/.test(sx)) dT.push("rebound_tenderness");
        if (/chest pain|göğüs ağrı/.test(sx)) dT.push("chest_pain");
        if (/cough(ing)? (up )?blood|hemoptys|kan tükür|kanlı balgam/.test(sx)) dT.push("coughing_blood");
        if (/bayıl|bilinc?ini kaybet|kendinden geç|passed out|blacked out|lost consciousness/i.test(sx)) dT.push("loss_of_consciousness");
        if (/boğaz(ım)? (daral|şiş)|dil(im)? şiş|nefes borusu|throat (closing|tight)|tongue swell/i.test(sx)) dT.push("throat_tightness");
        if (/kanama durm|kanamayı durduram|won'?t stop bleeding|bleeding heavily|can'?t stop the bleed/i.test(sx)) dT.push("bleeding_uncontrolled");
        if (/perde in|gölge indi|curtain (over|coming|across)/i.test(sx)) dT.push("curtain_vision");
        if (/ani görme kayb|göremiyorum|görmüyor|lost (my )?vision|can'?t see/i.test(sx)) dT.push("sudden_vision_loss");
        if (/kırmızı çizgi|red streak/i.test(sx)) dT.push("red_streaks");
        // ── "LLM extracts, never decides": karar deterministik SPRT motorunda ──
        const llmPresent = (parsed.symptoms?.present || []).filter(t => ALL_TRIGGERS.has(t));
        const llmAbsent  = (parsed.symptoms?.absent  || []).filter(t => ALL_TRIGGERS.has(t));
        const enginePresent = [...new Set([...llmPresent, ...dT])];
        const engineAbsent = llmAbsent.filter(t => !enginePresent.includes(t));
        // Soft evidence: LLM'in kalibre olasılıkları (Tez 3.3). dT regex tespitleri kesin sayılır (c=1).
        const llmConfRaw = parsed.symptoms?.confidence || {};
        const confMap = {};
        for (const t of [...enginePresent, ...engineAbsent]) {
          const c = llmConfRaw[t];
          if (typeof c === "number" && c >= 0 && c <= 1 && !dT.includes(t)) confMap[t] = c;
        }
        const engineRes = enginePresent.length > 0 ? sprtDecide({
          collected: enginePresent, absent: engineAbsent, riskMods, askedCount: 999,
          gate: null, lang, force: true,
          patternKeys: Object.keys(PATTERNS), PAT: PATTERNS,
          namesTR: OFFLINE_PATTERN_NAMES_TR, urgTR: OFFLINE_URGENCY_TR, urgEN: OFFLINE_URGENCY_EN,
          escalateFn: clinicalEscalation, escNoteFn: escalationNote, redFlagFn: checkRedFlags,
          minQuestions: 0, gatePatterns: GATE_PATTERNS, confMap}) : null;

        let finalRouting, escId = "";
        if (engineRes?.routing) {
          // Güvenlik: motor kıt çıkarımla LLM'in RED'ini ASLA düşürmesin (yalnız yükseltebilir)
          const RANK = { RED:3, GREY:2, YELLOW:1, GREEN:0 };
          finalRouting = (parsed.routing && RANK[parsed.routing] > RANK[engineRes.routing])
            ? parsed.routing : engineRes.routing;
          const advisory = parsed.doctor_alert
            ? (lang==="tr" ? `LLM klinik notu (danışma): ${parsed.doctor_alert}` : `LLM clinical note (advisory): ${parsed.doctor_alert}`)
            : "";
          const disagree = parsed.routing && parsed.routing !== finalRouting
            ? (lang==="tr" ? `LLM yönlendirme görüşü: ${parsed.routing} → motor kararı: ${finalRouting}` : `LLM routing opinion: ${parsed.routing} → engine decision: ${finalRouting}`)
            : "";
          setRouting(finalRouting);
          setUrgency(finalRouting === engineRes.routing ? engineRes.urgency : (lang==="tr"?OFFLINE_URGENCY_TR[finalRouting]:OFFLINE_URGENCY_EN[finalRouting]));
          setSprtViz(engineRes.sprt || null);
          setDoctorAlert([engineRes.doctorAlert, disagree, advisory].filter(Boolean).join("\n\n"));
          setLambda(engineRes.lambda);
        } else {
          // Çıkarım boş — güvenlik ağı: LLM görüşü + deterministik escalation override
          finalRouting = parsed.routing;
          const topConds = [...newMatches.slice(0,3).map(m=>(m.icd||"").toUpperCase()), ...((parsed.differentials||[]).slice(0,3).map(d=>(d.icd||"").toUpperCase()))];
          for (const cid of ["K81","K85","E10","E27.1","K37","N20","I80.2","S06.0","T14.2","S61.9","L03.9","B02.9","L50.9"]) {
            if (topConds.includes(cid)) {
              const r = clinicalEscalation(parsed.routing, cid, dT);
              if (r !== parsed.routing) { finalRouting = r; escId = cid; break; }
            }
          }
          const escNote = escId ? escalationNote(escId, dT, lang) : "";
          setRouting(finalRouting);
          setUrgency(escId ? (lang==="tr"?OFFLINE_URGENCY_TR.RED:OFFLINE_URGENCY_EN.RED) : parsed.urgency);
          setSprtViz(null);
          setDoctorAlert(escNote ? `${escNote}\n\n${parsed.doctor_alert||""}` : parsed.doctor_alert);
          if (escId) setLambda(Math.max(9.6, parsed.lambda || 10));
        }
        setUiPhase("decision");
        setPanelTab("result");
        // If pattern engine found matches, keep them.
        // If empty (short final turn), build matches from LLM differentials so Analiz Motoru isn't blank.
        if (newMatches.length === 0 && parsed.differentials?.length) {
          const syntheticMatches = parsed.differentials.slice(0, 5).map((d, i) => ({
            name: d.name || d.condition || "—",
            icd: d.icd || "—",
            triggerHits: Math.max(1, Math.round((d.score || 50) / 20)),
            sprt_lr: d.lr || d.sprt_lr || 2.0,
            profileMod: d.profileMod || 1.0,
            confirmatoryMet: i === 0,
            routing_if_confirmed: d.routing || parsed.routing || "YELLOW",
            source: d.source || "LLM clinical reasoning",
          }));
          setMatches(syntheticMatches);
        }
      }
// Belirsizlik bayrakları: motorun gerçek sonucundan türetilir (LLM tahminine değil).
      const absSource = (typeof engineRes !== "undefined" && engineRes) ? engineRes : { routing: parsed.routing, diffs: parsed.differentials || [], sprt: null };
      setAbstention(deriveAbstention(absSource));
      if (parsed.phase==="collecting" && parsed.text) setFollowUpHistory(h => { const updated=[...h]; if(updated.length>0&&updated[updated.length-1].a===""){updated[updated.length-1]={...updated[updated.length-1],a:text};} return [...updated,{q:parsed.text,a:""}]; });
    } catch (err) {
      // API hata verince otomatik çevrimdışı moda geç
      setOfflineMode(true);
      const switchMsg = lang === "tr"
        ? "Bağlantı kurulamadı — çevrimdışı moda geçildi.\n\nAşağıdaki listeden size en çok uyan şikayeti seçin:"
        : "Could not connect — switched to offline mode.\n\nSelect the complaint that best describes what you're experiencing:";
      addMsg(switchMsg);
      setTimeout(() => startAkinator(), 100);
    }
    setLoading(false);
  }

  if (!lang) return <OnboardingScreen onStart={startSession} dark={dark} setDark={setDark}/>;

  const t = T[lang];
  const APPLE_ROUTING = getRouting(dark);

  const ar = routing ? APPLE_ROUTING[routing] : null;
  const rl = routing ? t.routing[routing] : null;
  const pct = Math.round((profileIdx / t.questions.length) * 100);
  const needlePct = lambda ? Math.min(Math.max((Math.log10(Math.max(lambda,0.001))+2)/4*100,2),98) : null;
  const needleColor = routing==="RED"?"#c0392b":routing==="GREEN"?"#1a7a3c":routing==="YELLOW"?"#a0522d":"#aeaeb2";


  function exportPDF() {
    const now = new Date();
    const dateStr = now.toLocaleString(lang==="tr"?"tr-TR":"en-GB");
    const tr = lang==="tr";
    const routingColor = routing==="RED"?"#c0392b":routing==="GREEN"?"#1a7a3c":routing==="YELLOW"?"#92400e":"#555";
    const routingBg   = routing==="RED"?"#fef2f2":routing==="GREEN"?"#f0fdf4":routing==="YELLOW"?"#fffbeb":"#f9f9f9";
    const profileStr  = profile ? [
      profile.age   && (tr?`Yaş: ${profile.age}`:`Age: ${profile.age}`),
      profile.sex   && (tr?`Cinsiyet: ${profile.sex==="female"?"Kadın":"Erkek"}`:`Sex: ${profile.sex}`),
      profile.bmi   && `BMI: ${profile.bmi.toFixed(1)}`,
      profile.smoking    && (tr?"Sigara: Evet":"Smoking: Yes"),
      profile.diabetes   && (tr?"Diyabet: Evet":"Diabetes: Yes"),
      profile.hypertension && (tr?"Hipertansiyon: Evet":"Hypertension: Yes"),
      profile.familyHistory && (tr?"Aile Geçmişi: Evet":"Family History: Yes"),
    ].filter(Boolean).join("  ·  ") : "—";

    const diffsHTML = diffs.length>0 ? diffs.slice(0,6).map(d=>{
      const riskColor = d.risk==="critical"?"#c0392b":d.risk==="high"?"#d35400":d.risk==="moderate"?"#92400e":"#1a7a3c";
      return `<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #f0f0f0">
        <div style="flex:1">
          <span style="font-weight:600;color:#111;font-size:11px">${d.name}</span>
          ${d.source?`<span style="color:#aaa;font-size:10px;margin-left:6px">${d.source}</span>`:""}
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <div style="width:80px;height:4px;background:#eee;border-radius:4px;overflow:hidden">
            <div style="height:100%;width:${d.pct}%;background:${riskColor};border-radius:4px"></div>
          </div>
          <span style="font-size:11px;font-weight:600;color:${riskColor};min-width:32px;text-align:right">${d.pct}%</span>
          <span style="font-size:9px;color:#999;text-transform:uppercase;letter-spacing:0.05em;min-width:56px">${d.risk}</span>
        </div>
      </div>`;
    }).join("") : `<p style="color:#aaa;font-size:11px">${tr?"Mevcut değil":"Not available"}</p>`;

    const matchesHTML = matches.length>0 ? matches.slice(0,6).map(m=>`
      <div style="background:#fafafa;border:1px solid #eee;border-radius:8px;padding:10px 14px;margin-bottom:8px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
          <span style="font-weight:600;font-size:11px;color:#111">${m.name}</span>
          <span style="font-size:9px;color:#999">ICD ${m.icd}</span>
        </div>
        <div style="font-size:10px;color:#777;font-family:monospace">${m.triggerHits} hits · LR ${m.sprt_lr} · ×${m.profileMod.toFixed(1)}${m.confirmatoryMet?" · <b style='color:#1a7a3c'>CONF</b>":""}</div>
      </div>`).join("") : `<p style="color:#aaa;font-size:11px">${tr?"Mevcut değil":"Not available"}</p>`;

    const convoHTML = history.map(m=>{
      const isUser = m.role==="user";
      return `<div style="margin-bottom:12px">
        <div style="font-size:9px;font-weight:600;color:${isUser?"#1a7a3c":"#1F3864"};text-transform:uppercase;letter-spacing:0.06em;margin-bottom:3px">${isUser?(tr?"Hasta":"Patient"):"SHC"}</div>
        <div style="font-size:11px;color:#333;line-height:1.6;background:${isUser?"#f8fffe":"#f5f7ff"};border-radius:8px;padding:10px 12px;border-left:3px solid ${isUser?"#1a7a3c":"#1F3864"}">${m.content.replace(/\n/g,"<br>")}</div>
      </div>`;
    }).join("");

    const docSummaryHTML = docSummary ? `
      <div style="margin-top:24px">
        <h2 style="font-size:10px;font-weight:700;color:#999;text-transform:uppercase;letter-spacing:0.1em;margin:0 0 12px">${tr?"Yüklenen Belgeler":"Uploaded Documents"}</h2>
        <div style="background:#fffef0;border:1px solid #e8e0a0;border-radius:10px;padding:14px 16px;font-size:11px;color:#444;line-height:1.7;white-space:pre-wrap">${docSummary}</div>
      </div>` : "";

    const html = `<!DOCTYPE html><html lang="${lang}"><head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      <title>SHC Clinical Report — ${dateStr}</title>
      <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:-apple-system,BlinkMacSystemFont,'Helvetica Neue',Arial,sans-serif;background:#fff;color:#111;font-size:12px;line-height:1.5}
        @media print{body{padding:0}.no-print{display:none!important}@page{margin:20mm 18mm}}
      </style>
    </head><body style="padding:32px 36px;max-width:800px;margin:0 auto">

      <!-- HEADER -->
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:28px;padding-bottom:20px;border-bottom:2px solid #1F3864">
        <div>
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px">
            <div style="width:32px;height:32px;border-radius:8px;background:#1F3864;display:flex;align-items:center;justify-content:center">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            </div>
            <div>
              <div style="font-size:15px;font-weight:700;color:#1F3864;letter-spacing:-0.02em">SHC</div>
              <div style="font-size:10px;color:#888">Standard HealthCare</div>
            </div>
          </div>
        </div>
        <div style="text-align:right">
          <div style="font-size:10px;color:#888;text-transform:uppercase;letter-spacing:0.05em">${tr?"Rapor Tarihi":"Report Date"}</div>
          <div style="font-size:11px;font-weight:600;color:#333;margin-top:2px">${dateStr}</div>
          <div style="margin-top:8px;display:inline-block;padding:3px 10px;background:#fee2e2;border-radius:20px;font-size:9px;font-weight:700;color:#991b1b;letter-spacing:0.05em">${tr?"TANIM YERİNE GEÇMEZ":"NOT A DIAGNOSIS"}</div>
        </div>
      </div>

      <!-- PATIENT + TRIAGE ROW -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px">
        <div style="background:#f8f9fc;border-radius:10px;padding:16px">
          <div style="font-size:9px;font-weight:700;color:#999;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:8px">${tr?"Hasta Profili":"Patient Profile"}</div>
          <div style="font-size:11px;color:#333;line-height:1.8">${profileStr.split("  ·  ").map(s=>`<div>${s}</div>`).join("")}</div>
        </div>
        <div style="background:${routingBg};border:2px solid ${routingColor}22;border-radius:10px;padding:16px;text-align:center;display:flex;flex-direction:column;justify-content:center">
          <div style="font-size:9px;font-weight:700;color:#999;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:10px">${tr?"Triyaj Sonucu":"Triage Result"}</div>
          <div style="font-size:19px;font-weight:700;color:${routingColor};letter-spacing:-0.02em;line-height:1.2">${rl?.label||"—"}</div>
          ${urgency?`<div style="margin-top:8px;font-size:11px;color:${routingColor};background:${routingColor}11;border-radius:6px;padding:6px 10px">${urgency}</div>`:""}
          <div style="margin-top:10px;font-size:10px;color:#aaa;font-family:monospace">λ = ${lambda?.toFixed(3)||"—"}</div>
        </div>
      </div>

      ${doctorAlert?`
      <div style="margin-bottom:24px;background:#fff8f0;border:1px solid #f5a623;border-radius:10px;padding:14px 16px">
        <div style="font-size:9px;font-weight:700;color:#d97706;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:6px">${tr?"Doktor Notu":"Doctor Note"}</div>
        <div style="font-size:11px;color:#333;line-height:1.6">${doctorAlert}</div>
      </div>`:""}

      <!-- DIFFERENTIALS -->
      <div style="margin-bottom:24px">
        <h2 style="font-size:10px;font-weight:700;color:#999;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:12px">${tr?"Olası Tanılar":"Differential Diagnoses"}</h2>
        ${diffsHTML}
      </div>

      <!-- PATTERN ENGINE -->
      ${!offlineMode?`
      <div style="margin-bottom:24px">
        <h2 style="font-size:10px;font-weight:700;color:#999;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:12px">${tr?"Analiz Motoru — Pattern Eşleşmeleri":"Pattern Engine — Matches"}</h2>
        ${matchesHTML}
      </div>`:""}

      ${docSummaryHTML}

      <!-- FOOTER -->
      <div style="border-top:1px solid #eee;padding-top:16px;display:flex;justify-content:space-between;align-items:center">
        <div style="font-size:9px;color:#bbb">SHC · Standard HealthCare · ${dateStr}</div>
        <div style="font-size:9px;color:#bbb">${tr?"Bu rapor karar destek aracı çıktısıdır. Tanı yerine geçmez.":"This report is the output of a decision support tool. Not a clinical diagnosis."}</div>
      </div>

      <script>window.onload=()=>window.print();<\/script>
    </body></html>`;

    const w = window.open("","_blank","width=900,height=700");
    if (w) { w.document.write(html); w.document.close(); }
  }

  const SF = "-apple-system,BlinkMacSystemFont,'SF Pro Text','SF Pro Display','Helvetica Neue',sans-serif";

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100dvh",background:C.bg,fontFamily:SF,overflow:"hidden",fontSize:13,color:C.text,WebkitFontSmoothing:"antialiased"}}>

      <header style={{minHeight:52,borderBottom:`1px solid ${C.sep}`,display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 16px",paddingTop:"env(safe-area-inset-top)",boxSizing:"border-box",flexShrink:0,background:dark?"rgba(28,28,30,0.9)":"rgba(255,255,255,0.9)",backdropFilter:"blur(20px)",WebkitBackdropFilter:"blur(20px)"}}>
        <div style={{display:"flex",alignItems:"center",gap:8,minWidth:0,flex:1}}>
          <button onClick={()=>setDark(v=>!v)} style={{width:28,height:28,borderRadius:"50%",border:"none",background:"transparent",color:C.text3,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            {dark
              ? <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
              : <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>
            }
          </button>
          <div style={{width:26,height:26,borderRadius:6,background:C.dot,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={dark?"#1d1d1f":"white"} strokeWidth="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
          </div>
          <div style={{minWidth:0}}>
            <div style={{fontSize:11,fontWeight:600,color:C.text,letterSpacing:"-0.02em",whiteSpace:"nowrap"}}>SHC</div>
            <div style={{fontSize:8,color:C.text3,letterSpacing:"0.01em",whiteSpace:"nowrap"}}>Standard HealthCare</div>
          </div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:10,flexShrink:0}}>
          
          <button onClick={()=>setDoctorMode(v=>!v)} style={{display:"flex",alignItems:"center",gap:5,padding:"4px 10px",borderRadius:14,background:doctorMode?C.dot:"rgba(128,128,128,0.12)",border:"none",color:doctorMode?(dark?"#1d1d1f":"#ffffff"):C.text3,fontSize:10,fontWeight:500,cursor:"pointer",fontFamily:SF,transition:"all 0.2s",letterSpacing:"-0.01em"}}>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/></svg>
            {lang==="tr"?"Doktor":"Doctor"}
          </button>
          <CloseSessionButton lang={lang} onConfirm={doReset} dark={dark}/>
        </div>
      </header>

      <div style={{flex:1,display:"flex",overflow:"hidden"}}>

        <div style={{flex:1,display:doctorMode?"none":"flex",flexDirection:"column",overflow:"hidden",minWidth:0,background:C.bg}}>
          <div ref={scrollRef} style={{flex:1,overflowY:"auto",padding:offlineMode?"24px 0 calc(env(safe-area-inset-bottom) + 20px)":"24px 0 12px",display:"flex",flexDirection:"column",gap:2,userSelect:"none"}}
            onClick={e=>{
              if(uiPhase!=="profiling" && textareaRef.current && e.target===e.currentTarget){
                textareaRef.current.focus();
              }
            }}>
            {messages.map((msg,i)=>(
              <div key={i} style={{display:"flex",justifyContent:msg.role==="user"?"flex-end":"flex-start",padding:"3px 20px",alignItems:"flex-end",gap:8}}>
                {msg.role!=="user"&&(
                  <div style={{width:28,height:28,borderRadius:"50%",flexShrink:0,background:C.dot,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:2}}>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={dark?"#1d1d1f":"white"} strokeWidth="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                  </div>
                )}
                <div style={{
                  maxWidth:"68%",
                  background:msg.role==="user"?C.userBubble:C.shcBubble,
                  color:msg.role==="user"?C.userText:C.shcText,
                  borderRadius:msg.role==="user"?"18px 18px 4px 18px":"18px 18px 18px 4px",
                  padding:"11px 15px",
                  fontSize:13,
                  lineHeight:1.5,
                  letterSpacing:"-0.01em",
                  whiteSpace:"pre-wrap",
                  fontFamily:SF,
                }}>
                  {msg.text}
                </div>
              </div>
            ))}
            {uiPhase==="profiling" && !loading && (()=>{
              const q = t.questions[profileIdx];
              if (!q) return null;

              if (q.type === "choice") {
                return (
                  <div style={{padding:"4px 20px 4px 56px",display:"flex",gap:8,flexWrap:"wrap"}}>
                    {q.choices.map(choice=>(
                      <button key={choice} onClick={()=>{
                        addMsg(choice,"user");
                        handleProfileAnswer(choice);
                      }} style={{
                        padding:"10px 22px",borderRadius:20,
                        border:`1.5px solid ${C.btnBorder}`,
                        background:C.btnBg,color:C.text,
                        fontSize:13,fontWeight:400,cursor:"pointer",
                        fontFamily:SF,letterSpacing:"-0.01em",transition:"all 0.15s",
                      }}
                      onMouseEnter={e=>{e.currentTarget.style.background=dark?"#48484a":"#f5f5f7";e.currentTarget.style.color=C.text;}}
                      onMouseLeave={e=>{e.currentTarget.style.background=C.btnBg;e.currentTarget.style.color=C.text;}}>
                        {choice}
                      </button>
                    ))}
                  </div>
                );
              }

              if (q.type === "number") {
                const cfg = {
                  age:       {unit:lang==="tr"?"yaş":"yrs", hint:"18–120", min:18, max:120},
                  height_cm: {unit:"cm", hint:"140–220",    min:140, max:220},
                  weight_kg: {unit:"kg", hint:"40–200",     min:40,  max:200},
                }[q.key] || {unit:"", hint:"", min:0, max:999};
                const display = input || "";
                const numVal = parseInt(display, 10);
                const inRange = display.length > 0 && !isNaN(numVal) && numVal >= cfg.min && numVal <= cfg.max;
                const hasInput = display.length > 0;
                const tap = (k) => {
                  if (k==="⌫") { setInput(v=>v.slice(0,-1)); }
                  else if (k==="OK") {
                    if (!hasInput) return;
                    if (!inRange) {
                      const hint = lang==="tr"
                        ? `Lütfen geçerli bir değer girin (${cfg.min}–${cfg.max} ${cfg.unit}).`
                        : `Please enter a valid value (${cfg.min}–${cfg.max} ${cfg.unit}).`;
                      addMsg(hint);
                      setInput("");
                      return;
                    }
                    addMsg(display,"user"); handleProfileAnswer(display); setInput("");
                  }
                  else { if(input.length>=3) return; setInput(v=>v+k); }
                };
                const keys = ["1","2","3","4","5","6","7","8","9","⌫","0","OK"];
                return (
                  <div style={{padding:"6px 20px 6px 20px",display:"flex",gap:14,alignItems:"flex-start"}}>
                    <div style={{display:"flex",flexDirection:"column",justifyContent:"center",minWidth:58,paddingTop:4}}>
                      <div style={{fontSize:22,fontWeight:500,color:display?C.text:C.text3,fontFamily:SF,letterSpacing:"-0.02em",lineHeight:1}}>{display||"—"}</div>
                      <div style={{fontSize:10,color:C.text3,marginTop:3}}>{cfg.unit} · {cfg.hint}</div>
                    </div>
                    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:5}}>
                      {keys.map(k=>(
                        <button key={k} onClick={()=>tap(k)} style={{
                          width:44,height:36,borderRadius:9,border:"none",
                          background:k==="OK"?(inRange?C.dot:C.bg3):k==="⌫"?C.bg2:C.btnBg,
                          color:k==="OK"?(inRange?(dark?"#1d1d1f":"#ffffff"):C.text3):C.text,
                          fontSize:k==="⌫"?15:k==="OK"?12:17,
                          fontWeight:k==="OK"?500:400,
                          cursor:k==="OK"&&!inRange?"default":"pointer",
                          fontFamily:SF,
                          boxShadow:"0 1px 2px rgba(0,0,0,0.07)",
                          transition:"opacity 0.1s",
                        }}
                        onMouseEnter={e=>{if(k!=="OK"||valid)e.currentTarget.style.opacity="0.7";}}
                        onMouseLeave={e=>e.currentTarget.style.opacity="1"}>
                          {k}
                        </button>
                      ))}
                    </div>
                  </div>
                );
              }
              return null;
            })()}
            {/* ── AKİNATOR: KAPI SEÇİMİ ── */}
            {offlineMode && !akinatorGate && !akinatorDone && uiPhase!=="profiling" && !loading && (()=>{
              const gates = AKINATOR_GATES[lang] || AKINATOR_GATES.tr;
              return (
                <div style={{padding:"8px 20px 8px 20px"}}>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,maxWidth:380}}>
                    {gates.map(g=>(
                      <button key={g.id} onClick={()=>handleGateSelect(g.id)} style={{
                        display:"flex",flexDirection:"column",alignItems:"flex-start",
                        padding:"12px 14px",borderRadius:14,
                        border:`1.5px solid ${C.btnBorder}`,
                        background:C.btnBg,cursor:"pointer",fontFamily:SF,
                        textAlign:"left",transition:"all 0.15s",gap:4,
                      }}
                      onMouseEnter={e=>{e.currentTarget.style.background=dark?"#48484a":"#f0f0f2";e.currentTarget.style.borderColor=C.accent;}}
                      onMouseLeave={e=>{e.currentTarget.style.background=C.btnBg;e.currentTarget.style.borderColor=C.btnBorder;}}>
                        <span style={{fontSize:11,fontWeight:500,color:C.text,letterSpacing:"-0.01em",lineHeight:1.3}}>{g.label}</span>
                        <span style={{fontSize:10,color:C.text3,lineHeight:1.3}}>{g.sub}</span>
                      </button>
                    ))}
                  </div>
                </div>
              );
            })()}
            {/* ── AKİNATOR: CEVAP BUTONLARI ── */}
            {offlineMode && akinatorGate && akinatorCurrent && !akinatorDone && uiPhase!=="profiling" && !loading && (()=>{
              const q = akinatorCurrent;
              const totalQs = AKINATOR_QUESTIONS.filter(qq => qq.ask_if === akinatorGate).length;
              const doneQs = akinatorAsked.length;
              if (q.type === "yn") {
                const btns = [
                  { key:"yes", label:lang==="tr"?"✓ Evet":"✓ Yes", bg:dark?"#1a3a1a":"#f0fff4", color:"#166534", border:"rgba(22,101,52,0.3)" },
                  { key:"no",  label:lang==="tr"?"✗ Hayır":"✗ No", bg:dark?"#3a1a1a":"#fff5f5", color:"#c0392b", border:"rgba(192,57,43,0.3)" },
                ];
                return (
                  <div style={{padding:"6px 20px 6px 56px"}}>
                    <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:8}}>
                      {btns.map(b=>(
                        <button key={b.key} onClick={()=>handleAkinatorAnswer(b.key)} style={{
                          padding:"11px 18px",borderRadius:20,border:`1.5px solid ${b.border}`,
                          background:b.bg,color:b.color,fontSize:12,fontWeight:500,cursor:"pointer",
                          fontFamily:SF,letterSpacing:"-0.01em",transition:"all 0.15s",
                        }}
                        onMouseEnter={e=>e.currentTarget.style.opacity="0.8"}
                        onMouseLeave={e=>e.currentTarget.style.opacity="1"}>
                          {b.label}
                        </button>
                      ))}
                    </div>
                  </div>
                );
              }
              if (q.type === "scale") {
                return (
                  <div style={{padding:"6px 20px 10px 56px"}}>
                    <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
                      <span style={{fontSize:10,color:C.text3,minWidth:12}}>1</span>
                      <input type="range" min="1" max="10" value={akinatorScale}
                        onChange={e=>setAkinatorScale(Number(e.target.value))}
                        style={{flex:1,accentColor:C.accent,cursor:"pointer"}}/>
                      <span style={{fontSize:10,color:C.text3,minWidth:16}}>10</span>
                      <div style={{
                        minWidth:38,height:38,borderRadius:"50%",flexShrink:0,
                        background:akinatorScale>=8?"#c0392b":akinatorScale>=5?"#a0522d":"#1a7a3c",
                        display:"flex",alignItems:"center",justifyContent:"center",
                        color:"white",fontSize:13,fontWeight:600,fontFamily:SF,
                        transition:"background 0.2s",
                      }}>
                        {akinatorScale}
                      </div>
                    </div>
                    <div style={{display:"flex",alignItems:"center",gap:8}}>
                      <button onClick={()=>handleAkinatorAnswer("scale", akinatorScale)} style={{
                        padding:"10px 24px",borderRadius:20,border:"none",flexShrink:0,
                        background:C.dot,color:dark?"#1d1d1f":"white",
                        fontSize:12,fontWeight:500,cursor:"pointer",fontFamily:SF,letterSpacing:"-0.01em",
                      }}>
                        {lang==="tr"?"Onayla":"Confirm"} — {akinatorScale}/10
                      </button>
                    </div>
                  </div>
                );
              }
              return null;
            })()}
            {loading&&(
              <div style={{display:"flex",padding:"3px 20px",alignItems:"flex-end",gap:8}}>
                <div style={{width:28,height:28,borderRadius:"50%",background:C.dot,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:2}}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={dark?"#1d1d1f":"white"} strokeWidth="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                </div>
                <div style={{background:C.shcBubble,borderRadius:"18px 18px 18px 4px",padding:"14px 18px",display:"flex",gap:4,alignItems:"center"}}>
                  {[0,1,2].map(j=><div key={j} style={{width:6,height:6,borderRadius:"50%",background:C.text3,animation:`dotBounce 1.2s ${j*0.2}s infinite`}}/>)}
                </div>
              </div>
            )}
            <div ref={bottomRef}/>
          </div>

          {(uiPhase!=="profiling" || !t.questions[profileIdx] || (t.questions[profileIdx].type!=="choice" && t.questions[profileIdx].type!=="number")) && !offlineMode && (
          <div style={{paddingTop:8,paddingLeft:16,paddingRight:16,paddingBottom:"max(12px, calc(env(safe-area-inset-bottom) - 6px))",background:C.surface,borderTop:`1px solid ${C.sep}`,flexShrink:0}}>
            <div style={{display:"flex",gap:8,alignItems:"flex-end",background:C.bg2,borderRadius:22,padding:"8px 8px 8px 16px",transition:"background 0.15s"}}
              onFocusCapture={e=>e.currentTarget.style.background=dark?"#48484a":"#efefef"}
              onBlurCapture={e=>e.currentTarget.style.background=C.bg2}>
              {!offlineMode && (uiPhase==="doc_upload" || uiPhase==="symptoms") && (
                <>
                  <input ref={chatFileRef} type="file" accept=".pdf,.txt,.text,text/plain,application/pdf" style={{display:"none"}} onChange={e=>{const f=e.target.files?.[0]; e.target.value=""; if(f) handleFileUpload(f,"chat");}}/>
                  <button onClick={()=>chatFileRef.current?.click()} disabled={loading} title={lang==="tr"?"Belge yükle":"Upload document"} style={{width:30,height:30,borderRadius:"50%",border:`1px solid ${C.sep}`,flexShrink:0,background:"transparent",color:C.text3,cursor:loading?"default":"pointer",display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.15s"}}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                  </button>
                </>
              )}
              <textarea ref={textareaRef} value={input}
                onChange={e=>{setInput(e.target.value);e.target.style.height="auto";e.target.style.height=Math.min(e.target.scrollHeight,100)+"px";}}
                onKeyDown={handleKey}
                placeholder={t.placeholder_symptom}
                rows={1}
                style={{flex:1,background:"transparent",border:"none",outline:"none",fontFamily:SF,fontSize:14,color:C.text,resize:"none",minHeight:26,maxHeight:100,lineHeight:1.45,padding:"1px 0",letterSpacing:"-0.01em",caretColor:C.accent}}/>
              {!offlineMode && (window.SpeechRecognition||window.webkitSpeechRecognition) && (
                <button onClick={toggleListen} disabled={loading} title={lang==="tr"?"Sesli giriş":"Voice input"} style={{width:30,height:30,borderRadius:"50%",border:"none",flexShrink:0,background:isListening?C.accent:"transparent",color:isListening?"white":C.text3,cursor:loading?"default":"pointer",display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.15s"}}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="2" width="6" height="11" rx="3"/><path d="M19 10a7 7 0 01-14 0"/><line x1="12" y1="19" x2="12" y2="22"/><line x1="8" y1="22" x2="16" y2="22"/></svg>
                </button>
              )}
              <button onClick={send} disabled={loading||!input.trim()} style={{
                width:30,height:30,borderRadius:"50%",border:"none",flexShrink:0,
                background:loading||!input.trim()?"transparent":C.accent,
                cursor:loading||!input.trim()?"default":"pointer",
                display:"flex",alignItems:"center",justifyContent:"center",
                transition:"all 0.15s",
                opacity:loading||!input.trim()?0:1,
              }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" strokeLinecap="round" strokeLinejoin="round"><path d="M12 19V5M5 12l7-7 7 7" stroke="white" strokeWidth="2"/></svg>
              </button>
            </div>
            {uiPhase!=="profiling"&&followUpHistory.length===0&&<div style={{fontSize:10,color:C.text3,marginTop:6,paddingLeft:6,letterSpacing:"-0.01em"}}>{t.hint}</div>}
          </div>
          )}
        </div>

        {doctorMode&&(
          <div style={{flex:1,width:"100%",maxWidth:900,margin:"0 auto",background:C.bg2,display:"flex",flexDirection:"column",overflow:"hidden",fontSize:11}}>
            <div style={{display:"flex",background:C.surface,borderBottom:`1px solid ${C.sep}`,flexShrink:0}}>
              {[{id:"result",label:t.tabResult},{id:"diff",label:t.tabDiff},...(!offlineMode?[{id:"system",label:t.tabEngine}]:[])].map(tab=>(
                <button key={tab.id} onClick={()=>setPanelTab(tab.id)} style={{flex:1,padding:"10px 0",fontSize:10,fontWeight:500,letterSpacing:"-0.01em",border:"none",cursor:"pointer",background:"transparent",color:panelTab===tab.id?C.accent:C.text3,borderBottom:panelTab===tab.id?`1.5px solid ${C.accent}`:"1.5px solid transparent",transition:"all 0.15s",fontFamily:SF}}>{tab.label}</button>
              ))}
            </div>
            <div style={{flex:1,overflowY:"auto",padding:"16px 14px"}}>

              {panelTab==="result"&&<>
                {profile&&(
                  <div style={{marginBottom:16}}>
                    <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:8,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.patientLabel}</div>
                    <div style={{display:"flex",flexWrap:"wrap",gap:4}}>
                      {[profile.age&&`${profile.age}y`,profile.sex&&(profile.sex==="female"?(lang==="tr"?"K":"F"):(lang==="tr"?"E":"M")),profile.bmi&&`BMI ${profile.bmi.toFixed(0)}`,profile.smoking&&(lang==="tr"?"Sigara":"Smoker"),profile.diabetes&&"DM",profile.hypertension&&"HTN",profile.familyHistory&&"FHx"].filter(Boolean).map(chip=>(
                        <span key={chip} style={{background:C.bg2,borderRadius:5,padding:"2px 8px",fontSize:10,color:C.text,fontWeight:400,border:`1px solid ${C.sep}`}}>{chip}</span>
                      ))}
                    </div>
                  </div>
                )}

                <div style={{marginBottom:16}}>
                  <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:8,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.triageLabel}</div>
                  {!routing?(
                    <div style={{border:`1px solid ${C.sep}`,borderRadius:12,padding:"20px 14px",textAlign:"center",background:C.bg2}}>
                      <div style={{fontSize:11,color:C.text3,lineHeight:1.5}}>{t.awaiting}</div>
                    </div>
                  ):(
                    <div style={{border:`1px solid ${ar.border}`,borderRadius:12,background:ar.bg,padding:"16px 14px",textAlign:"center"}}>
                      <div style={{width:8,height:8,borderRadius:"50%",background:ar.dot,margin:"0 auto 10px",boxShadow:`0 0 0 3px ${ar.border}`}}/>
                      <div style={{fontSize:12,fontWeight:600,color:ar.color,lineHeight:1.3,marginBottom:4,letterSpacing:"-0.02em"}}>{rl.label}</div>
                      {lambda&&<div style={{fontSize:9,color:C.text3,marginTop:8,fontFamily:"'SF Mono','Menlo',monospace"}}>λ = {lambda.toFixed(3)}</div>}
                    </div>
                  )}
                  {routing&&(()=>{
                    // Karar özeti QR'ı — hasta doktoruna gösterir / ekran fotosu / indirir. Tüm veri kodun içinde.
                    const reason = (() => {
                      const top = diffs && diffs[0];
                      if (routing==="RED") return lang==="tr"?"Acil bulgu / kritik ayırıcı dışlanamadı":"Emergent finding / critical differential not excluded";
                      if (routing==="GREY") return lang==="tr"?"Örüntü belirsiz — değerlendirme gerekli":"Pattern unclear — evaluation needed";
                      return top ? (lang==="tr"?`Olası: ${top.name}`:`Likely: ${top.name}`) : (lang==="tr"?"Örüntü değerlendirildi":"Pattern assessed");
                    })();
                    const sxList = symptomText
                      ? symptomText.toLowerCase().split(/[\s,.;]+/).filter(Boolean).slice(0,10)
                      : (diffs&&diffs[0]?[diffs[0].name]:[]);
                    const payload = buildQRPayload(routing, sxList, lambda, reason, lang, doctorAlert, diffs, sprtViz);
                    let mat; try { mat = qrMatrix(payload); } catch(e){ return null; }
                    const N = mat.length, quiet = 4, dim = N + quiet*2, px = 8;
                    const W = dim*px;
                    const darkPath = mat.flatMap((row,r)=>row.map((v,c)=>v?`M${(c+quiet)*px} ${(r+quiet)*px}h${px}v${px}h-${px}z`:"")).filter(Boolean).join("");
                    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${W}" viewBox="0 0 ${W} ${W}"><rect width="${W}" height="${W}" fill="#fff"/><path d="${darkPath}" fill="#000"/></svg>`;
                    const dataUrl = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(svg)));
                    return (
                      <div style={{marginTop:10,padding:"12px",borderRadius:12,border:`1px solid ${C.sep}`,background:C.bg2,textAlign:"center"}}>
                        <div style={{fontSize:11,fontWeight:600,color:C.text,marginBottom:10,letterSpacing:"-0.01em"}}>{t.qrLabel}</div>
                        <div style={{display:"inline-block",padding:12,background:"#fff",borderRadius:14,boxShadow:dark?"0 2px 12px rgba(0,0,0,0.4)":"0 1px 4px rgba(0,0,0,0.08)"}}>
                          <img src={dataUrl} alt="QR" style={{display:"block",width:"min(82vw, 340px)",height:"auto",imageRendering:"pixelated"}}/>
                        </div>
                      </div>
                    );
                  })()}
                  {routing&&!offlineMode&&(
                    <button onClick={exportPDF} style={{marginTop:8,width:"100%",padding:"9px 0",borderRadius:8,border:`1px solid ${C.sep}`,background:C.bg2,color:C.text3,cursor:"pointer",fontFamily:"inherit",fontSize:11,fontWeight:500,display:"flex",alignItems:"center",justifyContent:"center",gap:6,transition:"all 0.2s",letterSpacing:"-0.01em"}}>
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/></svg>
                      {lang==="tr"?"PDF Raporu İndir":"Download PDF Report"}
                    </button>
                  )}
                </div>

                <div style={{marginBottom:16}}>
                  <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:8,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.sprtLabel}</div>
                  <div style={{display:"flex",justifyContent:"space-between",fontSize:9,marginBottom:5,color:C.text3}}><span style={{color:C.text3}}>{t.safe}</span><span style={{color:C.text3}}>{t.critical}</span></div>
                  <div style={{height:4,borderRadius:4,position:"relative",overflow:"visible",background:"linear-gradient(to right,rgba(26,122,60,0.25),rgba(160,82,45,0.2),rgba(192,57,43,0.3))",border:`1px solid ${C.sep}`}}>
                    {needlePct!==null&&<div style={{position:"absolute",top:"50%",transform:"translate(-50%,-50%)",left:needlePct+"%",width:3,height:14,borderRadius:2,background:needleColor,transition:"left 0.9s cubic-bezier(0.34,1.56,0.64,1)"}}/>}
                  </div>
                  <div style={{textAlign:"center",fontFamily:"'SF Mono','Menlo',monospace",fontSize:9,color:C.text3,marginTop:5}}>{lambda?`λ = ${lambda.toFixed(3)}`:"—"}</div>
                  {sprtViz?.traj?.length > 1 && (() => {
                    const A = sprtViz.A, B = sprtViz.B, pts = sprtViz.traj;
                    const W = 260, H = 92, PAD = 8;
                    const yOf = s => { const c = Math.max(-4.2, Math.min(4.2, s)); return H/2 - (c/4.2)*(H/2 - PAD); };
                    const xOf = idx => PAD + (idx/(Math.max(pts.length-1,1)))*(W-2*PAD);
                    const dPath = pts.map((p,idx)=>`${idx===0?"M":"L"}${xOf(idx).toFixed(1)},${yOf(p.S).toFixed(1)}`).join(" ");
                    return (
                      <div style={{marginTop:10}}>
                        <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{display:"block",background:C.bg2,border:`1px solid ${C.sep}`,borderRadius:8}}>
                          <line x1={PAD} x2={W-PAD} y1={yOf(B)} y2={yOf(B)} stroke="#c0392b" strokeWidth="1" strokeDasharray="4 3" opacity="0.7"/>
                          <line x1={PAD} x2={W-PAD} y1={yOf(A)} y2={yOf(A)} stroke="#1a7a3c" strokeWidth="1" strokeDasharray="4 3" opacity="0.7"/>
                          <line x1={PAD} x2={W-PAD} y1={yOf(0)} y2={yOf(0)} stroke={C.text3} strokeWidth="0.5" opacity="0.25"/>
                          <path d={dPath} fill="none" stroke={needleColor} strokeWidth="1.8" strokeLinejoin="round" strokeLinecap="round"/>
                          {pts.map((p,idx)=>(<circle key={idx} cx={xOf(idx)} cy={yOf(p.S)} r="2" fill={needleColor}/>))}
                          <text x={W-PAD} y={yOf(B)-3} textAnchor="end" fontSize="7" fill="#c0392b" fontFamily="monospace">b=+{B.toFixed(2)}</text>
                          <text x={W-PAD} y={yOf(A)+9} textAnchor="end" fontSize="7" fill="#1a7a3c" fontFamily="monospace">a={A.toFixed(2)}</text>
                        </svg>
                        <div style={{textAlign:"center",fontFamily:"'SF Mono','Menlo',monospace",fontSize:9,color:C.text3,marginTop:5}}>
                          Sₙ — {sprtViz.topKey} · S = {sprtViz.S.toFixed(2)}{sprtViz.abstained ? (lang==="tr"?" · ÇEKİMSER":" · ABSTAIN") : ""}
                        </div>
                      </div>
                    );
                  })()}
                </div>

                {doctorAlert&&(
                  <div style={{marginBottom:16}}>
                    <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:8,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.alertLabel}</div>
                    <div style={{background:C.bg2,border:`1px solid ${C.sep}`,borderRadius:10,padding:"10px 12px",fontSize:11,color:C.text,lineHeight:1.6,borderLeft:`3px solid ${C.sep}`}}>
                      {doctorAlert}
                    </div>
                  </div>
                )}

                <div>
                  <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:8,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.uncertaintyLabel}</div>
                  {t.uFlags.map(({k,label})=>{
                    const on=!!abstention[k];
                    return(
                      <div key={k} style={{display:"flex",alignItems:"center",gap:8,padding:"6px 0",borderBottom:`1px solid ${C.sep}`}}>
                        <div style={{width:5,height:5,borderRadius:"50%",flexShrink:0,background:on?C.text:"rgba(128,128,128,0.2)"}}/>
                        <div style={{fontSize:11,color:on?C.text:C.text3,flex:1,letterSpacing:"-0.01em"}}>{label}</div>
                        {on&&<div style={{fontSize:9,color:C.text3,fontWeight:500}}>{lang==="tr"?"aktif":"active"}</div>}
                      </div>
                    );
                  })}
                </div>
              </>}

              {panelTab==="diff"&&<>
                <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:14,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.diffLabel}</div>
                {diffs.length===0?(
                  <div style={{fontSize:11,color:C.text3,textAlign:"center",padding:"32px 0",lineHeight:1.6,whiteSpace:"pre-line"}}>{t.diffEmpty}</div>
                ):diffs.slice(0,6).map((d,i)=>{
                  return(
                    <div key={i} style={{marginBottom:16,paddingBottom:16,borderBottom:`1px solid ${C.sep}`}}>
                      <div style={{display:"flex",justifyContent:"space-between",alignItems:"baseline",marginBottom:6}}>
                        <div style={{fontSize:11,fontWeight:500,color:C.text,letterSpacing:"-0.01em"}}>{d.name}</div>
                        <div style={{fontSize:11,fontWeight:500,color:C.text,fontFamily:"'SF Mono','Menlo',monospace"}}>{d.pct}%</div>
                      </div>
                      <div style={{height:2,background:C.sep,borderRadius:2,overflow:"hidden"}}>
                        <div style={{height:"100%",width:d.pct+"%",background:C.text,borderRadius:2,transition:"width 0.9s ease"}}/>
                      </div>
                      <div style={{display:"flex",justifyContent:"space-between",marginTop:5}}><span style={{fontSize:9,color:C.text3,textTransform:"capitalize"}}>{d.risk}</span>{d.source&&<span style={{fontSize:8,color:C.text3,opacity:0.7}}>{d.source}</span>}</div>
                    </div>
                  );
                })}
              </>}

              {panelTab==="system"&&<>
                <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:14,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.engineLabel}</div>
                {matches.length===0?(
                  <div style={{fontSize:11,color:C.text3,textAlign:"center",padding:"32px 0",lineHeight:1.6,whiteSpace:"pre-line"}}>{t.engineEmpty}</div>
                ):matches.slice(0,5).map((m,i)=>(
                  <div key={i} style={{marginBottom:10,padding:"10px 12px",background:C.bg2,border:`1px solid ${C.sep}`,borderRadius:10}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:3}}>
                      <div style={{fontSize:11,fontWeight:500,color:C.text,letterSpacing:"-0.01em"}}>{m.name}</div>
                      {m.confirmatoryMet&&<span style={{fontSize:8,color:C.text3,fontWeight:500,letterSpacing:"0.02em"}}>CONF</span>}
                    </div>
                    <div style={{fontSize:9,color:C.text3,fontFamily:"'SF Mono','Menlo',monospace"}}>{m.triggerHits} hits · LR {m.sprt_lr} · ×{m.profileMod.toFixed(1)}</div>
                    <div style={{fontSize:9,color:C.text3,marginTop:2}}>ICD {m.icd}</div>
                  </div>
                ))}
                <div style={{marginTop:12,padding:"10px 12px",background:C.bg2,borderRadius:10,border:`1px solid ${C.sep}`}}>
                  <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:5,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.sourcesLabel}</div>
                  <div style={{fontSize:10,color:C.text3,lineHeight:1.8,letterSpacing:"-0.01em"}}>ADA 2025 · AHA/ACC · EULAR/ACR<br/>GINA · GOLD · MDS · NICE NG240<br/>USPSTF · WHO · ESC · IDSA</div>
                </div>
              </>}
            </div>
          </div>
        )}
      </div>

      <style>{`
        :root{--ph:${C.placeholder}}
        textarea::placeholder{color:var(--ph)!important}
        @keyframes dotBounce{0%,80%,100%{transform:translateY(0);opacity:0.3}40%{transform:translateY(-4px);opacity:1}}
        *{box-sizing:border-box;-webkit-tap-highlight-color:transparent;outline:none}
        button{outline:none!important;-webkit-appearance:none}
        button:focus,button:focus-visible,button:focus-within{outline:none!important;box-shadow:none!important}
        textarea:focus{outline:none}
        html{touch-action:manipulation}
        input,textarea,select{font-size:14px!important}
        ::-webkit-scrollbar{width:0}
      `}</style>
    </div>
  );
}


export default App;
