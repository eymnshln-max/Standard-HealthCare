# SHC Triage — Modular React + Gemini Backend

This project was refactored from the original single-file `shc-triage.tsx` into a modular React/Vite frontend and a small Express backend that calls Gemini securely.

## Structure

```text
src/
  App.tsx
  components/
    CloseSessionButton.tsx
    OnboardingScreen.tsx
  constants/
    routingTheme.ts
    translations.ts
  services/
    aiClient.ts
  types/
    anthropic.ts
  utils/
    clinicalEngine.ts
    qrcodeGenerator.ts
    reportUtils.ts
server/
  src/
    adapters/
      anthropicGeminiAdapter.ts
    routes/
      chat.ts
    services/
      geminiClient.ts
    types/
      anthropic.ts
    index.ts
```

## Gemini key

Copy `.env.example` to `.env` and fill in your key:

```bash
cp .env.example .env
```

```env
GEMINI_API_KEY=your_gemini_api_key_here
GEMINI_MODEL=gemini-2.5-flash
```

The key stays on the backend. Do not place it in React code.

## Run locally

```bash
npm install
npm run dev
```

The React app runs on `http://localhost:5173`; the API server runs on `http://localhost:3001`.

## What changed

The previous direct Anthropic call was replaced by:

- `src/services/aiClient.ts`: frontend request client calling `/api/chat`
- `server/src/routes/chat.ts`: backend route
- `server/src/adapters/anthropicGeminiAdapter.ts`: Anthropic-like request/response translation layer
- `server/src/services/geminiClient.ts`: Gemini SDK client using `GEMINI_API_KEY`

The frontend still receives an Anthropic-like response:

```ts
response.content[0].text
```

That keeps the existing app logic intact while Gemini handles generation behind the proxy.

## PDF/document support

The adapter maps the existing Anthropic-style document block:

```ts
{ type: "document", source: { type: "base64", media_type: "application/pdf", data } }
```

to Gemini inline data:

```ts
{ inlineData: { mimeType: "application/pdf", data } }
```

## Notes

This is still a clinical decision-support app, not a diagnostic device. Production deployment should add authentication, request logging policy, rate limiting, abuse protection, and a stricter privacy/compliance review before handling real patient data.

## Deploy as a website

This package can run as a single Node web service. Build the React app, then start the Express server; the server will serve `dist/` and keep `/api/chat` private on the backend. See `README_DEPLOY.md` for Render/Railway commands and environment variables.

