export type AnthropicRole = "user" | "assistant";

export type AnthropicTextBlock = {
  type: "text";
  text: string;
};

export type AnthropicDocumentBlock = {
  type: "document";
  source: {
    type: "base64";
    media_type: string;
    data: string;
  };
};

export type AnthropicContentBlock = AnthropicTextBlock | AnthropicDocumentBlock;

export type AnthropicMessage = {
  role: AnthropicRole;
  content: string | AnthropicContentBlock[];
};

export type AnthropicLikeRequest = {
  model?: string;
  max_tokens?: number;
  temperature?: number;
  system?: string;
  messages: AnthropicMessage[];
};

export type AnthropicLikeResponse = {
  id: string;
  type: "message";
  role: "assistant";
  model: string;
  content: AnthropicTextBlock[];
  stop_reason: "end_turn" | "max_tokens" | "stop_sequence" | "tool_use" | "refusal";
  stop_sequence: string | null;
  usage: {
    input_tokens: number;
    output_tokens: number;
  };
};
