import type {
  AnthropicContentBlock,
  AnthropicLikeResponse,
  AnthropicMessage,
} from "../types/anthropic";

type GeminiPart =
  | { text: string }
  | { inlineData: { mimeType: string; data: string } };

type GeminiContent = {
  role: "user" | "model";
  parts: GeminiPart[];
};

function blockToGeminiPart(block: AnthropicContentBlock): GeminiPart | null {
  if (block.type === "text") return { text: block.text };

  if (block.type === "document" && block.source?.type === "base64") {
    return {
      inlineData: {
        mimeType: block.source.media_type,
        data: block.source.data,
      },
    };
  }

  return null;
}

function normalizeContent(content: AnthropicMessage["content"]): GeminiPart[] {
  if (typeof content === "string") return [{ text: content }];

  const parts = content
    .map(blockToGeminiPart)
    .filter((part): part is GeminiPart => Boolean(part));

  return parts.length > 0 ? parts : [{ text: "" }];
}

export function anthropicMessagesToGeminiContents(messages: AnthropicMessage[]): GeminiContent[] {
  return messages.map((message) => ({
    role: message.role === "assistant" ? "model" : "user",
    parts: normalizeContent(message.content),
  }));
}

function mapFinishReason(reason?: string) {
  switch (reason) {
    case "STOP":
      return "end_turn" as const;
    case "MAX_TOKENS":
      return "max_tokens" as const;
    case "SAFETY":
    case "RECITATION":
      return "refusal" as const;
    default:
      return "end_turn" as const;
  }
}

export function geminiResponseToAnthropicLike(params: {
  model: string;
  text: string;
  finishReason?: string;
  inputTokens?: number;
  outputTokens?: number;
}): AnthropicLikeResponse {
  return {
    id: `msg_${Date.now()}`,
    type: "message",
    role: "assistant",
    model: params.model,
    content: [{ type: "text", text: params.text }],
    stop_reason: mapFinishReason(params.finishReason),
    stop_sequence: null,
    usage: {
      input_tokens: params.inputTokens ?? 0,
      output_tokens: params.outputTokens ?? 0,
    },
  };
}
