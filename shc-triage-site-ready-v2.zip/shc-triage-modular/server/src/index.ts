import "dotenv/config";
import cors from "cors";
import express from "express";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chatRouter } from "./routes/chat";

const app = express();
const port = Number(process.env.PORT || 3001);
const clientOrigin = process.env.CLIENT_ORIGIN;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, "../..");
const distDir = path.join(projectRoot, "dist");
const indexHtml = path.join(distDir, "index.html");

if (clientOrigin) {
  app.use(cors({ origin: clientOrigin }));
}

app.use(express.json({ limit: "30mb" }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

app.use("/api/chat", chatRouter);

if (fs.existsSync(indexHtml)) {
  app.use(express.static(distDir));

  app.use((req, res, next) => {
    if (req.method !== "GET" || req.path.startsWith("/api/")) {
      return next();
    }

    return res.sendFile(indexHtml);
  });
}

app.use((error: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  const status = typeof error?.status === "number" ? error.status : 500;
  const message = error?.message || "Internal server error";
  console.error(error);
  res.status(status).json({ error: message });
});

app.listen(port, () => {
  console.log(`SHC site running on http://localhost:${port}`);
});
