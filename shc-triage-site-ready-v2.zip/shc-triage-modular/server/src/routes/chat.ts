import { Router } from "express";
import { gemini } from "../services/geminiClient";
import {
  anthropicMessagesToGeminiContents,
  geminiResponseToAnthropicLike,
} from "../adapters/anthropicGeminiAdapter";
import type { AnthropicLikeRequest } from "../types/anthropic";

export const chatRouter = Router();

function extractText(response: any): string {
  if (typeof response?.text === "string") return response.text;

  const parts = response?.candidates?.[0]?.content?.parts ?? [];
  return parts
    .map((part: any) => typeof part?.text === "string" ? part.text : "")
    .join("")
    .trim();
}

chatRouter.post("/", async (req, res, next) => {
  try {
    const body = req.body as AnthropicLikeRequest;

    if (!Array.isArray(body.messages)) {
      res.status(400).json({ error: "messages must be an array" });
      return;
    }

    const model = body.model || process.env.GEMINI_MODEL || "gemini-2.5-flash";

    const wantsStrictJson = /Respond ONLY in this exact JSON|exact JSON|ONLY in this exact JSON/i.test(body.system || "");
    const jsonGuard = wantsStrictJson
      ? `

GEMINI OUTPUT CONTRACT:
Return a single valid JSON object only. No markdown, no prose before or after it, no code fences.
The JSON must be parseable by JSON.parse. Escape all line breaks inside string values as \n.
If you need more information, keep routing null, phase "collecting", and put exactly one follow-up question in text.`
      : "";

    const config: any = {
      systemInstruction: `${body.system || ""}${jsonGuard}`,
      maxOutputTokens: body.max_tokens ?? 1400,
      temperature: body.temperature ?? 0.1,
    };

    if (wantsStrictJson) {
      config.responseMimeType = "application/json";
    }

    const response = await gemini.models.generateContent({
      model,
      contents: anthropicMessagesToGeminiContents(body.messages),
      config,
    });

    const text = extractText(response);
    const candidate = (response as any)?.candidates?.[0];
    const usage = (response as any)?.usageMetadata;

    res.json(geminiResponseToAnthropicLike({
      model,
      text,
      finishReason: candidate?.finishReason,
      inputTokens: usage?.promptTokenCount,
      outputTokens: usage?.candidatesTokenCount,
    }));
  } catch (error) {
    next(error);
  }
});
