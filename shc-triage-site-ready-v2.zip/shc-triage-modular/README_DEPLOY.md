# Deploying SHC Triage as a Website

This package is prepared for a single-service deployment: the Express server exposes `/api/chat` and also serves the built React app from `dist/`.

## Required environment variables

```env
GEMINI_API_KEY=your_real_gemini_key
GEMINI_MODEL=gemini-2.5-flash
NODE_ENV=production
```

`PORT` is usually provided by the hosting platform. Do not put `GEMINI_API_KEY` in React/Vite public variables.

## Local production test

```bash
npm install
cp .env.example .env
npm run build
npm start
```

Open `http://localhost:3001`.

## Render setup

Create a new Web Service from your GitHub repository.

Build command:

```bash
npm install && npm run build
```

Start command:

```bash
npm start
```

Add environment variables in the Render dashboard:

```env
GEMINI_API_KEY=...
GEMINI_MODEL=gemini-2.5-flash
NODE_ENV=production
```

## Railway setup

Create a new project from your GitHub repository.

Build command:

```bash
npm install && npm run build
```

Start command:

```bash
npm start
```

Add the same environment variables.

## Frontend/backend split option

If you deploy the React app separately on Vercel/Netlify and the API separately on Render/Railway, set:

```env
CLIENT_ORIGIN=https://your-frontend-domain.com
```

Then change the frontend API base URL in `src/services/aiClient.ts` or configure a rewrite/proxy on the frontend host. The single-service deployment avoids this complexity.
