import { Router } from "express";
import { gemini } from "../services/geminiClient";
import {
  anthropicMessagesToGeminiContents,
  geminiResponseToAnthropicLike,
} from "../adapters/anthropicGeminiAdapter";
import type { AnthropicLikeRequest } from "../types/anthropic";

export const chatRouter = Router();

function extractText(response: any): string {
  if (typeof response?.text === "string") return response.text;

  const parts = response?.candidates?.[0]?.content?.parts ?? [];
  return parts
    .map((part: any) => typeof part?.text === "string" ? part.text : "")
    .join("")
    .trim();
}

chatRouter.post("/", async (req, res, next) => {
  try {
    const body = req.body as AnthropicLikeRequest;

    if (!Array.isArray(body.messages)) {
      res.status(400).json({ error: "messages must be an array" });
      return;
    }

    const model = body.model || process.env.GEMINI_MODEL || "gemini-2.5-flash";

    const response = await gemini.models.generateContent({
      model,
      contents: anthropicMessagesToGeminiContents(body.messages),
      config: {
        systemInstruction: body.system,
        maxOutputTokens: body.max_tokens ?? 1000,
        temperature: body.temperature ?? 0.2,
      },
    });

    const text = extractText(response);
    const candidate = (response as any)?.candidates?.[0];
    const usage = (response as any)?.usageMetadata;

    res.json(geminiResponseToAnthropicLike({
      model,
      text,
      finishReason: candidate?.finishReason,
      inputTokens: usage?.promptTokenCount,
      outputTokens: usage?.candidatesTokenCount,
    }));
  } catch (error) {
    next(error);
  }
});
