import { Router } from "express";
import { gemini } from "../services/geminiClient";
import type { GeminiConversationMessage, GeminiGenerateRequest, GeminiPart } from "../types/gemini";

export const geminiRouter = Router();

type NativeGeminiPart = { text: string } | { inlineData: { mimeType: string; data: string } };

function normalizeParts(content: string | GeminiPart[]): NativeGeminiPart[] {
  if (typeof content === "string") return [{ text: trimText(content) }];

  const parts: NativeGeminiPart[] = [];
  for (const part of content) {
    if (part.type === "text") {
      parts.push({ text: trimText(part.text) });
    } else if (part.type === "inline_data") {
      parts.push({ inlineData: { mimeType: part.mimeType, data: part.data } });
    }
  }
  return parts;
}

function trimText(text: string, maxChars = 9000) {
  const value = String(text || "");
  if (value.length <= maxChars) return value;
  return `${value.slice(0, maxChars)}\n\n[content truncated by SHC server]`;
}

function compactMessages(messages: GeminiConversationMessage[], mode: string) {
  // Gemini Flash is more likely to fail or time out with a long accumulated chat.
  // Keep document calls intact, but keep triage history bounded.
  if (mode === "document_summary") return messages.slice(-4);
  return messages.slice(-12);
}

function toGeminiContents(messages: GeminiConversationMessage[], mode: string) {
  return compactMessages(messages, mode).map((message) => ({
    role: message.role === "model" ? "model" : "user",
    parts: normalizeParts(message.content),
  }));
}

function extractText(response: any): string {
  if (typeof response?.text === "string") return response.text.trim();

  const parts = response?.candidates?.[0]?.content?.parts ?? [];
  return parts
    .map((part: any) => (typeof part?.text === "string" ? part.text : ""))
    .join("")
    .trim();
}

function jsonFromText(text: string): string | null {
  const cleaned = (text || "").replace(/```json|```/g, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end <= start) return null;

  const candidate = cleaned.slice(start, end + 1);
  try {
    JSON.parse(candidate);
    return candidate;
  } catch {
    return null;
  }
}

function lastUserText(messages: GeminiConversationMessage[]) {
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    const message = messages[i];
    if (message.role !== "user") continue;
    if (typeof message.content === "string") return message.content;
    const text = message.content
      .filter((part) => part.type === "text")
      .map((part: any) => part.text)
      .join(" ")
      .trim();
    if (text) return text;
  }
  return "";
}

function fallbackQuestion(messages: GeminiConversationMessage[], systemInstruction: string): string {
  const isTr = /Turkish|Türkçe|Turkce/i.test(systemInstruction || "");
  const last = lastUserText(messages).toLowerCase();

  if (/karın|mide|abdomen|stomach|belly/.test(last)) {
    return isTr
      ? "Bulantı, kusma, ateş, ishal, dışkıda kan/siyahlık veya idrar yaparken yanma var mı?"
      : "Do you also have nausea, vomiting, fever, diarrhea, black/bloody stool, or burning with urination?";
  }

  if (/göğüs|chest|nefes|breath/.test(last)) {
    return isTr
      ? "Ağrı nefes darlığı, terleme, bayılma hissi, çeneye/kola yayılma veya eforla artma ile birlikte mi?"
      : "Is it associated with shortness of breath, sweating, faintness, radiation to jaw/arm, or worsening with exertion?";
  }

  return isTr
    ? "Birkaç ayrıntıya daha ihtiyacım var. Şikayetiniz ne zamandır var, şiddeti nasıl ve eşlik eden ateş, kusma, kanama, bayılma veya nefes darlığı var mı?"
    : "I need a few more details. How long has this been present, how severe is it, and do you have fever, vomiting, bleeding, fainting, or shortness of breath?";
}

function safeTriageJson(text: string, systemInstruction: string, messages: GeminiConversationMessage[]): string {
  const parsed = jsonFromText(text);
  if (parsed) return parsed;

  return JSON.stringify({
    text: fallbackQuestion(messages, systemInstruction),
    phase: "collecting",
    differentials: [],
    symptoms: { present: [], absent: [], confidence: {} },
    routing: null,
    lambda: null,
    urgency: null,
    doctor_alert: null,
    abstention: { boundary: false, multiple: false, unusual: false },
  });
}

function triageContract() {
  return `

GOOGLE GEMINI OUTPUT CONTRACT FOR SHC:
You are not the routing decision-maker. The browser-side SPRT engine makes the final routing decision.
Your job is structured symptom extraction plus exactly one next follow-up question when phase is collecting.
Return one valid JSON object only. No markdown. No prose outside JSON. No code fences.
Use double quotes for all JSON keys and strings. Do not use trailing commas.
If information is insufficient, set phase to "collecting", routing to null, lambda to null, and put exactly one focused follow-up question in text.
Do not repeat a question already answered in the conversation. If onset/duration and severity are already present, ask associated symptoms or red flags next.
`;
}

function triageResponseSchema() {
  return {
    type: "object",
    properties: {
      text: { type: "string" },
      phase: { type: "string", enum: ["collecting", "decision"] },
      differentials: {
        type: "array",
        items: {
          type: "object",
          properties: {
            name: { type: "string" },
            condition: { type: "string" },
            icd: { type: "string" },
            score: { type: "number" },
            lr: { type: "number" },
            sprt_lr: { type: "number" },
            routing: { type: "string", enum: ["RED", "YELLOW", "GREEN", "GREY"] },
          },
        },
      },
      symptoms: {
        type: "object",
        properties: {
          present: { type: "array", items: { type: "string" } },
          absent: { type: "array", items: { type: "string" } },
          confidence: {
            type: "object",
            additionalProperties: { type: "number" },
          },
        },
        required: ["present", "absent", "confidence"],
      },
      routing: { type: ["string", "null"], enum: ["RED", "YELLOW", "GREEN", "GREY", null] },
      lambda: { type: ["number", "null"] },
      urgency: { type: ["string", "null"] },
      doctor_alert: { type: ["string", "null"] },
      abstention: {
        type: "object",
        properties: {
          boundary: { type: "boolean" },
          multiple: { type: "boolean" },
          unusual: { type: "boolean" },
        },
        required: ["boundary", "multiple", "unusual"],
      },
    },
    required: ["text", "phase", "differentials", "symptoms", "routing", "lambda", "urgency", "doctor_alert", "abstention"],
  };
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function isRetryableGeminiError(error: any) {
  const message = String(error?.message || error || "").toLowerCase();
  return /429|500|502|503|504|resource_exhausted|unavailable|deadline|timeout|temporarily|overloaded/.test(message);
}

async function generateWithRetry(params: any, attempts = 3) {
  let lastError: unknown;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      return await gemini.models.generateContent(params);
    } catch (error) {
      lastError = error;
      if (!isRetryableGeminiError(error) || attempt === attempts - 1) break;
      await sleep(1000 * Math.pow(2, attempt));
    }
  }
  throw lastError;
}

geminiRouter.post("/generate", async (req, res, next) => {
  const body = req.body as GeminiGenerateRequest;
  const mode = body?.mode || "free_text";
  const model = body?.model || process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const systemInstruction = `${body?.systemInstruction || ""}${mode === "triage_extraction" ? triageContract() : ""}`;

  try {
    if (!Array.isArray(body?.messages)) {
      res.status(400).json({ error: "messages must be an array" });
      return;
    }

    const config: any = {
      systemInstruction,
      temperature: body.temperature ?? (mode === "triage_extraction" ? 0 : 0.2),
      maxOutputTokens: body.maxOutputTokens ?? (mode === "document_summary" ? 1200 : 1600),
    };

    if (mode === "triage_extraction") {
      config.responseMimeType = "application/json";
      config.responseSchema = triageResponseSchema();
    }

    const response = await generateWithRetry({
      model,
      contents: toGeminiContents(body.messages, mode),
      config,
    });

    const rawText = extractText(response);
    const text = mode === "triage_extraction" ? safeTriageJson(rawText, systemInstruction, body.messages) : rawText;
    const candidate = (response as any)?.candidates?.[0];
    const usage = (response as any)?.usageMetadata;

    res.json({
      model,
      text,
      finishReason: candidate?.finishReason,
      usage: {
        inputTokens: usage?.promptTokenCount,
        outputTokens: usage?.candidatesTokenCount,
        totalTokens: usage?.totalTokenCount,
      },
    });
  } catch (error) {
    // Keep the browser's offline fallback for real server/network problems, but do not
    // let transient Gemini JSON/rate/overload failures break the online triage turn.
    // The app still receives a valid extraction envelope and can continue collecting.
    if (mode === "triage_extraction" && Array.isArray(body?.messages)) {
      console.error("Gemini triage extraction degraded to server-safe JSON:", error);
      res.status(200).json({
        model,
        text: safeTriageJson("", systemInstruction, body.messages),
        finishReason: "SERVER_SAFE_JSON",
        usage: {},
        degraded: true,
        error: error instanceof Error ? error.message : "Gemini generation failed",
      });
      return;
    }

    next(error);
  }
});
