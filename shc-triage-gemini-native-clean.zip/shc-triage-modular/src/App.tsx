import { useState, useRef, useEffect } from "react";

// ── TRANSLATIONS ──
const T = {
  en: {
    appSub: "Standard HealthCare",
    tabResult: "RESULT", tabDiff: "DIFF Δ", tabEngine: "ENGINE",
    patientLabel: "Patient", triageLabel: "Triage", sprtLabel: "Risk Level", qrLabel: "Show this to your doctor",
    safe: "SAFE", critical: "CRITICAL", alertLabel: "Doctor Note",
    uncertaintyLabel: "Uncertainty",
    uFlags: [{k:"boundary",label:"Risk boundary unclear"},{k:"multiple",label:"Multiple diagnoses"},{k:"unusual",label:"Unusual pattern"}],
    diffLabel: "Differential Diagnoses", diffEmpty: "—",
    engineLabel: "Pattern Engine", engineEmpty: "—",
    sourcesLabel: "Sources", awaiting: "No assessment yet",
    placeholder_symptom: "Describe your symptoms...",
    hint: 'Plain language works — "chest pain for two hours, left arm feels heavy"',
    connError: "Could not connect. Please check your internet and try again. If this is urgent, call 911 or go to the nearest ED.",
    profileComplete: (offline) => offline
      ? `Got it, thank you.\n\nSelect the complaint that best describes what you're experiencing:`
      : `Got it, thank you.\n\nNow describe your symptoms however feels natural.`,
    profileIntro: "Hi! Before we get started, I'll need a few quick details — it only takes a minute and makes the analysis much more accurate.\n\n",
    questions: [
      {key:"sex",          q:"What is your biological sex?",                                  type:"choice", choices:["Male","Female"]},
      {key:"age",          q:"How old are you?",                                              type:"number"},
      {key:"height_cm",    q:"Height in centimetres?",                                        type:"number"},
      {key:"weight_kg",    q:"Weight in kilograms?",                                          type:"number"},
      {key:"smoking",      q:"Do you currently smoke?",                                       type:"choice", choices:["Yes","No"]},
      {key:"diabetes",     q:"Have you been diagnosed with diabetes?",                        type:"choice", choices:["Yes","No"]},
      {key:"hypertension", q:"Do you have high blood pressure?",                             type:"choice", choices:["Yes","No"]},
      {key:"family_history",q:"Does close family have heart disease, diabetes or cancer?",   type:"choice", choices:["Yes","No"]},
    ],
    validation: { empty:"Please enter an answer to continue.", number:"Please enter a valid number.", age:"SHC is designed for adults (18+). For patients under 18, please consult a healthcare professional directly.", age_over:"Please enter a valid age (18–120).", height:"Please enter height in cm (e.g. 170).", weight:"Please enter weight in kg (e.g. 70).", yesno:"Please answer yes or no." },
    yesPattern: /yes|yeah|yep|evet/i,
    sexFemalePattern: /female|woman/i,
    routing: { RED:{label:"Emergency — Go Now",sub:"Call 911 or go to ED immediately"}, YELLOW:{label:"See a Doctor Today",sub:"Book urgent appointment"}, GREEN:{label:"Monitor at Home",sub:"See GP if symptoms worsen"}, GREY:{label:"See a Doctor — Unclear",sub:"Pattern unclear — doctor review needed"} },
  },
  tr: {
    appSub: "Standard HealthCare",
    tabResult: "SONUÇ", tabDiff: "AYIRT Δ", tabEngine: "MOTOR",
    patientLabel: "Hasta", triageLabel: "Triyaj", sprtLabel: "Risk Göstergesi", qrLabel: "Bunu doktorunuza gösterin",
    safe: "DÜŞÜK", critical: "KRİTİK", alertLabel: "Doktor Notu",
    uncertaintyLabel: "Belirsizlik",
    uFlags: [{k:"boundary",label:"Risk sınırı belirsiz"},{k:"multiple",label:"Birden fazla olası tanı"},{k:"unusual",label:"Alışılmadık belirti örüntüsü"}],
    diffLabel: "Olası Tanılar", diffEmpty: "—",
    engineLabel: "Analiz Motoru", engineEmpty: "—",
    sourcesLabel: "Kaynaklar", awaiting: "Henüz değerlendirme yapılmadı",
    placeholder_symptom: "Belirtilerinizi açıklayın...",
    hint: 'Sade bir dille anlatabilirsiniz — "iki saattir göğüs ağrım var, sol kolum da ağrıyor"',
    connError: "Bağlantı hatası oluştu. Acil durum ise lütfen 112'yi arayın veya en yakın acil servise gidin.",
    profileComplete: (offline) => offline
      ? `Teşekkürler, bilgilerinizi aldım.\n\nAşağıdaki listeden size en çok uyan şikayeti seçin:`
      : `Şimdi bana neden geldiğinizi anlatın. Sizi rahatsız eden ne?`,
    profileIntro: "Merhaba! Başlamadan önce birkaç hızlı soru sormam gerekiyor — bir dakika sürer ve sonuçları çok daha doğru hale getirir.\n\n",
    questions: [
      {key:"sex",          q:"Biyolojik cinsiyetiniz nedir?",                                      type:"choice", choices:["Erkek","Kadın"]},
      {key:"age",          q:"Kaç yaşındasınız?",                                                  type:"number"},
      {key:"height_cm",    q:"Boyunuz kaç cm?",                                                    type:"number"},
      {key:"weight_kg",    q:"Kilonuz kaç kg?",                                                    type:"number"},
      {key:"smoking",      q:"Şu an sigara içiyor musunuz?",                                       type:"choice", choices:["Evet","Hayır"]},
      {key:"diabetes",     q:"Diyabet tanınız var mı?",                                            type:"choice", choices:["Evet","Hayır"]},
      {key:"hypertension", q:"Yüksek tansiyon probleminiz var mı?",                               type:"choice", choices:["Evet","Hayır"]},
      {key:"family_history",q:"Yakın ailenizde kalp hastalığı, diyabet veya kanser var mı?",     type:"choice", choices:["Evet","Hayır"]},
    ],
    validation: { empty:"Devam etmek için lütfen bir cevap girin.", number:"Lütfen geçerli bir sayı girin.", age:"SHC yetişkinler (18+) için tasarlanmıştır. 18 yaş altı hastalar için lütfen doğrudan bir sağlık uzmanına başvurun.", age_over:"Lütfen geçerli bir yaş girin (18–120).", height:"Lütfen cm cinsinden boy girin (örn. 170).", weight:"Lütfen kg cinsinden kilo girin (örn. 70).", yesno:"Lütfen evet veya hayır olarak yanıtlayın." },
    yesPattern: /yes|yeah|yep|evet|^e$/i,
    sexFemalePattern: /female|woman|kadın|kadin|^k$/i,
    routing: { RED:{label:"Acil — Hemen Gidin",sub:"112'yi arayın veya acil servise gidin"}, YELLOW:{label:"Bugün Doktora Görünün",sub:"Acil randevu alın"}, GREEN:{label:"Evde İzleyin",sub:"Kötüleşirse doktora gidin"}, GREY:{label:"Doktora Danışın",sub:"Örüntü net değil — doktor değerlendirmesi gerekli"} },
  }
};

// ── AKINATOR OFFLINE ENGINE ──

// Kapı kartları — hasta hangi ana şikayetle başlıyor?
const AKINATOR_GATES = {
  tr: [
    { id:"chest",    label:"Göğüs ağrısı",          sub:"Sıkışma, baskı, yanma hissi"          },
    { id:"headache", label:"Baş ağrısı",             sub:"Zonklama, basınç, sürekli ağrı"       },
    { id:"cold",     label:"Burun, boğaz, öksürük",  sub:"Akıntı, hapşırma, ses kısıklığı"     },
    { id:"stomach",  label:"Mide ve karın",           sub:"Bulantı, şişkinlik, yanma, ishal"     },
    { id:"urinary",  label:"İdrar şikayeti",          sub:"Yanma, sık gitme, ağrı"               },
    { id:"fatigue",  label:"Yorgunluk ve halsizlik",  sub:"Bitkinlik, kilo değişimi, üşüme"     },
    { id:"backpain", label:"Sırt ve bel ağrısı",      sub:"Ağrı, uyuşma, tutulma, bacağa vurma" },
    { id:"anxiety",  label:"Kaygı ve çarpıntı",       sub:"Panik, nefes darlığı, stres"         },
    { id:"skin",     label:"Cilt ve döküntü",         sub:"Kızarıklık, kaşıntı, kabarcık"       },
    { id:"eye",      label:"Göz şikayeti",            sub:"Ağrı, kızarıklık, görme değişikliği" },
  ],
  en: [
    { id:"chest",    label:"Chest pain",              sub:"Tightness, pressure, burning"         },
    { id:"headache", label:"Headache",                sub:"Throbbing, pressure, constant ache"   },
    { id:"cold",     label:"Nose, throat, cough",     sub:"Runny nose, sneezing, hoarseness"     },
    { id:"stomach",  label:"Stomach and abdomen",     sub:"Nausea, bloating, heartburn, diarrhoea"},
    { id:"urinary",  label:"Urinary complaint",       sub:"Burning, frequent urge, pain"         },
    { id:"fatigue",  label:"Fatigue and weakness",    sub:"Exhaustion, weight change, cold sensitivity"},
    { id:"backpain", label:"Back and lower back",     sub:"Pain, numbness, stiffness, leg radiation"},
    { id:"anxiety",  label:"Anxiety and palpitations",sub:"Panic, breathlessness, stress"        },
    { id:"skin",     label:"Skin and rash",           sub:"Redness, itching, blisters"           },
    { id:"eye",      label:"Eye complaint",           sub:"Pain, redness, vision change"         },
  ],
};

// Tüm dal soruları — her dal 10-12 soru, derin ayrım
const AKINATOR_QUESTIONS = [

  // ══ GÖĞÜS DALI ══
  // ACS vs GERD vs Anksiyete ayrımı
  { id:"chest_scale",    ask_if:"chest",   type:"scale", weight:3,
    text_tr:"Şu anki göğüs ağrısını 1'den 10'a değerlendirin.",
    text_en:"Rate the chest pain you feel right now from 1 to 10.",
    scale_trigger:"chest_pain", scale_high_triggers:["chest_pressure","chest_tightness"] },
  { id:"chest_arm",      ask_if:"chest",   type:"yn",    weight:5,
    text_tr:"Sol kolunuzda, omzunuzda ya da çenenizde ağrı veya uyuşma var mı?",
    text_en:"Do you have pain or numbness in your left arm, shoulder or jaw?",
    triggers_yes:["left_arm_pain","jaw_pain","shoulder_pain"] },
  { id:"chest_sweat",    ask_if:"chest",   type:"yn",    weight:4,
    text_tr:"Soğuk terleme oluyor mu?",
    text_en:"Are you breaking out in a cold sweat?",
    triggers_yes:["diaphoresis","cold_sweat"] },
  { id:"chest_breath",   ask_if:"chest",   type:"yn",    weight:3,
    text_tr:"Nefes almak zorlaşıyor mu?",
    text_en:"Is breathing becoming difficult?",
    triggers_yes:["shortness_of_breath"] },
  { id:"chest_nausea",   ask_if:"chest",   type:"yn",    weight:3,
    text_tr:"Bulantı veya kusma var mı?",
    text_en:"Do you feel nauseous or are you vomiting?",
    triggers_yes:["nausea","vomiting"] },
  { id:"chest_burn",     ask_if:"chest",   type:"yn",    weight:3,
    text_tr:"Yemekten sonra veya yatınca daha mı kötü oluyor?",
    text_en:"Does it get worse after eating or when lying down?",
    triggers_yes:["heartburn","acid_reflux","worse_lying_down","worse_after_eating"] },
  { id:"chest_exertion", ask_if:"chest",   type:"yn",    weight:4,
    text_tr:"Eforla — yürüyünce veya merdiven çıkınca — ağrı artıyor mu?",
    text_en:"Does the pain increase with exertion — walking or climbing stairs?",
    triggers_yes:["chest_pain","chest_tightness"] },
  { id:"chest_rest",     ask_if:"chest",   type:"yn",    weight:3, depends_on:"chest_exertion",
    text_tr:"Dinlenince ağrı geçiyor mu?",
    text_en:"Does resting ease the pain?",
    triggers_yes:["chest_pressure"] },
  { id:"chest_duration", ask_if:"chest",   type:"yn",    weight:3, depends_on:"chest_arm",
    text_tr:"Ağrı 20 dakikadan uzun sürüyor mu?",
    text_en:"Has the pain lasted more than 20 minutes?",
    triggers_yes:["chest_pain"] },
  { id:"chest_acid",     ask_if:"chest",   type:"yn",    weight:3, depends_on:"chest_burn",
    text_tr:"Ağız içine ekşi veya acı bir tat geliyor mu?",
    text_en:"Do you get a sour or bitter taste in your mouth?",
    triggers_yes:["acid_reflux","regurgitation","sour_taste"] },
  { id:"chest_palpitat", ask_if:"chest",   type:"yn",    weight:3,
    text_tr:"Kalp çarpıntısı, düzensiz kalp atışı veya panik hissi var mı?",
    text_en:"Do you also have palpitations, irregular heartbeat or a sense of panic?",
    triggers_yes:["palpitations","racing_heart","irregular_heartbeat","panic_attacks","fear","excessive_worry"] },
  { id:"chest_back",     ask_if:"chest",   type:"yn",    weight:4, depends_on:"chest_arm",
    text_tr:"Ağrı sırta veya omuzlara yayılıyor mu?",
    text_en:"Does the pain radiate to your back or shoulders?",
    triggers_yes:["back_pain","shoulder_pain","pain_radiation_back"] },

  // ══ BAŞ AĞRISI DALI ══
  // İnme vs Migren vs Gerilim tipi kesin ayrım
  { id:"head_sudden",    ask_if:"headache",type:"yn",    weight:5,
    text_tr:"Ağrı saniyeler içinde, aniden mi geldi?",
    text_en:"Did the pain come on within seconds — suddenly?",
    triggers_yes:["sudden_headache"] },
  { id:"head_face",      ask_if:"headache",type:"yn",    weight:5,
    text_tr:"Yüzünüzde uyuşma, sarkma veya güçsüzlük var mı?",
    text_en:"Is there numbness, drooping or weakness in your face?",
    triggers_yes:["facial_drooping","numbness_one_side","vision_change"] },
  { id:"head_arm",       ask_if:"headache",type:"yn",    weight:5,
    text_tr:"Bir kolunuzda veya bacağınızda ani güçsüzlük var mı?",
    text_en:"Is there sudden weakness in one arm or leg?",
    triggers_yes:["arm_weakness"] },
  { id:"head_speech",    ask_if:"headache",type:"yn",    weight:5,
    text_tr:"Konuşmanızda bozulma veya kelime bulmakta güçlük var mı?",
    text_en:"Is your speech slurred or are you struggling to find words?",
    triggers_yes:["speech_difficulty"] },
  { id:"head_scale",     ask_if:"headache",type:"scale", weight:3,
    text_tr:"Ağrının şiddetini 1'den 10'a değerlendirin.",
    text_en:"Rate the headache intensity from 1 to 10.",
    scale_trigger:"severe_headache", scale_high_triggers:["throbbing_headache"] },
  { id:"head_side",      ask_if:"headache",type:"yn",    weight:4,
    text_tr:"Ağrı kafanızın sadece bir tarafında mı?",
    text_en:"Is the pain on just one side of your head?",
    triggers_yes:["one_sided_headache"] },
  { id:"head_light",     ask_if:"headache",type:"yn",    weight:4,
    text_tr:"Işık veya ses sizi rahatsız ediyor mu?",
    text_en:"Does light or noise bother you?",
    triggers_yes:["light_sensitivity","sound_sensitivity"] },
  { id:"head_nausea",    ask_if:"headache",type:"yn",    weight:3,
    text_tr:"Bulantı veya kusma var mı?",
    text_en:"Is there nausea or vomiting?",
    triggers_yes:["nausea","vomiting"] },
  { id:"head_throbbing", ask_if:"headache",type:"yn",    weight:3, depends_on:"head_side",
    text_tr:"Ağrı nabız atar gibi zonkluyor mu?",
    text_en:"Does the pain throb or pulse?",
    triggers_yes:["throbbing_headache"] },
  { id:"head_aura",      ask_if:"headache",type:"yn",    weight:3, depends_on:"head_side",
    text_tr:"Ağrıdan önce gözlerinizde parlama, karartı veya çizgiler görüyor muydunuz?",
    text_en:"Before the pain, did you see flashing lights, blind spots or zigzag lines?",
    triggers_yes:["aura","visual_disturbance"] },
  { id:"head_pressure",  ask_if:"headache",type:"yn",    weight:3,
    text_tr:"Ağrı zonklamak yerine kafanızı saran bir baskı veya kuşak gibi mi hissettiriyor?",
    text_en:"Does it feel like pressure or a tight band squeezing your head rather than throbbing?",
    triggers_yes:["bilateral_headache","pressure_headache","band_around_head","neck_muscle_tension","stress_related"] },
  { id:"head_worse_act", ask_if:"headache",type:"yn",    weight:2, depends_on:"head_nausea",
    text_tr:"Hareket edince veya fiziksel aktiviteyle ağrı artıyor mu?",
    text_en:"Does physical activity or movement make the headache worse?",
    triggers_yes:["severe_headache","worsens_with_activity"] },

  // ══ BURUN / BOĞAZ / ÖKSÜRÜK DALI ══
  // Grip vs Soğuk algınlığı vs Pnömoni ayrımı
  { id:"cold_runny",     ask_if:"cold",    type:"yn",    weight:2,
    text_tr:"Burun akıntısı veya burun tıkanıklığı var mı?",
    text_en:"Do you have a runny or blocked nose?",
    triggers_yes:["runny_nose"] },
  { id:"cold_fever",     ask_if:"cold",    type:"yn",    weight:4,
    text_tr:"Ateşiniz var mı?",
    text_en:"Do you have a fever?",
    triggers_yes:["fever"] },
  { id:"cold_body",      ask_if:"cold",    type:"yn",    weight:4,
    text_tr:"Tüm vücudunuz ağrıyor mu?",
    text_en:"Is your whole body aching?",
    triggers_yes:["body_aches"] },
  { id:"cold_onset",     ask_if:"cold",    type:"yn",    weight:4,
    text_tr:"Şikayetler birkaç saat içinde aniden mi geldi?",
    text_en:"Did the symptoms come on suddenly within a few hours?",
    triggers_yes:["sudden_onset"] },
  { id:"cold_throat",    ask_if:"cold",    type:"yn",    weight:3,
    text_tr:"Boğaz ağrısı var mı?",
    text_en:"Do you have a sore throat?",
    triggers_yes:["sore_throat"] },
  { id:"cold_cough",     ask_if:"cold",    type:"yn",    weight:3,
    text_tr:"Öksürük var mı?",
    text_en:"Do you have a cough?",
    triggers_yes:["cough","dry_cough"] },
  { id:"cold_breath",    ask_if:"cold",    type:"yn",    weight:4,
    text_tr:"Nefes darlığı veya nefes alırken güçlük oluyor mu?",
    text_en:"Do you have shortness of breath or difficulty breathing?",
    triggers_yes:["shortness_of_breath","chest_tightness"] },
  { id:"cold_sputum",    ask_if:"cold",    type:"yn",    weight:3, depends_on:"cold_cough",
    text_tr:"Öksürükle balgam veya renkli sekresyon çıkıyor mu?",
    text_en:"Are you coughing up phlegm or discoloured mucus?",
    triggers_yes:["sputum_production","cough"] },
  { id:"cold_smell",     ask_if:"cold",    type:"yn",    weight:3,
    text_tr:"Koku veya tat duyunuz azaldı mı?",
    text_en:"Has your sense of smell or taste decreased?",
    triggers_yes:["loss_of_smell","loss_of_taste"] },
  { id:"cold_rigors",    ask_if:"cold",    type:"yn",    weight:3,
    text_tr:"Kontrol edemediğiniz titreme nöbetleri oluyor mu?",
    text_en:"Are you having uncontrollable shivering fits?",
    triggers_yes:["rigors","chills"] },
  { id:"cold_severity",  ask_if:"cold",    type:"scale", weight:2,
    text_tr:"Kendinizi ne kadar kötü hissediyorsunuz? 1 hafif, 10 yataktan kalkamıyorum.",
    text_en:"How unwell do you feel? 1 = mild, 10 = can't get out of bed.",
    scale_trigger:"fatigue", scale_high_triggers:["headache","body_aches","fever"] },

  // ══ MİDE / KARIN DALI ══
  // GERD vs İBS vs Ülser vs Gastroenterit ayrımı
  { id:"stom_scale",     ask_if:"stomach", type:"scale", weight:3,
    text_tr:"Karın ağrısını 1'den 10'a değerlendirin.",
    text_en:"Rate your abdominal pain from 1 to 10.",
    scale_trigger:"abdominal_pain", scale_high_triggers:["severe_abdominal_pain","cramping"] },
  { id:"stom_nausea",    ask_if:"stomach", type:"yn",    weight:3,
    text_tr:"Bulantı veya kusma var mı?",
    text_en:"Do you have nausea or vomiting?",
    triggers_yes:["nausea","vomiting"] },
  { id:"stom_diarrhea",  ask_if:"stomach", type:"yn",    weight:3,
    text_tr:"İshal var mı?",
    text_en:"Do you have diarrhoea?",
    triggers_yes:["diarrhea"] },
  { id:"stom_upper",     ask_if:"stomach", type:"yn",    weight:3,
    text_tr:"Ağrı üst karında mı — göğüs kemiğinin hemen altında mı?",
    text_en:"Is the pain in the upper abdomen — just below the breastbone?",
    triggers_yes:["epigastric_pain","burning_stomach_pain"] },
  { id:"stom_eating",    ask_if:"stomach", type:"yn",    weight:3, depends_on:"stom_upper",
    text_tr:"Yemek yince ağrı geçiyor mu?",
    text_en:"Does eating ease the pain?",
    triggers_yes:["pain_relieved_by_eating"] },
  { id:"stom_burn",      ask_if:"stomach", type:"yn",    weight:4,
    text_tr:"Göğüste yanma veya ağıza ekşi sıvı geliyor mu?",
    text_en:"Do you have a burning in your chest or acid coming up into your mouth?",
    triggers_yes:["heartburn","acid_reflux","regurgitation","chest_burning"] },
  { id:"stom_lie",       ask_if:"stomach", type:"yn",    weight:3, depends_on:"stom_burn",
    text_tr:"Yatınca veya öne eğilince şikayetler daha mı kötü oluyor?",
    text_en:"Do symptoms get worse when you lie down or bend forward?",
    triggers_yes:["worse_lying_down","worse_after_eating"] },
  { id:"stom_swallow",    ask_if:"stomach", type:"yn",    weight:2, depends_on:"stom_burn",
    text_tr:"Yutkunmakta güçlük veya yutkunurken ağrı var mı?",
    text_en:"Do you have difficulty swallowing or pain when swallowing?",
    triggers_yes:["difficulty_swallowing","sour_taste"] },
  { id:"stom_blood",     ask_if:"stomach", type:"yn",    weight:5,
    text_tr:"Dışkıda kan var mı ya da siyah, katran gibi görünüyor mu?",
    text_en:"Is there blood in your stool, or does it look black and tarry?",
    triggers_yes:["blood_in_stool","black_stool","rectal_bleeding"] },
  { id:"stom_fever",     ask_if:"stomach", type:"yn",    weight:3,
    text_tr:"Ateş var mı?",
    text_en:"Do you have a fever?",
    triggers_yes:["fever"] },
  { id:"stom_bloat",     ask_if:"stomach", type:"yn",    weight:2,
    text_tr:"Belirgin şişkinlik veya gaz şikayeti var mı?",
    text_en:"Do you have noticeable bloating or gas?",
    triggers_yes:["bloating","constipation","alternating_bowel"] },
  { id:"stom_bowel",     ask_if:"stomach", type:"yn",    weight:2, depends_on:"stom_diarrhea",
    text_tr:"Tuvalete gidince ağrı geçiyor mu?",
    text_en:"Does the pain ease after having a bowel movement?",
    triggers_yes:["pain_relieved_by_defecation","urgency"] },
  { id:"stom_hunger",    ask_if:"stomach", type:"yn",    weight:2, depends_on:"stom_upper",
    text_tr:"Ağrı aç kaldığınızda daha mı kötü oluyor?",
    text_en:"Is the pain worse when you are hungry?",
    triggers_yes:["hunger_pain","epigastric_pain"] },

  // ══ İDRAR DALI ══
  // İYE vs Piyelonefrit vs Böbrek taşı ayrımı
  { id:"uri_burn",       ask_if:"urinary", type:"yn",    weight:5,
    text_tr:"İdrar yaparken yanma veya ağrı var mı?",
    text_en:"Do you feel burning or pain when urinating?",
    triggers_yes:["painful_urination","burning_urination"] },
  { id:"uri_freq",       ask_if:"urinary", type:"yn",    weight:4,
    text_tr:"Çok sık tuvalete gidiyor musunuz, her seferinde az mı çıkıyor?",
    text_en:"Are you going very often with little urine each time?",
    triggers_yes:["frequent_urination","urgency"] },
  { id:"uri_appear",     ask_if:"urinary", type:"yn",    weight:4,
    text_tr:"İdrar bulanık, kötü kokulu veya kanlı mı?",
    text_en:"Is the urine cloudy, foul-smelling or bloody?",
    triggers_yes:["cloudy_urine","strong_urine_smell","blood_in_urine"] },
  { id:"uri_fever",      ask_if:"urinary", type:"yn",    weight:4,
    text_tr:"Ateş var mı?",
    text_en:"Do you have a fever?",
    triggers_yes:["fever"] },
  { id:"uri_flank",      ask_if:"urinary", type:"yn",    weight:4,
    text_tr:"Yan tarafınızda veya sırt alt kısmında ağrı var mı?",
    text_en:"Do you have pain in your side or lower back?",
    triggers_yes:["flank_pain","back_pain"] },
  { id:"uri_colicky",    ask_if:"urinary", type:"yn",    weight:4, depends_on:"uri_flank",
    text_tr:"Ağrı dalgalar halinde mi geliyor — şiddetleniyor sonra hafifliyour mu?",
    text_en:"Does the pain come in waves — intensifying then easing?",
    triggers_yes:["colicky_pain","severe_flank_pain"] },
  { id:"uri_groin",      ask_if:"urinary", type:"yn",    weight:3, depends_on:"uri_flank",
    text_tr:"Ağrı kasığa veya uyluğa yayılıyor mu?",
    text_en:"Does the pain radiate to your groin or thigh?",
    triggers_yes:["pain_radiates_groin"] },
  { id:"uri_lower",      ask_if:"urinary", type:"scale", weight:2,
    text_tr:"Alt karın ağrısını 1'den 10'a değerlendirin.",
    text_en:"Rate any lower abdominal pain from 1 to 10.",
    scale_trigger:"lower_abdominal_pain", scale_high_triggers:["urgency"] },
  { id:"uri_nausea",     ask_if:"urinary", type:"yn",    weight:2,
    text_tr:"Bulantı, kusma veya titreme oluyor mu?",
    text_en:"Is there nausea, vomiting or rigors?",
    triggers_yes:["nausea","vomiting","rigors"] },

  // ══ YORGUNLUK DALI ══
  // Hipotiroid vs Anemi vs Depresyon ayrımı
  { id:"fat_scale",      ask_if:"fatigue", type:"scale", weight:3,
    text_tr:"Yorgunluğu 1'den 10'a değerlendirin. 1 hafif, 10 hiç kalkamıyorum.",
    text_en:"Rate your fatigue from 1 to 10. 1 = mild, 10 = can't get up.",
    scale_trigger:"fatigue", scale_high_triggers:["weakness"] },
  { id:"fat_cold",       ask_if:"fatigue", type:"yn",    weight:4,
    text_tr:"Herkesten daha çok üşüyor musunuz?",
    text_en:"Do you feel colder than the people around you?",
    triggers_yes:["cold_intolerance"] },
  { id:"fat_weight_gain",ask_if:"fatigue", type:"yn",    weight:4,
    text_tr:"Son birkaç ayda diyet yapmadan kilo aldınız mı?",
    text_en:"Have you gained weight recently without trying?",
    triggers_yes:["weight_gain"] },
  { id:"fat_pale",       ask_if:"fatigue", type:"yn",    weight:4,
    text_tr:"Cildiniz soluk mu, az hareketle nefes darlığı oluyor mu?",
    text_en:"Is your skin pale, or do you get breathless with little effort?",
    triggers_yes:["pale_skin","breathlessness","dizziness"] },
  { id:"fat_heart",      ask_if:"fatigue", type:"yn",    weight:3, depends_on:"fat_pale",
    text_tr:"Çarpıntı veya hızlı kalp atışı oluyor mu?",
    text_en:"Do you have palpitations or a racing heart?",
    triggers_yes:["palpitations","racing_heart"] },
  { id:"fat_sad",        ask_if:"fatigue", type:"yn",    weight:4,
    text_tr:"Sürekli üzgün, umutsuz veya hiçbir şeyden zevk alamıyor musunuz?",
    text_en:"Do you feel persistently sad, hopeless or unable to enjoy anything?",
    triggers_yes:["persistent_sadness","loss_of_interest","hopelessness"] },
  { id:"fat_sleep",      ask_if:"fatigue", type:"yn",    weight:3, depends_on:"fat_sad",
    text_tr:"Uyku bozukluğu var mı — çok az veya çok fazla uyuma?",
    text_en:"Do you have sleep disturbances — sleeping too little or too much?",
    triggers_yes:["sleep_changes","insomnia"] },
  { id:"fat_appetite",   ask_if:"fatigue", type:"yn",    weight:3, depends_on:"fat_sad",
    text_tr:"İştah değişikliği var mı — yemek istemiyor musunuz veya çok mu yiyorsunuz?",
    text_en:"Has your appetite changed significantly — eating much less or much more?",
    triggers_yes:["appetite_changes","loss_of_appetite"] },
  { id:"fat_concentrate",ask_if:"fatigue", type:"yn",    weight:2, depends_on:"fat_sad",
    text_tr:"Konsantrasyon güçlüğü veya karar vermekte zorlanma oluyor mu?",
    text_en:"Do you have difficulty concentrating or making decisions?",
    triggers_yes:["concentration_problems","memory_problems","social_withdrawal"] },
  { id:"fat_skin",       ask_if:"fatigue", type:"yn",    weight:3, depends_on:"fat_cold",
    text_tr:"Cilt kuru mu, normalden fazla saç mı dökülüyor?",
    text_en:"Is your skin dry, or are you losing more hair than usual?",
    triggers_yes:["dry_skin","hair_loss"] },
  { id:"fat_constip",    ask_if:"fatigue", type:"yn",    weight:2, depends_on:"fat_cold",
    text_tr:"Belirgin kabızlık var mı?",
    text_en:"Do you have noticeable constipation?",
    triggers_yes:["constipation"] },
  { id:"fat_voice",      ask_if:"fatigue", type:"yn",    weight:2, depends_on:"fat_cold",
    text_tr:"Sesiniz kalınlaştı mı ya da yüzünüz şiş görünüyor mu?",
    text_en:"Has your voice become deeper, or does your face look puffy?",
    triggers_yes:["hoarse_voice","puffy_face"] },
  { id:"fat_nails",      ask_if:"fatigue", type:"yn",    weight:2, depends_on:"fat_cold",
    text_tr:"Tırnaklarınız kırılgan mı veya el-ayak soğukluğu oluyor mu?",
    text_en:"Are your nails brittle, or do you have cold hands and feet?",
    triggers_yes:["brittle_nails","cold_hands"] },

  // ══ SIRT / BEL DALI ══
  // Disk fıtığı vs Cauda equina — erken yakalama
  { id:"back_scale",     ask_if:"backpain",type:"scale", weight:3,
    text_tr:"Bel ağrısını 1'den 10'a değerlendirin.",
    text_en:"Rate your back pain from 1 to 10.",
    scale_trigger:"lower_back_pain", scale_high_triggers:["stiffness"] },
  { id:"back_leg",       ask_if:"backpain",type:"yn",    weight:5,
    text_tr:"Ağrı bir bacağınıza yayılıyor mu?",
    text_en:"Does the pain spread down into one leg?",
    triggers_yes:["leg_pain","sciatica","pain_radiates_leg"] },
  { id:"back_numb",      ask_if:"backpain",type:"yn",    weight:5, depends_on:"back_leg",
    text_tr:"Bacakta uyuşma veya karıncalanma var mı?",
    text_en:"Do you have numbness or tingling in your leg?",
    triggers_yes:["numbness_leg","tingling_leg","weakness_leg"] },
  { id:"back_bladder",   ask_if:"backpain",type:"yn",    weight:6,
    text_tr:"İdrar yapmakta güçlük ya da idrarı tutamama oluyor mu?",
    text_en:"Are you having trouble urinating or losing bladder control?",
    triggers_yes:["urinary_retention","bladder_dysfunction"] },
  { id:"back_saddle",    ask_if:"backpain",type:"yn",    weight:6, depends_on:"back_bladder",
    text_tr:"Kasık, iç bacaklar veya kalça bölgesinde uyuşma var mı?",
    text_en:"Do you have numbness in the groin, inner thighs or buttocks?",
    triggers_yes:["saddle_anesthesia"] },
  { id:"back_bowel",     ask_if:"backpain",type:"yn",    weight:5, depends_on:"back_bladder",
    text_tr:"Dışkılamayı kontrol etmekte güçlük var mı?",
    text_en:"Are you having difficulty controlling your bowels?",
    triggers_yes:["bowel_dysfunction","saddle_anesthesia"] },
  { id:"back_both_legs", ask_if:"backpain",type:"yn",    weight:4, depends_on:"back_leg",
    text_tr:"Her iki bacakta da güçsüzlük veya uyuşma var mı?",
    text_en:"Do you have weakness or numbness in both legs?",
    triggers_yes:["bilateral_leg_weakness","numbness_leg"] },
  { id:"back_sit",       ask_if:"backpain",type:"yn",    weight:3, depends_on:"back_leg",
    text_tr:"Oturunca ağrı daha mı kötü oluyor?",
    text_en:"Does sitting make the pain worse?",
    triggers_yes:["worse_sitting"] },
  { id:"back_worse_morn",ask_if:"backpain",type:"yn",    weight:2,
    text_tr:"Sabah kalktığınızda ağrı daha mı şiddetli oluyor?",
    text_en:"Is the pain worse when you first get up in the morning?",
    triggers_yes:["lower_back_pain","stiffness"] },
  { id:"back_duration",  ask_if:"backpain",type:"yn",    weight:2,
    text_tr:"Bu ağrı 6 haftadan uzun süredir devam ediyor mu?",
    text_en:"Has this pain been going on for more than 6 weeks?",
    triggers_yes:["lower_back_pain"] },

  // ══ KAYGI / ÇARPINTI DALI ══
  // Panik bozukluğu vs GAD vs AFib ayrımı
  { id:"anx_chest_pain", ask_if:"anxiety", type:"yn",    weight:5,
    text_tr:"Göğüste ağrı, baskı veya sıkışma hissediyor musunuz?",
    text_en:"Do you have any chest pain, pressure or tightness?",
    triggers_yes:["chest_pain","chest_pressure","chest_tightness"] },
  { id:"anx_palp",       ask_if:"anxiety", type:"yn",    weight:4,
    text_tr:"Kalp çarpıntısı veya hızlı kalp atışı hissediyor musunuz?",
    text_en:"Do you feel your heart pounding or racing?",
    triggers_yes:["racing_heart","palpitations"] },
  { id:"anx_irregular",  ask_if:"anxiety", type:"yn",    weight:4,
    text_tr:"Kalp atışınız düzensiz mi — zaman zaman atlıyor gibi mi?",
    text_en:"Does your heart feel irregular — like it skips beats sometimes?",
    triggers_yes:["irregular_heartbeat","palpitations"] },
  { id:"anx_breath",     ask_if:"anxiety", type:"yn",    weight:4,
    text_tr:"Nefes darlığı veya boğuluyormuş gibi his var mı?",
    text_en:"Do you feel short of breath or like you can't get enough air?",
    triggers_yes:["shortness_of_breath","chest_tightness"] },
  { id:"anx_panic",      ask_if:"anxiety", type:"yn",    weight:4,
    text_tr:"Aniden gelen yoğun korku veya panik atakları oluyor mu?",
    text_en:"Do you have sudden intense fear or panic attacks?",
    triggers_yes:["panic_attacks","fear"] },
  { id:"anx_worry",      ask_if:"anxiety", type:"yn",    weight:3,
    text_tr:"Durduramadığınız, günlük hayatı etkileyen aşırı endişe var mı?",
    text_en:"Do you have uncontrollable worry that affects daily life?",
    triggers_yes:["excessive_worry","muscle_tension"] },
  { id:"anx_scale",      ask_if:"anxiety", type:"scale", weight:3, depends_on:"anx_worry",
    text_tr:"Kaygı veya gerginliğini 1'den 10'a değerlendirin.",
    text_en:"Rate your anxiety or tension from 1 to 10.",
    scale_trigger:"excessive_worry", scale_high_triggers:["panic_attacks","muscle_tension"] },
  { id:"anx_dizziness",  ask_if:"anxiety", type:"yn",    weight:3, depends_on:"anx_palp",
    text_tr:"Baş dönmesi veya bayılacakmış gibi his oluyor mu?",
    text_en:"Do you feel dizzy or like you might faint?",
    triggers_yes:["dizziness"] },
  { id:"anx_physical",   ask_if:"anxiety", type:"yn",    weight:2, depends_on:"anx_panic",
    text_tr:"Titreme, terleme veya bulantı gibi fiziksel belirtiler var mı?",
    text_en:"Do you have physical symptoms like trembling, sweating or nausea?",
    triggers_yes:["trembling","sweating","nausea"] },
  { id:"anx_avoidance",  ask_if:"anxiety", type:"yn",    weight:3, depends_on:"anx_worry",
    text_tr:"Belirli yerlere veya durumlardan kaçınıyor musunuz — toplu taşıma, kalabalık gibi?",
    text_en:"Do you avoid certain places or situations — like public transport or crowds?",
    triggers_yes:["avoidance","excessive_worry","fear"] },
  { id:"anx_exertion",   ask_if:"anxiety", type:"yn",    weight:3, depends_on:"anx_chest_pain",
    text_tr:"Bu belirtiler efor sırasında — yürüyünce — daha mı kötü oluyor?",
    text_en:"Do these symptoms get worse with physical effort — like walking?",
    triggers_yes:["reduced_exercise","shortness_of_breath"] },

  // ══ SÜRE (tüm kapılar) ══
  { id:"dur_chest", ask_if:"chest", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_headache", ask_if:"headache", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset","sudden_headache"] },
  { id:"dur_cold", ask_if:"cold", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_stomach", ask_if:"stomach", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_urinary", ask_if:"urinary", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_fatigue", ask_if:"fatigue", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_backpain", ask_if:"backpain", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_anxiety", ask_if:"anxiety", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_skin", ask_if:"skin", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },
  { id:"dur_eye", ask_if:"eye", type:"yn", weight:4,
    text_tr:"Bu şikayet son birkaç saat içinde aniden mi başladı?",
    text_en:"Did this start suddenly, within the last few hours?",
    triggers_yes:["rapid_onset","sudden_onset"] },

  // ══ CİLT / DÖKÜNTÜ DALI ══
  { id:"skin_spread", ask_if:"skin", type:"yn", weight:5,
    text_tr:"Ciltte yayılan ve dokununca sıcak hissedilen bir kızarıklık var mı?",
    text_en:"Is there spreading redness that feels warm to the touch?",
    triggers_yes:["spreading_redness","warm_skin"] },
  { id:"skin_fever", ask_if:"skin", type:"yn", weight:5,
    text_tr:"Ateşiniz ya da titremeniz var mı?",
    text_en:"Do you have fever or chills?",
    triggers_yes:["fever","chills"] },
  { id:"skin_streak", ask_if:"skin", type:"yn", weight:6, depends_on:"skin_spread",
    text_tr:"Kızarıklıktan vücuda doğru çizgi halinde kırmızı hatlar ilerliyor mu?",
    text_en:"Are red streaks spreading from the area toward the body?",
    triggers_yes:["red_streaks"] },
  { id:"skin_hives", ask_if:"skin", type:"yn", weight:4,
    text_tr:"Kaşıntılı, kabarık döküntüler (kurdeşen) var mı?",
    text_en:"Do you have itchy, raised welts (hives)?",
    triggers_yes:["itchy_welts","hives"] },
  { id:"skin_expose", ask_if:"skin", type:"yn", weight:3,
    text_tr:"Yeni bir ürün, yiyecek, ilaç ya da böcek temasından sonra mı başladı?",
    text_en:"Did it start after a new product, food, medication, or insect contact?",
    triggers_yes:["rash_after_exposure"] },
  { id:"skin_swellface", ask_if:"skin", type:"yn", weight:6,
    text_tr:"Dudak veya dilde şişme ya da boğazda daralma hissi var mı?",
    text_en:"Any swelling of the lips or tongue, or tightness in the throat?",
    triggers_yes:["lip_face_swelling","throat_tightness"] },
  { id:"skin_band", ask_if:"skin", type:"yn", weight:5,
    text_tr:"Vücudun tek tarafında bant şeklinde ağrılı kabarcıklar var mı?",
    text_en:"Painful clustered blisters in a band on one side of the body?",
    triggers_yes:["one_sided_band_rash","blisters_cluster"] },
  { id:"skin_burnpain", ask_if:"skin", type:"yn", weight:4, depends_on:"skin_band",
    text_tr:"Döküntüden önce o bölgede yanma ya da karıncalanma var mıydı?",
    text_en:"Was there burning or tingling in that area before the rash appeared?",
    triggers_yes:["burning_pain_before_rash"] },
  { id:"skin_eye", ask_if:"skin", type:"yn", weight:6, depends_on:"skin_band",
    text_tr:"Döküntü göz çevresine ya da burun ucuna yakın mı?",
    text_en:"Is the rash near the eye or the tip of the nose?",
    triggers_yes:["rash_near_eye"] },
  { id:"skin_itchdry", ask_if:"skin", type:"yn", weight:2,
    text_tr:"Söz konusu bölgeler kuru, pullu ve kaşıntılı mı?",
    text_en:"Are the patches dry, scaly, and itchy?",
    triggers_yes:["itchy_rash","dry_scaly_patches","localized_redness"] },

  // ══ GÖZ DALI ══
  { id:"eye_pain", ask_if:"eye", type:"yn", weight:5,
    text_tr:"Gözde belirgin ağrı var mı (batma değil, gerçek ağrı)?",
    text_en:"Is there real pain in the eye (not just a gritty feeling)?",
    triggers_yes:["eye_pain"] },
  { id:"eye_vision", ask_if:"eye", type:"yn", weight:6,
    text_tr:"Görmede ani azalma ya da kayıp oldu mu?",
    text_en:"Has there been a sudden decrease or loss of vision?",
    triggers_yes:["sudden_vision_loss","painless_vision_loss"] },
  { id:"eye_curtain", ask_if:"eye", type:"yn", weight:6,
    text_tr:"Görme alanınıza perde ya da gölge iner gibi oldu mu?",
    text_en:"Did a curtain or shadow seem to come down over your vision?",
    triggers_yes:["curtain_vision"] },
  { id:"eye_flash", ask_if:"eye", type:"yn", weight:5,
    text_tr:"Ani ışık çakmaları ya da yoğun uçuşan noktalar görüyor musunuz?",
    text_en:"Are you seeing flashes of light or a sudden shower of floaters?",
    triggers_yes:["flashes_of_light","sudden_floaters"] },
  { id:"eye_halo", ask_if:"eye", type:"yn", weight:5,
    text_tr:"Işıkların etrafında renkli haleler görüyor musunuz?",
    text_en:"Do you see halos around lights?",
    triggers_yes:["halos_around_lights"] },
  { id:"eye_red", ask_if:"eye", type:"yn", weight:3,
    text_tr:"Gözünüz kızarık mı?",
    text_en:"Is the eye red?",
    triggers_yes:["red_eye"] },
  { id:"eye_disch", ask_if:"eye", type:"yn", weight:3,
    text_tr:"Çapaklanma ya da akıntı var mı?",
    text_en:"Is there discharge or crusting?",
    triggers_yes:["eye_discharge","crusted_lashes"] },
  { id:"eye_fb", ask_if:"eye", type:"yn", weight:4,
    text_tr:"Gözde yabancı cisim batması hissi ya da göz kırparken ağrı var mı?",
    text_en:"A foreign-body sensation, or pain when blinking?",
    triggers_yes:["foreign_body_sensation","pain_on_blinking"] },
  { id:"eye_photo", ask_if:"eye", type:"yn", weight:3,
    text_tr:"Işığa bakmak gözü rahatsız ediyor mu?",
    text_en:"Does light bother the eye?",
    triggers_yes:["light_sensitivity"] },
  { id:"eye_nausea", ask_if:"eye", type:"yn", weight:4, depends_on:"eye_pain",
    text_tr:"Göz ağrısıyla birlikte bulantı ya da kusma var mı?",
    text_en:"Nausea or vomiting along with the eye pain?",
    triggers_yes:["nausea","vomiting"] },
];


// Tüm offline patternlar — tüm gate pattern'larını kapsıyor
const OFFLINE_PATTERNS = [
  // Kardiyak
  "acs","afib",
  // Nörolojik
  "stroke","migraine","tension_headache",
  // Solunum / enfeksiyon
  "influenza","pneumonia",
  // GIS
  "gerd","ibs","peptic_ulcer",
  // Üriner
  "uti","pyelonephritis","kidney_stones",
  // Endokrin / metabolik
  "hypothyroidism","anemia","depression",
  // Kas-iskelet
  "lumbar_radiculopathy","cauda_equina",
  // Psikiyatrik
  "anxiety",
  "cellulitis","urticaria_allergy","contact_dermatitis","shingles","conjunctivitis","corneal_abrasion","retinal_detachment","acute_glaucoma"];

// Kapı → ilgili patternlar — tümü OFFLINE_PATTERNS'da mevcut
const GATE_PATTERNS = {
  chest:    ["acs","afib","gerd","anxiety"],
  headache: ["stroke","migraine","tension_headache"],
  cold:     ["influenza","pneumonia"],
  stomach:  ["gerd","ibs","peptic_ulcer"],
  urinary:  ["uti","pyelonephritis","kidney_stones"],
  fatigue:  ["hypothyroidism","anemia","depression"],
  backpain: ["lumbar_radiculopathy","cauda_equina"],
  anxiety:  ["anxiety","afib","acs"],
  skin:     ["cellulitis","urticaria_allergy","contact_dermatitis","shingles"],
  eye:      ["acute_glaucoma","retinal_detachment","conjunctivitis","corneal_abrasion"],
};


const MIN_QUESTIONS_BEFORE_DECISION = 5;

// Dinamik soru sıralaması — her cevaptan sonra kalan pattern dağılımına göre
// en ayırt edici soruyu seçer (information gain bazlı)
function pickNextQuestion(askedIds, selectedGate, collectedTriggers, riskMods, answeredNo, absentTriggers) {
  const noSet = new Set(answeredNo || []);
  const pendingQs = AKINATOR_QUESTIONS.filter(q => {
    if (q.ask_if !== selectedGate) return false;
    if (askedIds.includes(q.id)) return false;
    // Ebeveyne hayır denildiyse bu soruyu atla
    if (q.depends_on && noSet.has(q.depends_on)) return false;
    return true;
  });
  if (pendingQs.length === 0) return null;
  if (pendingQs.length === 1) return pendingQs[0];

  const relevantPatterns = GATE_PATTERNS[selectedGate]
    ? [...new Set([...(GATE_PATTERNS[selectedGate] || []), ...OFFLINE_PATTERNS])]
    : OFFLINE_PATTERNS;
  const gateBonus = selectedGate ? (GATE_PATTERNS[selectedGate] || []) : [];
  const absent = absentTriggers || [];
  // SPRT durumu BİR kez hesaplanır; her aday soru bu duruma karşı puanlanır
  const state = runSPRT(relevantPatterns, collectedTriggers, absent, riskMods, gateBonus, PATTERNS);

  let bestQ = pendingQs[0], bestGain = -1;
  for (const q of pendingQs) {
    const g = sprtQuestionGain(q, state, collectedTriggers, absent, relevantPatterns, PATTERNS);
    if (g > bestGain) { bestGain = g; bestQ = q; }
  }
  return bestQ;
}


// Kırmızı bayrak kombinasyonları — pattern tamamlanmasa bile direkt RED
// Her kural: { triggers: [gerekli triggerlar], min_any: kaçı yeterli, pattern, label_tr, label_en }
const RED_FLAG_RULES = [
  // ACS — göğüs ağrısı + kol/çene/terleme/nefes'ten biri yeterli
  { triggers:["chest_pain","chest_pressure","chest_tightness"],     min_main:1,
    alarm:["left_arm_pain","jaw_pain","diaphoresis","cold_sweat","shortness_of_breath","shoulder_pain"],
    min_alarm:1, pattern:"acs",
    label_tr:"Göğüs ağrısı + eşlik eden belirti — ACS ekarte edilmeli",
    label_en:"Chest pain + accompanying symptom — ACS must be ruled out" },
  // İnme — FAST belirtilerinden 2'si
  { triggers:["facial_drooping","arm_weakness","speech_difficulty","sudden_headache","numbness_one_side"],
    min_main:2, alarm:[], min_alarm:0, pattern:"stroke",
    label_tr:"İnme belirtileri — FAST pozitif",
    label_en:"Stroke signs — FAST positive" },
  // Cauda equina — eyer uyuşması + mesane
  { triggers:["saddle_anesthesia","urinary_retention","bladder_dysfunction","bowel_dysfunction"],
    min_main:2, alarm:[], min_alarm:0, pattern:"cauda_equina",
    label_tr:"Cauda equina — acil cerrahi değerlendirme",
    label_en:"Cauda equina — emergency surgical assessment" },
  // Aort diseksiyonu — yırtılır gibi ağrı + sırt
  { triggers:["tearing_pain","sudden_severe_chest_pain"],
    min_main:1, alarm:["back_pain","pain_radiation_back"],
    min_alarm:1, pattern:"aortic_dissection",
    label_tr:"Yırtılır gibi göğüs/sırt ağrısı — aort diseksiyonu ekarte edilmeli",
    label_en:"Tearing chest/back pain — aortic dissection must be ruled out" },
  // Piyelonefrit + sepsis belirtisi
  { triggers:["fever","flank_pain"],
    min_main:2, alarm:["confusion","rapid_breathing","rapid_heart_rate"],
    min_alarm:1, pattern:"sepsis",
    label_tr:"Ateş + yan ağrısı + sistemik belirti — sepsis riski",
    label_en:"Fever + flank pain + systemic signs — sepsis risk" },
  // Ateş + nefes darlığı + sistemik → Pnömoni/Sepsis
  { triggers:["fever","shortness_of_breath"],
    min_main:2, alarm:["confusion","rigors","chest_pain"],
    min_alarm:2, pattern:"pneumonia",
    label_tr:"Ateş + nefes darlığı + sistemik belirti — acil değerlendirme",
    label_en:"Fever + breathlessness + systemic signs — emergency assessment" },
  // Travma sonrası bilinç kaybı / nöbet — tek başına yeterli
  { triggers:["loss_of_consciousness","seizure_after_injury"],
    min_main:1, alarm:[], min_alarm:0, pattern:"head_injury",
    label_tr:"Travma sonrası bilinç kaybı / nöbet — acil görüntüleme",
    label_en:"Post-injury loss of consciousness / seizure — emergent imaging" },
  // Anafilaksi — hava yolu belirtisi + alerjik bağlam
  { triggers:["throat_tightness","lip_face_swelling"],
    min_main:1, alarm:["hives","itchy_welts","rash_after_exposure","shortness_of_breath","dizziness","breathing_difficulty_allergy"],
    min_alarm:1, pattern:"urticaria_allergy",
    label_tr:"Alerjik reaksiyonda hava yolu tutulumu — anafilaksi yolu",
    label_en:"Airway involvement in allergic reaction — anaphylaxis pathway" },
  // Ani görme kaybı / perde — aynı gün retina
  { triggers:["curtain_vision","sudden_vision_loss","painless_vision_loss"],
    min_main:1, alarm:["flashes_of_light","sudden_floaters","eye_pain","headache","red_eye","blurred_vision"],
    min_alarm:1, pattern:"retinal_detachment",
    label_tr:"Ani görme kaybı / perde inmesi — aynı gün retina değerlendirmesi",
    label_en:"Sudden vision loss / curtain — same-day retina evaluation" },
];

function checkRedFlags(collectedTriggers, lang) {
  for (const rule of RED_FLAG_RULES) {
    const mainHits = rule.triggers.filter(t => collectedTriggers.includes(t)).length;
    const alarmHits = rule.alarm.filter(t => collectedTriggers.includes(t)).length;
    const mainOk = mainHits >= rule.min_main;
    const alarmOk = rule.min_alarm === 0 || alarmHits >= rule.min_alarm;
    if (mainOk && alarmOk) {
      const p = PATTERNS[rule.pattern];
      return {
        routing: "RED",
        lambda: 15,
        pattern: rule.pattern,
        label: lang === "tr" ? rule.label_tr : rule.label_en,
        diffs: [{
          name: lang==="tr" ? (OFFLINE_PATTERN_NAMES_TR[rule.pattern]||p?.name||rule.pattern) : (p?.name||rule.pattern),
          pct: 85, risk: "critical", source: p?.source||""
        }],
        doctorAlert: p?.doctor_alert || "",
        urgency: lang==="tr" ? OFFLINE_URGENCY_TR["RED"] : OFFLINE_URGENCY_EN["RED"],
      };
    }
  }
  return null;
}

// Offline karar motoru
// ── DETERMINISTIC CLINICAL SAFETY ESCALATION ──
// Hard override: specific red-flag features push YELLOW→RED regardless of score or LLM output.
// These are life-threatening presentations a kiosk cannot rule out, so the system over-triages by design (false-negative-first).
function clinicalEscalation(routing, conditionId, triggers) {
  if (routing === "RED") return routing;
  const id = (conditionId || "").toLowerCase();
  const has = t => triggers.includes(t);
  const anyOf = (...ts) => ts.some(has);
  const sirs = anyOf("fever","tachycardia","racing_heart","rapid_heartbeat","shortness_of_breath","rapid_breathing","low_blood_pressure");
  // Cholecystitis + jaundice/pale stool → possible biliary obstruction / ascending cholangitis (Charcot triad). Emergency.
  if ((id === "cholecystitis" || id === "k81") && anyOf("jaundice","clay_stool")) return "RED";
  // Acute pancreatitis + any systemic inflammatory sign (SIRS proxy) → risk of severe AP. Emergency.
  if ((id === "pancreatitis" || id === "k85") && sirs) return "RED";
  // Type 1 diabetes + DKA picture (ketotic breath, or vomiting with rapid onset / abdominal pain) → diabetic ketoacidosis. Emergency.
  if ((id === "diabetes_t1" || id === "e10") && (has("fruity_breath") || (has("vomiting") && anyOf("rapid_onset","abdominal_pain")))) return "RED";
  // Adrenal insufficiency / Addison's + hypotension or vomiting+dizziness → adrenal crisis (shock). Emergency.
  if ((id === "addisons" || id === "e27.1") && (has("low_blood_pressure") || (has("vomiting") && has("dizziness")))) return "RED";
  // Appendicitis + rebound tenderness (peritoneal sign) → perforation/peritonitis. Surgical emergency.
  if ((id === "appendicitis" || id === "k37") && has("rebound_tenderness")) return "RED";
  // Kidney stone + fever → infected obstructed stone / urosepsis. Emergency.
  if ((id === "kidney_stones" || id === "n20") && has("fever")) return "RED";
  // DVT + breathlessness/chest pain/hemoptysis → pulmonary embolism. Emergency.
  if ((id === "dvt" || id === "i80.2") && anyOf("shortness_of_breath","chest_pain","coughing_blood","rapid_breathing")) return "RED";
  // ── Travma / cilt / göz eskalasyonları ──
  if ((id === "head_injury" || id === "s06.0") && anyOf("loss_of_consciousness","repeated_vomiting","seizure_after_injury")) return "RED";
  if ((id === "fracture_suspect" || id === "t14.2") && anyOf("open_wound","limb_numb_pale")) return "RED";
  if ((id === "laceration" || id === "s61.9") && has("bleeding_uncontrolled")) return "RED";
  if ((id === "cellulitis" || id === "l03.9") && anyOf("fever","red_streaks")) return "RED";
  if ((id === "shingles" || id === "b02.9") && has("rash_near_eye")) return "RED";
  if ((id === "urticaria_allergy" || id === "l50.9") && anyOf("throat_tightness","lip_face_swelling","breathing_difficulty_allergy")) return "RED";
  return routing;
}
function escalationNote(conditionId, triggers, lang) {
  const id = (conditionId || "").toLowerCase();
  const has = t => triggers.includes(t);
  if ((id === "cholecystitis" || id === "k81") && (has("jaundice") || has("clay_stool")))
    return lang === "tr"
      ? "ESKALASYON: Sarılık / açık renkli dışkı = olası safra yolu tıkanıklığı veya asendan kolanjit (Charcot triadı). Acil değerlendirme; antibiyotik + acil safra drenajı gerekebilir."
      : "ESCALATION: Jaundice / pale stool = possible biliary obstruction or ascending cholangitis (Charcot triad). Emergency workup; may require antibiotics + urgent biliary drainage.";
  if (id === "pancreatitis" || id === "k85")
    return lang === "tr"
      ? "ESKALASYON: Pankreatit + sistemik enflamasyon işareti (SIRS) = ağır seyir riski. Acil servis değerlendirmesi (lipaz, IV sıvı, izlem)."
      : "ESCALATION: Pancreatitis + systemic inflammatory sign (SIRS) = risk of severe course. Emergency department evaluation (lipase, IV fluids, monitoring).";
  if (id === "diabetes_t1" || id === "e10")
    return lang === "tr"
      ? "ESKALASYON: Tip 1 diyabet + DKA bulguları (asetonlu/meyveli nefes ya da kusma + ani başlangıç). Diyabetik ketoasidoz hayati acildir. Acil glukoz + keton + IV sıvı."
      : "ESCALATION: Type 1 diabetes + DKA features (fruity/acetone breath or vomiting + rapid onset). Diabetic ketoacidosis is life-threatening. Urgent glucose + ketones + IV fluids.";
  if (id === "addisons" || id === "e27.1")
    return lang === "tr"
      ? "ESKALASYON: Adrenal yetmezlik + kriz bulguları (düşük tansiyon ya da kusma + baş dönmesi). Adrenal kriz = şok. Acil IV hidrokortizon + sıvı."
      : "ESCALATION: Adrenal insufficiency + crisis signs (low blood pressure or vomiting + dizziness). Adrenal crisis = shock. Emergency IV hydrocortisone + fluids.";
  if (id === "appendicitis" || id === "k37")
    return lang === "tr"
      ? "ESKALASYON: Apandisit + rebound (geri tepme) hassasiyeti = peritoneal bulgu, olası perforasyon/peritonit. Cerrahi acil."
      : "ESCALATION: Appendicitis + rebound tenderness = peritoneal sign, possible perforation/peritonitis. Surgical emergency.";
  if (id === "kidney_stones" || id === "n20")
    return lang === "tr"
      ? "ESKALASYON: Böbrek taşı + ateş = enfekte tıkalı taş / ürosepsis riski. Acil; tıkanıklığın acil drenajı gerekebilir."
      : "ESCALATION: Kidney stone + fever = infected obstructed stone / urosepsis risk. Emergency; obstruction may need urgent drainage.";
  if (id === "dvt" || id === "i80.2")
    return lang === "tr"
      ? "ESKALASYON: DVT + nefes darlığı / göğüs ağrısı / kan tükürme = olası pulmoner emboli. Acil."
      : "ESCALATION: DVT + breathlessness / chest pain / hemoptysis = possible pulmonary embolism. Emergency.";
  if ((id === "head_injury" || id === "s06.0") && (has("loss_of_consciousness") || has("repeated_vomiting") || has("seizure_after_injury")))
    return lang === "tr"
      ? "ESKALASYON: Travma sonrası bilinç kaybı / tekrarlayan kusma / nöbet = acil BT endikasyonu (Canadian CT Head Rule). Acil servis."
      : "ESCALATION: Post-injury LOC / repeated vomiting / seizure = emergent CT indication (Canadian CT Head Rule). ED now.";
  if ((id === "fracture_suspect" || id === "t14.2") && (has("open_wound") || has("limb_numb_pale")))
    return lang === "tr"
      ? "ESKALASYON: Kırık bölgesinde açık yara veya uyuşuk/soluk uzuv = açık kırık / nörovasküler tehlike. Acil cerrahi değerlendirme."
      : "ESCALATION: Open wound over fracture or numb/pale limb = open fracture / neurovascular compromise. Emergent surgical evaluation.";
  if ((id === "laceration" || id === "s61.9") && has("bleeding_uncontrolled"))
    return lang === "tr"
      ? "ESKALASYON: Basınca rağmen durmayan kanama = acil kanama kontrolü gerekir."
      : "ESCALATION: Bleeding uncontrolled by direct pressure = emergent hemorrhage control.";
  if ((id === "cellulitis" || id === "l03.9") && (has("fever") || has("red_streaks")))
    return lang === "tr"
      ? "ESKALASYON: Selülit + ateş veya kırmızı çizgiler (lenfanjit) = sistemik yayılım. IV antibiyotik / acil değerlendirme."
      : "ESCALATION: Cellulitis + fever or red streaks (lymphangitis) = systemic spread. IV antibiotics / emergency evaluation.";
  if ((id === "shingles" || id === "b02.9") && has("rash_near_eye"))
    return lang === "tr"
      ? "ESKALASYON: Göz çevresinde zona (Hutchinson bulgusu) = görmeyi tehdit eden oftalmik tutulum. Acil göz hastalıkları."
      : "ESCALATION: Zoster near the eye (Hutchinson sign) = sight-threatening ophthalmic involvement. Urgent ophthalmology.";
  if ((id === "urticaria_allergy" || id === "l50.9") && (has("throat_tightness") || has("lip_face_swelling") || has("breathing_difficulty_allergy")))
    return lang === "tr"
      ? "ESKALASYON: Boğaz daralması / dudak-dil şişmesi = anafilaksi yolu. Epinefrin + acil servis."
      : "ESCALATION: Throat tightness / lip-tongue swelling = anaphylaxis pathway. Epinephrine + ED.";
  return "";
}

// ═══════════════════════════════════════════════════════════════════
// SPRT ENGINE v2 — true two-boundary sequential probability ratio test
// Replaces heuristic (hits × sprt_lr × mod). Theory: Math Foundations
// §02 (upper bound h=log(1/α)), §4.2 (lower bound h_lower=log(β)),
// PhD Appendix (Wald forms a=log(β/(1−α)), b=log((1−β)/α)).
// Per-symptom LRs are FIRST-PASS CALIBRATION derived from pattern-level
// sprt_lr; structure accepts per-symptom literature overrides
// (pattern.lrOverrides = { trigger_id: {plus, minus} }) — calibration
// against MIMIC-IV is the PhD-phase task. Guarantees are conditional on
// correctly specified LRs (Pre-Mortem Risk 8).
// ═══════════════════════════════════════════════════════════════════
const SPRT_CFG = {
  ALPHA: 0.05,                       // max false-RED (Type I)
  BETA: 0.05,                        // max missed-emergency (Type II / FNR)
  B_UPPER: Math.log(0.95 / 0.05),    // ≈ +2.944 — confirm boundary (Wald b)
  A_LOWER: Math.log(0.05 / 0.95),    // ≈ −2.944 — exclude boundary (Wald a)
  PRIOR_CLAMP: 1.5,   // |S₀| ≤ 1.5: prior may nudge, never pre-decide
  MOD_CLAMP: 1.2,     // demographic multiplier contribution cap (log space)
  PREV_W: 0.25, PREV_REF: 5.0, PREV_CLAMP: 0.4,  // relative-prevalence term
  GATE_ON: Math.log(1.4), GATE_OFF: -Math.log(1.4), // gate prior shift
  LR_FLOOR: 1.3,      // floor for sprt_lr<1 patterns (anxiety 0.6 etc.)
  TRIG_W: 0.5,        // non-confirmatory present: y = 0.5·log(LR)
  LRM_CONF: 0.35,     // confirmatory ABSENT → LR⁻ (strong negative evidence)
  LRM_TRIG: 0.7,      // trigger ABSENT → LR⁻ (mild negative evidence)
  ABSTAIN_MARGIN: 0.8, // critical blocks GREEN unless S ≤ A_LOWER+margin
  LEAN_MIN: 1.0,      // unconfirmed lean → provisional routing if S ≥ 1.0
  LAMBDA_MIN: 0.012, LAMBDA_MAX: 95,
};
const SPRT_SEV = { critical: 3, high: 2, moderate: 1, low: 0 };
const SPRT_ROUTE_RANK = { RED: 3, GREY: 2, YELLOW: 1, GREEN: 0 };
const sprtClamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

// log-likelihood contribution of one symptom for one pattern
function sprtSymptomY(pat, trig, present, conf) {
  const ov = pat.lrOverrides?.[trig];
  let yh;
  if (ov) yh = Math.log(present ? (ov.plus || 1) : (ov.minus || 1));
  else {
    const base = Math.max(pat.sprt_lr || 1, SPRT_CFG.LR_FLOOR);
    const isConf = (pat.confirmatory || []).includes(trig);
    yh = present
      ? (isConf ? 1 : SPRT_CFG.TRIG_W) * Math.log(base)
      : Math.log(isConf ? SPRT_CFG.LRM_CONF : SPRT_CFG.LRM_TRIG);
  }
  // Soft evidence (Tez Bölüm 3.3): beklenen-LR altında entegrasyon.
  // LR_eff = c·e^{y} + (1−c)·1  →  y_soft = log(LR_eff).
  // c = ekstraktörün kalibre olasılığı; c=1 klasik (hard) SPRT'yi BİREBİR verir,
  // c→0 katkıyı sıfıra çeker (log 1 = 0). |y_soft| ≤ |y_hard| her zaman.
  const c = conf == null ? 1 : Math.max(0, Math.min(1, conf));
  if (c >= 1) return yh;
  return Math.log(c * Math.exp(yh) + (1 - c));
}

// clamped prior offset S₀ = demographics + relative prevalence + gate
function sprtPrior(pat, key, riskMods, gateBonus) {
  const mod = riskMods?.[key] ?? 1.0;
  let s0 = sprtClamp(Math.log(Math.max(mod, 0.05)), -SPRT_CFG.MOD_CLAMP, SPRT_CFG.MOD_CLAMP);
  s0 += sprtClamp(SPRT_CFG.PREV_W * Math.log((pat.base_prevalence || 1) / SPRT_CFG.PREV_REF), -SPRT_CFG.PREV_CLAMP, SPRT_CFG.PREV_CLAMP);
  if (gateBonus && gateBonus.length > 0) s0 += gateBonus.includes(key) ? SPRT_CFG.GATE_ON : SPRT_CFG.GATE_OFF;
  return sprtClamp(s0, -SPRT_CFG.PRIOR_CLAMP, SPRT_CFG.PRIOR_CLAMP);
}

// run parallel SPRTs over patternKeys given present/absent trigger sets
function runSPRT(patternKeys, present, absent, riskMods, gateBonus, PAT, confMap) {
  // confMap: {trigger_id: P(present|anlatı)} — LLM'in kalibre olasılıkları (online).
  // Varlık kanalı c = p; yokluk kanalı c = 1−p (yokluk iddiasının gücü). Yoksa c=1.
  const cm = confMap || null;
  const per = {};
  const presentSet = new Set(present);
  const absentSet = new Set((absent || []).filter(t => !presentSet.has(t)));
  for (const key of patternKeys) {
    const pat = PAT[key];
    if (!pat) continue;
    const presRel = (pat.triggers || []).filter(t => presentSet.has(t));
    const absRel = (pat.triggers || []).filter(t => absentSet.has(t));
    const reqMet = (pat.required_any || []).length === 0 || pat.required_any.some(r => presentSet.has(r));
    const active = reqMet && presRel.length >= 1;
    if (!active) { per[key] = { active: false, status: "inactive", S: null }; continue; }
    const s0 = sprtPrior(pat, key, riskMods, gateBonus);
    let S = s0;
    const traj = [{ t: "prior", y: s0, S: s0 }];
    for (const t of presRel) { const c = cm && typeof cm[t] === "number" ? cm[t] : 1; const y = sprtSymptomY(pat, t, true, c); S += y; traj.push({ t, y, S, present: true }); }
    for (const t of absRel) { const c = cm && typeof cm[t] === "number" ? (1 - cm[t]) : 1; const y = sprtSymptomY(pat, t, false, c); S += y; traj.push({ t, y, S, present: false }); }
    const status = S >= SPRT_CFG.B_UPPER ? "confirmed" : S <= SPRT_CFG.A_LOWER ? "excluded" : "indeterminate";
    per[key] = { active: true, status, S, s0, traj, presRel, absRel, risk: pat.risk || "moderate" };
  }
  const byS = st => Object.keys(per).filter(k => per[k].status === st)
    .sort((a, b) => (SPRT_SEV[per[b].risk] - SPRT_SEV[per[a].risk]) || (per[b].S - per[a].S));
  return { per, confirmed: byS("confirmed"), indeterminate: byS("indeterminate"), excluded: byS("excluded") };
}

// posterior-share differentials — geniş aday seti (en az 1 trigger eşleşen tüm hipotezler).
// routing kararından BAĞIMSIZ: yalnız doktor-modu tablosu için zengin ayırıcı tanı üretir.
function sprtDiffs(sprt, lang, PAT, namesTR, present, absent, riskMods, gateBonus) {
  const presentSet = new Set(present || []);
  const absentSet = new Set((absent || []).filter(t => !presentSet.has(t)));
  // Önce runSPRT'nin tam aktif hipotezleri (confirmed/indeterminate skorlarıyla)
  const scored = {};
  for (const [k, v] of Object.entries(sprt.per)) {
    if (v.active && v.S != null) scored[k] = v.S;
  }
  // Sonra: aktif sayılmayan ama ≥1 trigger eşleşen hipotezleri de aday olarak ekle (gevşek skor).
  // Bu yalnız tablo için; required_any karşılanmadıysa hafif ceza ile dahil edilir.
  const candidateKeys = gateBonus && gateBonus.length
    ? [...new Set([...gateBonus, ...Object.keys(scored)])]
    : Object.keys(PAT);
  for (const k of candidateKeys) {
    if (scored[k] != null) continue;
    const pat = PAT[k]; if (!pat) continue;
    const presRel = (pat.triggers || []).filter(t => presentSet.has(t));
    if (presRel.length < 1) continue;
    const reqMet = (pat.required_any || []).length === 0 || pat.required_any.some(r => presentSet.has(r));
    let s = sprtPrior(pat, k, riskMods || {}, gateBonus || []);
    for (const t of presRel) s += sprtSymptomY(pat, t, true, 1);
    for (const t of (pat.triggers || []).filter(t => absentSet.has(t))) s += sprtSymptomY(pat, t, false, 1);
    if (!reqMet) s -= 0.7; // required_any yoksa hafif indirim (aday kalır ama geride)
    scored[k] = s;
  }
  const entries = Object.entries(scored);
  if (entries.length === 0) return [];
  const tot = entries.reduce((acc, [, s]) => acc + Math.exp(s), 0) || 1;
  return entries
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([k, s]) => ({
      name: lang === "tr" ? (namesTR[k] || PAT[k]?.name || k) : (PAT[k]?.name || k),
      pct: Math.round((Math.exp(s) / tot) * 1000) / 10,  // küsuratlı: 85.3 gibi
      risk: PAT[k]?.risk || "moderate",
      source: PAT[k]?.source || "",
    }));
}

// compact doctor-mode narrative of the decision statistic
function sprtNarrative(key, c) {
  if (!c || !c.traj) return "";
  const terms = c.traj.slice(1, 7).map(s => `${s.present ? "+" : "−"}${s.t} ${s.y >= 0 ? "+" : ""}${s.y.toFixed(2)}`).join(" · ");
  const more = c.traj.length > 7 ? " · …" : "";
  return `[SPRT] ${key}: S₀=${c.s0 >= 0 ? "+" : ""}${c.s0.toFixed(2)} · ${terms}${more} → S=${c.S.toFixed(2)} (bounds ${SPRT_CFG.A_LOWER.toFixed(2)}/${SPRT_CFG.B_UPPER.toFixed(2)}, odds ${Math.exp(c.S).toFixed(1)}:1) → ${c.status}`;
}

const sprtLambda = S => sprtClamp(Math.exp(S), SPRT_CFG.LAMBDA_MIN, SPRT_CFG.LAMBDA_MAX);

// core decision: returns result object, or null = keep questioning / no match
function sprtDecide(opts) {
  const { collected, absent, riskMods, askedCount, gate, lang, force,
    patternKeys, PAT, namesTR, urgTR, urgEN, escalateFn, escNoteFn, redFlagFn, minQuestions, confMap} = opts;
  const gateBonus = gate ? (opts.gatePatterns?.[gate] || []) : [];
  const redFlag = redFlagFn(collected, lang);
  if (redFlag) {
    // Routing/label/urgency red-flag'ten gelir; ama ayırıcı tanı + λ'yı SPRT'ten türet.
    const rfSprt = runSPRT(patternKeys, collected, absent, riskMods, gateBonus, PAT, confMap);
    const rfDiffs = sprtDiffs(rfSprt, lang, PAT, namesTR, collected, absent, riskMods, gateBonus);
    // λ: red-flag pattern'inin gerçek SPRT skorundan; yoksa aktif liderden. Red-flag tabanı 9.6 korunur.
    const rfKey = redFlag.pattern;
    const rfS = rfSprt.per[rfKey]?.active ? rfSprt.per[rfKey].S
      : (rfSprt.confirmed[0] ? rfSprt.per[rfSprt.confirmed[0]].S
      : (rfSprt.indeterminate[0] ? rfSprt.per[rfSprt.indeterminate[0]].S : null));
    const rfLambda = rfS != null ? Math.max(9.6, sprtLambda(rfS)) : redFlag.lambda;
    // SPRT yörüngesini de taşı (QR'daki hesap satırı için) — lider hipotezin izini ekle.
    const rfLeadKey = rfSprt.per[rfKey]?.active ? rfKey : (rfSprt.confirmed[0] || rfSprt.indeterminate[0]);
    const rfLead = rfLeadKey ? rfSprt.per[rfLeadKey] : null;
    const rfSprtPayload = rfLead ? { topKey: rfLeadKey, S: rfLead.S, s0: rfLead.s0, traj: rfLead.traj, A: SPRT_CFG.A_LOWER, B: SPRT_CFG.B_UPPER, confirmed: rfSprt.confirmed, excluded: rfSprt.excluded } : null;
    return { ...redFlag, lambda: rfLambda, diffs: rfDiffs.length ? rfDiffs : redFlag.diffs, sprt: rfSprtPayload || redFlag.sprt, engine: "sprt-v2" };
  }
  if (!force && askedCount < minQuestions) return null;

  const sprt = runSPRT(patternKeys, collected, absent, riskMods, gateBonus, PAT, confMap);
  const urg = r => (lang === "tr" ? urgTR : urgEN)[r];
  const diffs = sprtDiffs(sprt, lang, PAT, namesTR, collected, absent, riskMods, gateBonus);

  // ── confirmed hypotheses: worst effective routing wins ──
  if (sprt.confirmed.length > 0) {
    let topKey = null, topRoute = "GREEN", escalatedAny = false;
    for (const k of sprt.confirmed) {
      const base = PAT[k]?.routing_if_confirmed || "YELLOW";
      const eff = escalateFn(base, k, collected);
      if (eff !== base) escalatedAny = true;
      if (!topKey || SPRT_ROUTE_RANK[eff] > SPRT_ROUTE_RANK[topRoute] ||
        (SPRT_ROUTE_RANK[eff] === SPRT_ROUTE_RANK[topRoute] && sprt.per[k].S > sprt.per[topKey].S)) {
        topKey = k; topRoute = eff;
      }
    }
    const c = sprt.per[topKey];
    const escNote = escalatedAny ? escNoteFn(topKey, collected, lang) : "";
    const alertParts = [escNote, sprtNarrative(topKey, c), PAT[topKey]?.doctor_alert || ""].filter(Boolean);
    return {
      routing: topRoute,
      lambda: escalatedAny ? Math.max(9.6, sprtLambda(c.S)) : sprtLambda(c.S),
      diffs, doctorAlert: alertParts.join("\n\n"), urgency: urg(topRoute),
      escalated: escalatedAny, engine: "sprt-v2",
      sprt: { topKey, S: c.S, s0: c.s0, traj: c.traj, A: SPRT_CFG.A_LOWER, B: SPRT_CFG.B_UPPER, confirmed: sprt.confirmed, excluded: sprt.excluded },
    };
  }

  // ── nothing confirmed ──
  if (!force) return null; // sequential: keep questioning

  // Eskalasyon TABANI: belirsizlik (soft evidence) deterministik güvenlik kurallarını
  // susturamaz. Açık (indeterminate) hipotezlerden herhangi biri kural-RED veriyorsa,
  // GREY çekimserliğine düşmeden önce RED'e yükselt — red-flag'lerle aynı doktrin.
  for (const ek of sprt.indeterminate) {
    if (escalateFn("YELLOW", ek, collected) === "RED") {
      const ec = sprt.per[ek];
      const note = escNoteFn(ek, collected, lang) || "";
      const parts = [note, sprtNarrative(ek, ec), PAT[ek]?.doctor_alert || ""].filter(Boolean);
      return {
        routing: "RED", lambda: Math.max(9.6, sprtLambda(ec.S)), diffs,
        doctorAlert: parts.join("\n\n"), urgency: urg("RED"),
        escalated: true, engine: "sprt-v2",
        sprt: { topKey: ek, S: ec.S, s0: ec.s0, traj: ec.traj, A: SPRT_CFG.A_LOWER, B: SPRT_CFG.B_UPPER, confirmed: sprt.confirmed, excluded: sprt.excluded },
      };
    }
  }

  // force-finalize: formal abstention if a critical hypothesis is still open
  const openCritical = sprt.indeterminate.filter(k =>
    (PAT[k]?.risk === "critical") && sprt.per[k].S > SPRT_CFG.A_LOWER + SPRT_CFG.ABSTAIN_MARGIN);
  if (openCritical.length > 0) {
    const k = openCritical[0]; const c = sprt.per[k];
    return {
      routing: "GREY", lambda: sprtLambda(c.S), diffs,
      doctorAlert: `${sprtNarrative(k, c)}\n\n${PAT[k]?.doctor_alert || ""}`,
      urgency: urg("GREY"), escalated: false, engine: "sprt-v2",
      sprt: { topKey: k, S: c.S, s0: c.s0, traj: c.traj, A: SPRT_CFG.A_LOWER, B: SPRT_CFG.B_UPPER, confirmed: [], excluded: sprt.excluded, abstained: true },
    };
  }

  // provisional lean or GREEN fallback
  const open = sprt.indeterminate;
  if (open.length === 0) {
    if (diffs.length === 0) return null; // truly nothing matched — caller message
    return { routing: "GREEN", lambda: 0.05, diffs, doctorAlert: PAT[Object.keys(sprt.per).find(k => sprt.per[k].active)]?.doctor_alert || "", urgency: urg("GREEN"), escalated: false, engine: "sprt-v2", sprt: null };
  }
  const k = open[0]; const c = sprt.per[k];
  let routing = "GREEN";
  if (c.S >= SPRT_CFG.LEAN_MIN) {
    const base = PAT[k]?.routing_if_confirmed || "YELLOW";
    routing = base === "RED" ? "GREY" : base;
  }
  const eff = escalateFn(routing, k, collected);
  const escNote = eff !== routing ? escNoteFn(k, collected, lang) : "";
  return {
    routing: eff, lambda: eff !== routing ? Math.max(9.6, sprtLambda(c.S)) : sprtLambda(c.S), diffs,
    doctorAlert: [escNote, sprtNarrative(k, c), PAT[k]?.doctor_alert || ""].filter(Boolean).join("\n\n"),
    urgency: urg(eff), escalated: eff !== routing, engine: "sprt-v2",
    sprt: { topKey: k, S: c.S, s0: c.s0, traj: c.traj, A: SPRT_CFG.A_LOWER, B: SPRT_CFG.B_UPPER, confirmed: [], excluded: sprt.excluded },
  };
}

// expected discrimination value of asking question q given current SPRT state:
// severity-weighted, plausibility-weighted movement toward either boundary,
// plus discovery value for hypotheses the question could newly activate.
function sprtQuestionGain(q, state, present, absent, patternKeys, PAT) {
  const yesTrigs = (q.type === "yn" ? (q.triggers_yes || []) : [q.scale_trigger, ...(q.scale_high_triggers || [])]).filter(Boolean);
  const newTrigs = yesTrigs.filter(t => !present.includes(t) && !absent.includes(t));
  if (newTrigs.length === 0) return 0;
  let gain = 0;
  for (const key of patternKeys) {
    const pat = PAT[key]; if (!pat) continue;
    const rel = newTrigs.filter(t => (pat.triggers || []).includes(t));
    if (rel.length === 0) continue;
    const sev = (SPRT_SEV[pat.risk || "moderate"] ?? 1) + 0.5;
    const st = state.per[key];
    if (st && st.active && st.status === "indeterminate") {
      const plaus = Math.exp(Math.min(st.S, 2)); // capped posterior plausibility
      const dYes = rel.reduce((s, t) => s + Math.abs(sprtSymptomY(pat, t, true)), 0);
      const dNo = rel.reduce((s, t) => s + Math.abs(sprtSymptomY(pat, t, false)), 0);
      gain += sev * plaus * (dYes + dNo) / 2;
    } else if (!st || !st.active) {
      if ((pat.required_any || []).some(r => newTrigs.includes(r))) {
        const dYes = rel.reduce((s, t) => s + Math.abs(sprtSymptomY(pat, t, true)), 0);
        gain += sev * 0.4 * dYes; // discovery weight for waking a hypothesis
      }
    }
  }
  return gain * (q.weight || 1);
}
// ═══════════════════════════ END SPRT ENGINE v2 ═══════════════════════════

function computeOfflineResult(collectedTriggers, riskMods, askedCount, selectedGate, lang, force=false, absentTriggers=[]) {
  const relevantPatterns = GATE_PATTERNS[selectedGate]
    ? [...new Set([...(GATE_PATTERNS[selectedGate] || []), ...OFFLINE_PATTERNS])]
    : OFFLINE_PATTERNS;
  return sprtDecide({
    collected: collectedTriggers, absent: absentTriggers, riskMods, askedCount,
    gate: selectedGate, lang, force,
    patternKeys: relevantPatterns, PAT: PATTERNS,
    namesTR: OFFLINE_PATTERN_NAMES_TR, urgTR: OFFLINE_URGENCY_TR, urgEN: OFFLINE_URGENCY_EN,
    escalateFn: clinicalEscalation, escNoteFn: escalationNote, redFlagFn: checkRedFlags,
    minQuestions: MIN_QUESTIONS_BEFORE_DECISION, gatePatterns: GATE_PATTERNS,
  });
}

const OFFLINE_PATTERN_NAMES_TR = {
  acs: "Akut Koroner Sendrom", stroke: "İnme / TİA", migraine: "Migren",
  uti: "İdrar Yolu Enfeksiyonu", hypothyroidism: "Hipotiroidizm",
  influenza: "Grip", gerd: "Mide Reflüsü", ibs: "İrritabl Bağırsak",
  lumbar_radiculopathy: "Bel Fıtığı / Sinir Sıkışması",
  cauda_equina: "Cauda Equina Sendromu", anxiety: "Anksiyete / Panik",
  anemia: "Anemi", pyelonephritis: "Böbrek İltihabı",
  head_injury:"Kafa Travması / Beyin Sarsıntısı", fracture_suspect:"Kırık Şüphesi", sprain_strain:"Burkulma / Zorlanma", laceration:"Kesik / Açık Yara",
  cellulitis:"Selülit (Cilt Enfeksiyonu)", urticaria_allergy:"Ürtiker / Alerjik Reaksiyon", contact_dermatitis:"Kontakt Dermatit / Egzama", shingles:"Zona",
  conjunctivitis:"Konjonktivit", corneal_abrasion:"Kornea Çizilmesi / Yabancı Cisim", retinal_detachment:"Retina Dekolmanı / Ani Görme Kaybı", acute_glaucoma:"Akut Glokom",
};
const OFFLINE_URGENCY_TR = {
  RED: "Hemen 112'yi arayın veya acil servise gidin.",
  YELLOW: "Bugün bir doktora görünün.",
  GREEN: "Belirtiler kötüleşirse, yeni belirti eklenirse veya 48 saat içinde geçmezse bir doktora görünün.",
  GREY: "Örüntü güvenli otomatik karar için yeterince net değil. Lütfen görevli doktora başvurun ya da bugün doktorunuzu arayın.",
};
const OFFLINE_URGENCY_EN = {
  RED: "Call 911 or go to the ED immediately.",
  YELLOW: "See a doctor today.",
  GREEN: "If symptoms worsen, new symptoms appear, or they don't improve within 48 hours, see a doctor.",
  GREY: "The pattern is not clear enough for a safe automated decision. Please see the on-site doctor or call your doctor today.",
};

function computeRiskProfile(profile) {
  const {age,sex,bmi,smoking,diabetes,hypertension,familyHistory}=profile;
  const mods={};
  const bmiCat=!bmi?"unknown":bmi<18.5?"underweight":bmi<25?"normal":bmi<30?"overweight":bmi<35?"obese_1":"obese_2";
  const obese = bmiCat==="obese_1"||bmiCat==="obese_2";
  const female = sex==="female";
  const male = sex==="male";
  const older = age>60; const middle = age>40; const young = age<35;

  mods.diabetes_t2=1.0*(bmiCat==="obese_2"?3.2:bmiCat==="obese_1"?2.1:bmiCat==="overweight"?1.5:1.0)*(age>45?1.8:age>35?1.3:1.0)*(familyHistory?1.6:1.0)*(smoking?1.3:1.0);
  mods.diabetes_t1=1.0*(young?2.0:1.0)*(familyHistory?2.0:1.0);
  mods.hypothyroidism=1.0*(female?5.0:1.0)*(older?1.8:1.0);
  mods.hyperthyroidism=1.0*(female?7.0:1.0)*(age>20&&age<50?1.5:1.0);
  mods.cushings=1.0*(female?3.0:1.0)*(obese?1.5:1.0)*(age>20&&age<50?1.5:1.0);
  mods.addisons=1.0*(female?2.0:1.0)*(age>20&&age<50?1.5:1.0);
  mods.pcos=female&&age<50?1.0*(bmiCat==="obese_1"||bmiCat==="obese_2"?1.8:1.0)*(age>13&&age<45?2.0:0.1):0.0;
  mods.acs=1.0*(male?1.8:1.0)*(age>65?3.0:age>50?2.0:age>40?1.4:0.6)*(diabetes?2.0:1.0)*(smoking?1.9:1.0)*(hypertension?1.6:1.0)*(familyHistory?1.5:1.0);
  mods.aortic_dissection=1.0*(male?2.0:1.0)*(age>60?2.5:age>50?1.6:1.0)*(hypertension?2.5:1.0);
  mods.heart_failure=1.0*(age>65?2.5:age>50?1.5:1.0)*(diabetes?1.8:1.0)*(hypertension?2.0:1.0)*(obese?1.6:1.0);
  mods.pe=1.0*(age>50?1.5:1.0)*(obese?1.4:1.0)*(smoking?1.3:1.0);
  mods.stroke=1.0*(age>65?2.5:age>50?1.6:1.0)*(hypertension?2.1:1.0)*(diabetes?1.5:1.0)*(smoking?1.7:1.0);
  mods.hypertensive_crisis=1.0*(age>50?1.8:1.0)*(hypertension?4.0:1.0)*(diabetes?1.4:1.0);
  mods.afib=1.0*(age>65?3.0:age>55?1.8:1.0)*(hypertension?1.8:1.0)*(diabetes?1.4:1.0);
  mods.dvt=1.0*(age>50?1.5:1.0)*(obese?1.5:1.0)*(smoking?1.3:1.0);
  mods.parkinsons=1.0*(age>70?3.0:age>60?2.0:age>50?1.2:0.3)*(male?1.5:1.0);
  mods.essential_tremor=1.0*(age>60?2.0:age>40?1.3:1.0)*(familyHistory?2.0:1.0);
  mods.migraine=1.0*(female?3.0:1.0)*(age>15&&age<55?1.5:0.8);
  mods.ms=1.0*(female?2.5:1.0)*(age>20&&age<40?2.0:0.8);
  mods.epilepsy=1.0*(age<30?1.5:1.0);
  mods.tension_headache=1.0*(female?1.3:1.0)*(middle?1.2:1.0)*(smoking?1.2:1.0);
  mods.lupus=1.0*(female?9.0:1.0)*(age>15&&age<50?2.0:0.6);
  mods.ra=1.0*(female?2.5:1.0)*(age>40&&age<70?1.8:1.0)*(smoking?1.5:1.0)*(familyHistory?1.6:1.0);
  mods.gout=1.0*(male?4.0:1.0)*(age>40?2.0:1.0)*(obese?1.8:1.0)*(diabetes?1.5:1.0);
  mods.fibromyalgia=1.0*(female?7.0:1.0)*(age>30&&age<60?1.5:1.0);
  mods.osteoporosis=1.0*(female?3.0:1.0)*(age>65?3.0:age>50?1.5:0.3)*(bmiCat==="underweight"?2.0:1.0);
  mods.appendicitis=1.0*(age>10&&age<40?2.0:1.0);
  mods.ibd=1.0*(age>15&&age<40?1.8:1.0)*(smoking?1.5:1.0)*(familyHistory?2.0:1.0);
  mods.celiac=1.0*(female?1.5:1.0)*(familyHistory?3.0:1.0);
  mods.peptic_ulcer=1.0*(male?1.5:1.0)*(smoking?2.0:1.0)*(older?1.5:1.0);
  mods.gerd=1.0*(obese?2.5:1.0)*(smoking?1.5:1.0)*(older?1.3:1.0);
  mods.bowel_obstruction=1.0*(older?2.0:1.0);
  mods.cholecystitis=1.0*(female?2.0:1.0)*(obese?2.5:1.0)*(age>40?1.8:1.0);
  mods.pancreatitis=1.0*(male?1.5:1.0)*(age>40?1.5:1.0);
  mods.ibs=1.0*(female?2.0:1.0)*(age>15&&age<50?1.5:1.0);
  mods.nafld=1.0*(bmiCat==="obese_2"?3.5:bmiCat==="obese_1"?2.2:bmiCat==="overweight"?1.5:0.5)*(diabetes?2.0:1.0)*(age>40?1.4:1.0);
  mods.copd=1.0*(smoking?4.0:1.0)*(age>50?2.0:1.0);
  mods.asthma=1.0*(female?1.2:1.0)*(young?1.5:1.0);
  mods.pneumonia=1.0*(older?2.5:1.0)*(smoking?1.5:1.0)*(diabetes?1.5:1.0);
  mods.depression=1.0*(female?1.8:1.0)*(older?1.3:1.0)*(smoking?1.3:1.0);
  mods.anxiety=1.0*(female?2.0:1.0)*(young?1.5:1.0)*(smoking?1.2:1.0);
  mods.bipolar=1.0*(age>15&&age<35?1.8:1.0)*(familyHistory?2.5:1.0);
  mods.ptsd=1.0*(female?2.0:1.0);
  mods.ckd=1.0*(diabetes?2.5:1.0)*(hypertension?2.0:1.0)*(age>60?1.8:1.0);
  mods.kidney_stones=1.0*(male?2.0:1.0)*(age>20&&age<60?1.8:1.0)*(obese?1.4:1.0);
  mods.uti=1.0*(female?10.0:1.0)*(diabetes?2.0:1.0)*(older?1.5:1.0);
  mods.pyelonephritis=1.0*(female?5.0:1.0)*(diabetes?2.5:1.0);
  mods.anemia=1.0*(female?2.5:1.0)*(older?1.5:1.0);
  mods.sleep_apnea=1.0*(bmiCat==="obese_2"?4.0:bmiCat==="obese_1"?2.5:bmiCat==="overweight"?1.6:1.0)*(male?2.0:1.0)*(age>40?1.5:1.0);
  mods.cancer_red_flags=1.0*(age>50?2.5:age>40?1.5:1.0)*(smoking?1.8:1.0)*(familyHistory?1.8:1.0);
  mods.ectopic=female&&age>12&&age<50?1.0:0.0;
  mods.sepsis=1.0*(older?2.0:1.0)*(diabetes?1.8:1.0);
  mods.covid=1.0*(older?2.5:1.0)*(obese?1.5:1.0)*(diabetes?1.6:1.0);
  mods.influenza=1.0*(older?2.0:young?1.3:1.0)*(obese?1.3:1.0);
  mods.lumbar_radiculopathy=1.0*(male?1.3:1.0)*(age>30&&age<65?1.8:1.0)*(obese?1.4:1.0);
  mods.cauda_equina=1.0*(age>30&&age<60?1.5:1.0);
  mods.cellulitis=1.0*(diabetes?2.5:1.0)*(obese?1.5:1.0)*(older?1.4:1.0);
  mods.psoriasis=1.0*(age>15&&age<40?1.5:1.0)*(familyHistory?2.5:1.0)*(smoking?1.4:1.0);
  mods.acute_glaucoma=1.0*(age>50?2.5:1.0)*(female?1.3:1.0);

  return{mods,bmiCat};
}

const PATTERNS = {
  hyperthyroidism:{name:"Hyperthyroidism / Graves",icd:"E05.0",base_prevalence:1.3,sprt_lr:2.8,risk:"moderate",triggers:["tremor","weight_loss","palpitations","heat_intolerance","sweating","anxiety","hair_loss","eye_changes","eye_bulging","frequent_bowel","insomnia","restlessness","increased_appetite"],required_any:["tremor","weight_loss","palpitations","heat_intolerance"],confirmatory:["tremor","weight_loss","palpitations"],routing_if_confirmed:"YELLOW",doctor_alert:"TSH + free T4 indicated. Three-symptom cluster (tremor + weight loss + palpitations) consistent with hyperthyroidism. Graves disease 60-80% of cases.",source:"AAFP 2025; ATA"},
  hypothyroidism:{name:"Hypothyroidism",icd:"E03.9",base_prevalence:4.6,sprt_lr:2.2,risk:"low",triggers:["fatigue","weight_gain","cold_intolerance","constipation","dry_skin","hair_loss","depression","slow_heart_rate","muscle_weakness","hoarse_voice","memory_problems","puffy_face","brittle_nails"],required_any:["fatigue","weight_gain","cold_intolerance","dry_skin"],confirmatory:["fatigue","weight_gain","cold_intolerance"],routing_if_confirmed:"YELLOW",doctor_alert:"TSH screening recommended. Hypothyroidism 5x more common in women. Pattern: fatigue + weight gain + cold intolerance.",source:"AAFP; ATA 2014"},
  diabetes_t2:{name:"Type 2 Diabetes",icd:"E11",base_prevalence:10.5,sprt_lr:3.1,risk:"moderate",triggers:["thirst","frequent_urination","fatigue","weight_loss","blurred_vision","tingling","slow_healing","hunger","frequent_infections","dark_skin_patches","numbness_feet","recurrent_thrush"],required_any:["thirst","frequent_urination","fatigue","weight_loss"],confirmatory:["thirst","frequent_urination","weight_loss"],routing_if_confirmed:"YELLOW",doctor_alert:"Classic triad (polyuria + polydipsia + fatigue/weight loss) highly suggestive of T2DM. Fasting glucose or HbA1c. ADA 2025.",source:"ADA Standards 2025"},
  diabetes_t1:{name:"Type 1 Diabetes",icd:"E10",base_prevalence:0.5,sprt_lr:3.8,risk:"high",triggers:["thirst","frequent_urination","weight_loss","fatigue","blurred_vision","abdominal_pain","nausea","fruity_breath","vomiting","rapid_onset"],required_any:["thirst","frequent_urination","weight_loss"],confirmatory:["thirst","frequent_urination","weight_loss"],routing_if_confirmed:"YELLOW",doctor_alert:"Rapid onset + younger age suggests T1DM vs T2DM. Urgent glucose + ketones. DKA risk.",source:"ADA 2025"},
  cushings:{name:"Cushing Syndrome",icd:"E24",base_prevalence:0.02,sprt_lr:3.2,risk:"moderate",triggers:["weight_gain","round_face","hump_back","stretch_marks","easy_bruising","high_blood_pressure","fatigue","depression","irregular_periods","muscle_weakness","acne","slow_healing"],required_any:["weight_gain","round_face","hump_back","stretch_marks"],confirmatory:["weight_gain","round_face","stretch_marks"],routing_if_confirmed:"YELLOW",doctor_alert:"Central obesity + facial rounding + purple striae: Cushing workup. 24h urine cortisol or overnight dexamethasone suppression.",source:"Endocrine Society 2022"},
  addisons:{name:"Adrenal Insufficiency (Addison's)",icd:"E27.1",base_prevalence:0.02,sprt_lr:3.5,risk:"high",triggers:["fatigue","weight_loss","low_blood_pressure","dizziness","nausea","vomiting","abdominal_pain","skin_darkening","salt_craving","muscle_weakness","depression"],required_any:["fatigue","skin_darkening","low_blood_pressure"],confirmatory:["fatigue","skin_darkening","weight_loss"],routing_if_confirmed:"YELLOW",doctor_alert:"Adrenal crisis risk. Morning cortisol + ACTH stimulation test. Salt craving + hyperpigmentation = classic Addison's.",source:"Endocrine Society 2016"},
  pcos:{name:"PCOS",icd:"E28.2",base_prevalence:8.0,sprt_lr:2.5,risk:"moderate",triggers:["irregular_periods","excess_hair","acne","weight_gain","thinning_hair","difficulty_conceiving","pelvic_pain","oily_skin","mood_changes"],required_any:["irregular_periods","excess_hair","acne"],confirmatory:["irregular_periods","excess_hair"],routing_if_confirmed:"YELLOW",doctor_alert:"Rotterdam criteria: 2 of 3 (irregular ovulation, hyperandrogenism, polycystic ovaries). Pelvic ultrasound + testosterone + LH/FSH.",source:"ESHRE/ASRM 2023"},
  acs:{name:"Acute Coronary Syndrome",icd:"I21",base_prevalence:19.0,sprt_lr:3.8,risk:"critical",triggers:["chest_pain","chest_tightness","chest_pressure","jaw_pain","left_arm_pain","shortness_of_breath","diaphoresis","nausea","back_pain","shoulder_pain","cold_sweat","dizziness"],required_any:["chest_pain","chest_tightness","chest_pressure","left_arm_pain"],confirmatory:["chest_pain","diaphoresis","shortness_of_breath"],routing_if_confirmed:"RED",doctor_alert:"ACS presentation. ECG + troponin immediately. TIMI score. Missed AMI 2.1% from ED.",source:"AHA/ACC 2021"},
  aortic_dissection:{name:"Aortic Dissection",icd:"I71.0",base_prevalence:0.4,sprt_lr:5.5,risk:"critical",triggers:["sudden_severe_chest_pain","tearing_pain","back_pain","pain_radiation_back","difference_in_arm_pulses","severe_chest_back_pain"],required_any:["sudden_severe_chest_pain","tearing_pain","back_pain"],confirmatory:["tearing_pain","back_pain"],routing_if_confirmed:"RED",doctor_alert:"Aortic dissection: sudden tearing pain sensitivity 84%. Emergency CT angiography. Mortality 1-2%/hour.",source:"ESC 2014; JACC"},
  heart_failure:{name:"Heart Failure",icd:"I50",base_prevalence:2.0,sprt_lr:3.5,risk:"high",triggers:["shortness_of_breath","leg_swelling","fatigue","orthopnea","waking_breathless","rapid_weight_gain","reduced_exercise","ankle_swelling","cough_lying_down"],required_any:["shortness_of_breath","leg_swelling"],confirmatory:["shortness_of_breath","leg_swelling","orthopnea"],routing_if_confirmed:"YELLOW",doctor_alert:"Framingham criteria: orthopnea + PND + leg edema. BNP + ECG + echo. Acute decompensation = emergency.",source:"ESC 2021; AHA 2024"},
  pe:{name:"Pulmonary Embolism",icd:"I26",base_prevalence:2.5,sprt_lr:4.2,risk:"critical",triggers:["shortness_of_breath","chest_pain","tachycardia","coughing_blood","recent_immobility","recent_surgery","leg_swelling_one_sided","low_oxygen","sudden_breathlessness"],required_any:["shortness_of_breath","chest_pain","coughing_blood"],confirmatory:["shortness_of_breath","tachycardia","low_oxygen"],routing_if_confirmed:"RED",doctor_alert:"Wells score. D-dimer if low prob; CT-PA if high. Emergency anticoagulation.",source:"ESC 2019"},
  stroke:{name:"Stroke / TIA",icd:"I64",base_prevalence:0.8,sprt_lr:5.8,risk:"critical",triggers:["facial_drooping","arm_weakness","speech_difficulty","sudden_headache","vision_change","confusion","numbness_one_side","dizziness_sudden","loss_of_balance","sudden_vision_loss"],required_any:["facial_drooping","arm_weakness","speech_difficulty","sudden_headache"],confirmatory:["facial_drooping","arm_weakness","speech_difficulty"],routing_if_confirmed:"RED",doctor_alert:"FAST positive. Thrombolysis window 4.5h. Call emergency immediately. No aspirin before imaging.",source:"AHA/ASA 2019"},
  hypertensive_crisis:{name:"Hypertensive Crisis",icd:"I16",base_prevalence:1.0,sprt_lr:3.8,risk:"critical",triggers:["severe_headache","chest_pain","shortness_of_breath","vision_change","nosebleed","confusion","nausea","vomiting","pulsating_headache"],required_any:["severe_headache","chest_pain","vision_change"],confirmatory:["severe_headache","vision_change","chest_pain"],routing_if_confirmed:"RED",doctor_alert:"BP >180/120. End-organ damage assessment: ECG, troponin, creatinine, fundoscopy. IV antihypertensive if symptomatic.",source:"ESC 2018"},
  afib:{name:"Atrial Fibrillation",icd:"I48",base_prevalence:2.0,sprt_lr:2.8,risk:"high",triggers:["palpitations","irregular_heartbeat","racing_heart","shortness_of_breath","fatigue","dizziness","chest_discomfort","reduced_exercise"],required_any:["palpitations","irregular_heartbeat","racing_heart"],confirmatory:["palpitations","irregular_heartbeat","shortness_of_breath"],routing_if_confirmed:"YELLOW",doctor_alert:"ECG urgently. CHA2DS2-VASc for stroke risk. Anticoagulation decision. Rate vs rhythm control.",source:"ESC 2020"},
  dvt:{name:"Deep Vein Thrombosis",icd:"I80.2",base_prevalence:1.5,sprt_lr:3.2,risk:"high",triggers:["leg_swelling_one_sided","leg_pain","leg_warmth","leg_redness","recent_immobility","recent_surgery","calf_pain","tenderness"],required_any:["leg_swelling_one_sided","leg_pain","leg_warmth"],confirmatory:["leg_swelling_one_sided","leg_pain","leg_redness"],routing_if_confirmed:"YELLOW",doctor_alert:"Wells DVT score. Doppler ultrasound. D-dimer if low probability. PE risk: anticoagulate if confirmed.",source:"ACCP 2016"},
  parkinsons:{name:"Parkinson Disease",icd:"G20",base_prevalence:0.3,sprt_lr:3.4,risk:"moderate",triggers:["tremor","stiffness","slow_movement","balance_problems","small_handwriting","loss_of_smell","sleep_disorder","constipation","soft_voice","masked_face","shuffling_gait"],required_any:["tremor","stiffness","slow_movement"],confirmatory:["tremor","stiffness","slow_movement"],routing_if_confirmed:"YELLOW",doctor_alert:"MDS criteria: bradykinesia + resting tremor or rigidity. Pill-rolling 4-6Hz tremor specific. Neurology referral.",source:"MDS Criteria 2015"},
  essential_tremor:{name:"Essential Tremor",icd:"G25.0",base_prevalence:4.0,sprt_lr:1.2,risk:"low",triggers:["tremor","tremor_with_action","head_tremor","voice_tremor","worsens_with_movement","improves_at_rest"],required_any:["tremor","tremor_with_action"],confirmatory:["tremor_with_action"],routing_if_confirmed:"GREEN",doctor_alert:"Action tremor vs resting tremor differentiates from Parkinson. Family history + alcohol responsiveness typical. Neurology if disabling.",source:"MDS; AAFP 2022"},
  migraine:{name:"Migraine",icd:"G43",base_prevalence:12.0,sprt_lr:1.8,risk:"low",triggers:["severe_headache","one_sided_headache","nausea","light_sensitivity","sound_sensitivity","aura","visual_disturbance","throbbing_headache","vomiting","worsens_with_activity"],required_any:["severe_headache","one_sided_headache"],confirmatory:["one_sided_headache","nausea","light_sensitivity"],routing_if_confirmed:"YELLOW",doctor_alert:"IHS criteria: 5+ attacks of unilateral throbbing 4-72h + nausea or photophobia. Rule out SAH if sudden onset worst-ever headache.",source:"IHS 2018"},
  meningitis:{name:"Meningitis",icd:"G03",base_prevalence:0.1,sprt_lr:5.2,risk:"critical",triggers:["severe_headache","neck_stiffness","fever","photophobia","vomiting","rash_non_blanching","confusion","sudden_onset_headache","jolt_sign"],required_any:["severe_headache","neck_stiffness","fever"],confirmatory:["fever","neck_stiffness","severe_headache"],routing_if_confirmed:"RED",doctor_alert:"Classic triad: fever + neck stiffness + altered consciousness. Non-blanching rash = meningococcal. Emergency IV antibiotics before LP.",source:"IDSA 2004; NICE NG240 2023"},
  ms:{name:"Multiple Sclerosis",icd:"G35",base_prevalence:0.3,sprt_lr:2.9,risk:"high",triggers:["vision_loss_one_eye","double_vision","numbness","tingling","weakness","balance_problems","fatigue","bladder_problems","cognitive_problems","heat_worsens"],required_any:["vision_loss_one_eye","numbness","weakness","balance_problems"],confirmatory:["vision_loss_one_eye","numbness","balance_problems"],routing_if_confirmed:"YELLOW",doctor_alert:"McDonald criteria. MRI brain + spine. Optic neuritis = classic first presentation. Neurology urgently.",source:"McDonald 2017; ECTRIMS"},
  epilepsy:{name:"Epilepsy / Seizure",icd:"G40",base_prevalence:1.2,sprt_lr:4.1,risk:"high",triggers:["seizure","convulsion","loss_of_consciousness","blank_staring","jerking_movements","confusion_after_event","tongue_biting","urinary_incontinence","post_ictal"],required_any:["seizure","convulsion","loss_of_consciousness"],confirmatory:["seizure","convulsion","jerking_movements"],routing_if_confirmed:"RED",doctor_alert:"New seizure = emergency workup. EEG + MRI. Rule out structural, metabolic, toxic causes. Status epilepticus = immediate IV benzodiazepine.",source:"ILAE 2017"},
  tension_headache:{name:"Tension-Type Headache",icd:"G44.2",base_prevalence:38.0,sprt_lr:0.8,risk:"low",triggers:["bilateral_headache","pressure_headache","band_around_head","mild_moderate_pain","stress_related","no_nausea","neck_muscle_tension"],required_any:["bilateral_headache","pressure_headache","band_around_head"],confirmatory:["bilateral_headache","pressure_headache"],routing_if_confirmed:"GREEN",doctor_alert:"Differentiate from migraine: bilateral, pressing/tightening, mild-moderate, no nausea. NSAIDs first-line. Rule out secondary causes if new pattern.",source:"IHS 2018"},
  lupus:{name:"Systemic Lupus (SLE)",icd:"M32.9",base_prevalence:0.1,sprt_lr:3.6,risk:"high",triggers:["butterfly_rash","joint_pain","fatigue","fever","hair_loss","mouth_sores","sun_sensitivity","chest_pain_pleurisy","kidney_symptoms","photosensitivity","rash_after_sun"],required_any:["butterfly_rash","joint_pain","sun_sensitivity"],confirmatory:["butterfly_rash","joint_pain","fatigue"],routing_if_confirmed:"YELLOW",doctor_alert:"EULAR/ACR 2019: ANA >= 1:80 sensitivity 98%. Multi-organ. Rheumatology referral. SLE mainly women 15-45.",source:"EULAR/ACR 2019"},
  ra:{name:"Rheumatoid Arthritis",icd:"M06.9",base_prevalence:1.0,sprt_lr:2.9,risk:"moderate",triggers:["joint_pain","morning_stiffness","joint_swelling","symmetric_joints","fatigue","joint_warmth","grip_weakness","small_joint_involvement","wrist_pain"],required_any:["joint_pain","morning_stiffness"],confirmatory:["joint_pain","morning_stiffness","symmetric_joints"],routing_if_confirmed:"YELLOW",doctor_alert:"ACR/EULAR 2010 criteria. RF + anti-CCP. Early DMARD prevents joint destruction. Rheumatology referral.",source:"ACR/EULAR 2010"},
  gout:{name:"Gout",icd:"M10",base_prevalence:3.9,sprt_lr:2.2,risk:"moderate",triggers:["joint_pain","big_toe_pain","sudden_joint_pain","red_swollen_joint","joint_warm","pain_at_night","tophi","recurrent_attacks"],required_any:["big_toe_pain","sudden_joint_pain","red_swollen_joint"],confirmatory:["big_toe_pain","sudden_joint_pain"],routing_if_confirmed:"YELLOW",doctor_alert:"Serum uric acid + joint aspiration if diagnostic uncertainty. NSAIDs or colchicine first-line. Allopurinol for prophylaxis.",source:"ACR 2020"},
  fibromyalgia:{name:"Fibromyalgia",icd:"M79.3",base_prevalence:2.0,sprt_lr:1.8,risk:"moderate",triggers:["widespread_pain","fatigue","sleep_problems","cognitive_difficulties","tender_points","headache","ibs_symptoms","depression","anxiety","pain_all_over"],required_any:["widespread_pain","fatigue","tender_points"],confirmatory:["widespread_pain","fatigue","sleep_problems"],routing_if_confirmed:"YELLOW",doctor_alert:"ACR 2010 criteria: widespread pain index ≥7 + symptom severity ≥5. Rule out inflammatory arthritis, thyroid disease. Multidisciplinary management.",source:"ACR 2016"},
  osteoporosis:{name:"Osteoporosis",icd:"M81",base_prevalence:10.0,sprt_lr:1.4,risk:"moderate",triggers:["back_pain","height_loss","fracture_low_trauma","stooped_posture","fragility_fracture","hip_pain","spine_pain"],required_any:["back_pain","height_loss","fracture_low_trauma"],confirmatory:["height_loss","fracture_low_trauma"],routing_if_confirmed:"YELLOW",doctor_alert:"DEXA scan. FRAX score. Risk: postmenopausal female, age >65, low BMI, smoking, steroids, family history. Calcium + Vit D + bisphosphonates.",source:"NOF 2023; USPSTF"},
  appendicitis:{name:"Appendicitis",icd:"K37",base_prevalence:5.3,sprt_lr:2.1,risk:"high",triggers:["abdominal_pain","right_lower_pain","nausea","vomiting","fever","pain_worsens_moving","loss_of_appetite","rebound_tenderness","pain_moves_to_right"],required_any:["abdominal_pain","right_lower_pain"],confirmatory:["right_lower_pain","nausea","fever"],routing_if_confirmed:"YELLOW",doctor_alert:"Alvarado score. Peritoneal signs = surgical emergency. WBC >10k LR+ 2.1. CT abdomen. Misdiagnosed 33% in women of childbearing age.",source:"AAFP 2008"},
  ibd:{name:"IBD (Crohn / UC)",icd:"K50",base_prevalence:0.4,sprt_lr:2.5,risk:"moderate",triggers:["chronic_diarrhea","blood_in_stool","abdominal_pain","weight_loss","fatigue","joint_pain","skin_rash","mouth_sores","night_sweats","rectal_bleeding","urgency"],required_any:["chronic_diarrhea","blood_in_stool","abdominal_pain"],confirmatory:["chronic_diarrhea","blood_in_stool","weight_loss"],routing_if_confirmed:"YELLOW",doctor_alert:"Fecal calprotectin + colonoscopy referral. Urgent if severe bleeding, toxic megacolon, or systemic deterioration.",source:"ACG IBD 2019"},
  celiac:{name:"Celiac Disease",icd:"K90.0",base_prevalence:1.0,sprt_lr:2.3,risk:"moderate",triggers:["diarrhea","bloating","weight_loss","fatigue","anemia","bone_pain","skin_rash","mouth_sores","gluten_triggered","abdominal_cramps","pale_stool"],required_any:["diarrhea","bloating","fatigue"],confirmatory:["diarrhea","weight_loss","fatigue"],routing_if_confirmed:"YELLOW",doctor_alert:"tTG-IgA serology (sensitivity 98%) — test BEFORE starting gluten-free diet. Duodenal biopsy to confirm. HLA-DQ2/DQ8.",source:"ACG Celiac 2023"},
  peptic_ulcer:{name:"Peptic Ulcer Disease",icd:"K25",base_prevalence:4.0,sprt_lr:1.6,risk:"moderate",triggers:["burning_stomach_pain","hunger_pain","pain_relieved_by_eating","nausea","vomiting","bloating","black_stool","nsaid_use","epigastric_pain"],required_any:["burning_stomach_pain","hunger_pain","epigastric_pain"],confirmatory:["burning_stomach_pain","pain_relieved_by_eating"],routing_if_confirmed:"YELLOW",doctor_alert:"H.pylori test + treat. Black/tarry stools = upper GI bleed, urgent endoscopy. Stop NSAIDs. PPI empiric.",source:"ACG 2017"},
  gerd:{name:"GERD / Acid Reflux",icd:"K21",base_prevalence:20.0,sprt_lr:1.4,risk:"low",triggers:["heartburn","acid_reflux","chest_burning","regurgitation","difficulty_swallowing","worse_lying_down","worse_after_eating","sour_taste","chronic_cough"],required_any:["heartburn","acid_reflux","chest_burning"],confirmatory:["heartburn","regurgitation","worse_lying_down"],routing_if_confirmed:"GREEN",doctor_alert:"PPI trial 4-8 weeks. Alarm symptoms (dysphagia, weight loss, bleeding) → urgent endoscopy. Barrett's esophagus surveillance if chronic.",source:"ACG GERD 2022"},
  bowel_obstruction:{name:"Bowel Obstruction",icd:"K56",base_prevalence:2.5,sprt_lr:3.2,risk:"critical",triggers:["severe_abdominal_pain","abdominal_distension","vomiting","no_bowel_movement","no_flatus","colicky_pain","nausea","vomiting_fecal"],required_any:["severe_abdominal_pain","no_bowel_movement","abdominal_distension"],confirmatory:["severe_abdominal_pain","no_bowel_movement","abdominal_distension"],routing_if_confirmed:"RED",doctor_alert:"Obstruction triad: pain + distension + obstipation. Upright AXR + CT. NPO + NGT + surgery consult. Strangulation = emergency.",source:"AAFP; StatPearls"},
  cholecystitis:{name:"Cholecystitis / Gallstones",icd:"K81",base_prevalence:3.0,sprt_lr:2.8,risk:"high",triggers:["right_upper_pain","pain_after_fatty_meal","nausea","vomiting","fever","pain_radiates_shoulder","right_shoulder_pain","jaundice","clay_stool"],required_any:["right_upper_pain","pain_after_fatty_meal"],confirmatory:["right_upper_pain","nausea","fever"],routing_if_confirmed:"YELLOW",doctor_alert:"Murphy's sign. Abdominal ultrasound. Acute cholecystitis = surgical referral. ERCP if choledocholithiasis suspected.",source:"WSES 2020"},
  pancreatitis:{name:"Acute Pancreatitis",icd:"K85",base_prevalence:0.5,sprt_lr:3.5,risk:"high",triggers:["severe_abdominal_pain","pain_radiates_back","nausea","vomiting","fever","abdominal_tenderness","worse_lying_flat","better_leaning_forward","alcohol_history"],required_any:["severe_abdominal_pain","pain_radiates_back"],confirmatory:["severe_abdominal_pain","nausea","pain_radiates_back"],routing_if_confirmed:"YELLOW",doctor_alert:"Lipase >3x ULN. CT abdomen for severity. NPO + IV fluids + analgesia. Gallstone = ERCP. Alcohol = abstinence counseling.",source:"ACG 2013"},
  ibs:{name:"Irritable Bowel Syndrome",icd:"K58",base_prevalence:11.0,sprt_lr:1.2,risk:"low",triggers:["abdominal_pain","bloating","diarrhea","constipation","alternating_bowel","pain_relieved_by_defecation","urgency","mucus_in_stool"],required_any:["abdominal_pain","bloating"],confirmatory:["abdominal_pain","alternating_bowel","pain_relieved_by_defecation"],routing_if_confirmed:"GREEN",doctor_alert:"Rome IV criteria. Exclude organic pathology (IBD, celiac, colorectal cancer). Low-FODMAP diet trial. No alarm features required for diagnosis.",source:"ACG IBS 2021"},
  copd:{name:"COPD",icd:"J44",base_prevalence:6.5,sprt_lr:2.4,risk:"moderate",triggers:["chronic_cough","progressive_breathlessness","sputum_production","wheezing","smoking_history","reduced_exercise","barrel_chest","morning_cough"],required_any:["chronic_cough","progressive_breathlessness"],confirmatory:["chronic_cough","progressive_breathlessness","smoking_history"],routing_if_confirmed:"YELLOW",doctor_alert:"Spirometry: FEV1/FVC <0.70 post-bronchodilator. GOLD staging. Smoking cessation first priority.",source:"GOLD 2024"},
  asthma:{name:"Asthma",icd:"J45",base_prevalence:8.0,sprt_lr:2.1,risk:"moderate",triggers:["wheezing","breathlessness","chest_tightness","cough","worse_at_night","exercise_triggered","allergen_triggered","variable_symptoms","seasonal_worsening"],required_any:["wheezing","breathlessness","chest_tightness"],confirmatory:["wheezing","breathlessness","exercise_triggered"],routing_if_confirmed:"YELLOW",doctor_alert:"GINA 2024: spirometry + reversibility testing. SpO2 <92% = emergency. Peak flow monitoring.",source:"GINA 2024"},
  pneumonia:{name:"Pneumonia",icd:"J18",base_prevalence:1.5,sprt_lr:3.2,risk:"high",triggers:["fever","cough","sputum","shortness_of_breath","chest_pain","fatigue","sweating","rigors","confusion_elderly"],required_any:["fever","cough","shortness_of_breath"],confirmatory:["fever","cough","shortness_of_breath"],routing_if_confirmed:"YELLOW",doctor_alert:"CURB-65 score. CXR. Blood cultures + sputum. Elderly: confusion may be only sign. Atypical: Legionella, Mycoplasma.",source:"BTS 2009; IDSA/ATS 2019"},
  depression:{name:"Major Depression",icd:"F32",base_prevalence:8.3,sprt_lr:2.0,risk:"moderate",triggers:["persistent_sadness","loss_of_interest","fatigue","sleep_changes","appetite_changes","concentration_problems","hopelessness","worthlessness","crying","social_withdrawal","suicidal_thoughts"],required_any:["persistent_sadness","loss_of_interest"],confirmatory:["persistent_sadness","loss_of_interest","fatigue"],routing_if_confirmed:"YELLOW",doctor_alert:"PHQ-9 recommended. Suicidal ideation = emergency psychiatric assessment. ≥2 weeks consistent with MDD. SSRI + therapy first-line.",source:"DSM-5-TR; APA 2023"},
  anxiety:{name:"Anxiety / Panic Disorder",icd:"F41",base_prevalence:19.1,sprt_lr:0.6,risk:"low",triggers:["racing_heart","chest_tightness","shortness_of_breath","dizziness","trembling","sweating","fear","avoidance","excessive_worry","muscle_tension","panic_attacks"],required_any:["racing_heart","chest_tightness","excessive_worry"],confirmatory:["racing_heart","chest_tightness","shortness_of_breath"],routing_if_confirmed:"GREEN",doctor_alert:"Rule out cardiac cause first (ECG). GAD-7 + PHQ-4. CBT + SSRI first-line. Panic disorder requires ruling out organic cause.",source:"NIMH 2024"},
  bipolar:{name:"Bipolar Disorder",icd:"F31",base_prevalence:2.8,sprt_lr:2.2,risk:"moderate",triggers:["mood_swings","elevated_mood","decreased_sleep","grandiosity","rapid_speech","impulsivity","depression_episodes","risky_behavior","racing_thoughts","irritability"],required_any:["mood_swings","elevated_mood","decreased_sleep"],confirmatory:["elevated_mood","decreased_sleep","rapid_speech"],routing_if_confirmed:"YELLOW",doctor_alert:"MDQ screening. Rule out substance use, thyroid, medications. Mood stabilizer (lithium/valproate). Psychiatry referral.",source:"DSM-5-TR; CANMAT 2023"},
  ptsd:{name:"PTSD",icd:"F43.1",base_prevalence:3.5,sprt_lr:2.0,risk:"moderate",triggers:["flashbacks","nightmares","avoidance","hypervigilance","emotional_numbing","sleep_problems","irritability","memory_problems","trauma_history"],required_any:["flashbacks","nightmares","avoidance","trauma_history"],confirmatory:["flashbacks","nightmares","hypervigilance"],routing_if_confirmed:"YELLOW",doctor_alert:"PCL-5 screening. Trauma-focused CBT or EMDR first-line. SSRIs (sertraline, paroxetine) FDA-approved. Assess for suicidality.",source:"VA/DoD 2023; APA"},
  ckd:{name:"Chronic Kidney Disease",icd:"N18",base_prevalence:15.0,sprt_lr:1.8,risk:"moderate",triggers:["fatigue","leg_swelling","foamy_urine","reduced_urine","back_pain","itching","nausea","loss_of_appetite","pale_skin","muscle_cramps","high_blood_pressure"],required_any:["fatigue","leg_swelling","foamy_urine"],confirmatory:["fatigue","leg_swelling","foamy_urine"],routing_if_confirmed:"YELLOW",doctor_alert:"eGFR + urine albumin-creatinine ratio. Nephrology if eGFR <30. CDC: 90% of CKD patients unaware.",source:"KDIGO 2022"},
  kidney_stones:{name:"Nephrolithiasis (Kidney Stones)",icd:"N20",base_prevalence:3.0,sprt_lr:3.5,risk:"high",triggers:["severe_flank_pain","colicky_pain","blood_in_urine","nausea","vomiting","pain_radiates_groin","urinary_urgency","painful_urination","fever"],required_any:["severe_flank_pain","colicky_pain","blood_in_urine"],confirmatory:["severe_flank_pain","colicky_pain","blood_in_urine"],routing_if_confirmed:"YELLOW",doctor_alert:"CT KUB (non-contrast) gold standard. Analgesics + IV fluids. Stones >6mm usually need urological intervention. Fever + stone = urological emergency.",source:"EAU 2022"},
  uti:{name:"Urinary Tract Infection",icd:"N39.0",base_prevalence:5.0,sprt_lr:2.1,risk:"moderate",triggers:["painful_urination","frequent_urination","urgency","cloudy_urine","blood_in_urine","lower_abdominal_pain","burning_urination","strong_urine_smell"],required_any:["painful_urination","frequent_urination","burning_urination"],confirmatory:["painful_urination","frequent_urination","urgency"],routing_if_confirmed:"YELLOW",doctor_alert:"Urine dipstick + MSU. Nitrofurantoin or trimethoprim first-line uncomplicated UTI. Pyelonephritis (fever + flank pain) = ciprofloxacin.",source:"EAU 2023; PHE"},
  pyelonephritis:{name:"Pyelonephritis",icd:"N10",base_prevalence:0.5,sprt_lr:3.2,risk:"high",triggers:["fever","flank_pain","back_pain","painful_urination","frequent_urination","nausea","vomiting","rigors","confusion"],required_any:["fever","flank_pain"],confirmatory:["fever","flank_pain","painful_urination"],routing_if_confirmed:"YELLOW",doctor_alert:"MSU + blood cultures. IV antibiotics if severe. CT if no response in 48h (rule out abscess/obstruction). Hospitalise if septic.",source:"EAU 2023"},
  nafld:{name:"Fatty Liver (NAFLD/MASLD)",icd:"K76.0",base_prevalence:25.0,sprt_lr:1.5,risk:"moderate",triggers:["fatigue","right_upper_pain","abdominal_fullness","elevated_liver_enzymes","obesity","diabetes","metabolic_syndrome","no_alcohol"],required_any:["fatigue","right_upper_pain","obesity"],confirmatory:["fatigue","obesity","diabetes"],routing_if_confirmed:"YELLOW",doctor_alert:"FIB-4 index (ADA 2025 for all T2DM). Liver ultrasound. Lifestyle modification primary treatment. NASH progression to cirrhosis risk.",source:"ADA 2025; AASLD 2023"},
  anemia:{name:"Anemia",icd:"D64.9",base_prevalence:5.6,sprt_lr:1.9,risk:"moderate",triggers:["fatigue","pale_skin","breathlessness","dizziness","cold_hands","palpitations","brittle_nails","pica","pale_gums","headache","weakness"],required_any:["fatigue","pale_skin","breathlessness"],confirmatory:["fatigue","pale_skin","dizziness"],routing_if_confirmed:"YELLOW",doctor_alert:"CBC with differential. Iron deficiency most common. Rule out GI bleed. B12/folate if macrocytic. WHO: 24.8% global prevalence.",source:"WHO 2023"},
  sleep_apnea:{name:"Obstructive Sleep Apnea",icd:"G47.3",base_prevalence:9.0,sprt_lr:1.9,risk:"moderate",triggers:["loud_snoring","witnessed_apnea","daytime_sleepiness","morning_headache","frequent_waking","obesity","large_neck","hypertension","gasping_sleep","dry_mouth"],required_any:["loud_snoring","daytime_sleepiness"],confirmatory:["loud_snoring","witnessed_apnea","daytime_sleepiness"],routing_if_confirmed:"YELLOW",doctor_alert:"STOP-BANG score. Polysomnography referral. High risk: obesity + HTN + male. Untreated OSA increases CVD risk 2-3x.",source:"AASM 2023"},
  cancer_red_flags:{name:"Cancer Red Flags",icd:"Z12",base_prevalence:0.5,sprt_lr:3.2,risk:"high",triggers:["unexplained_weight_loss","persistent_fatigue","unexplained_bleeding","persistent_cough","lump","change_in_bowel","difficulty_swallowing","night_sweats","bone_pain","blood_in_urine","blood_in_stool"],required_any:["unexplained_weight_loss","unexplained_bleeding","lump","persistent_cough"],confirmatory:["unexplained_weight_loss","persistent_fatigue"],routing_if_confirmed:"YELLOW",doctor_alert:"NICE NG12 2015 criteria. 2-week urgent cancer referral pathway. Specify symptom pattern for targeted workup.",source:"NICE NG12 2015"},
  ectopic_pregnancy:{name:"Ectopic Pregnancy",icd:"O00",base_prevalence:1.2,sprt_lr:4.5,risk:"critical",triggers:["abdominal_pain","pelvic_pain","missed_period","vaginal_bleeding","shoulder_pain","dizziness","fainting","positive_pregnancy_test"],required_any:["pelvic_pain","missed_period","vaginal_bleeding"],confirmatory:["pelvic_pain","missed_period"],routing_if_confirmed:"RED",doctor_alert:"MUST exclude in ALL females of reproductive age with abdominal/pelvic pain. Urine beta-hCG immediately. Ruptured ectopic = hemorrhagic shock.",source:"ACOG 2023"},
  sepsis:{name:"Sepsis",icd:"A41.9",base_prevalence:0.3,sprt_lr:4.9,risk:"critical",triggers:["high_fever","confusion","rapid_breathing","rapid_heart_rate","suspected_infection","extreme_fatigue","mottled_skin","not_urinating","very_cold","low_blood_pressure"],required_any:["high_fever","confusion","rapid_breathing"],confirmatory:["high_fever","rapid_heart_rate","confusion"],routing_if_confirmed:"RED",doctor_alert:"qSOFA ≥2. Sepsis-3. Hour-1 bundle: blood cultures, lactate, IV fluids, antibiotics. Mortality +7% per hour of delay.",source:"Surviving Sepsis 2021"},
  covid:{name:"COVID-19",icd:"U07.1",base_prevalence:2.0,sprt_lr:2.5,risk:"moderate",triggers:["fever","cough","shortness_of_breath","loss_of_smell","loss_of_taste","fatigue","body_aches","sore_throat","headache","diarrhea"],required_any:["fever","cough","loss_of_smell","loss_of_taste"],confirmatory:["fever","cough","loss_of_smell"],routing_if_confirmed:"YELLOW",doctor_alert:"RAT or PCR. High-risk patients (age >65, immunocompromised, comorbidities): antivirals within 5 days. Isolation guidance.",source:"WHO 2023; CDC"},
  influenza:{name:"Influenza",icd:"J11",base_prevalence:5.0,sprt_lr:2.0,risk:"low",triggers:["fever","body_aches","headache","fatigue","dry_cough","sore_throat","runny_nose","sudden_onset","chills"],required_any:["fever","body_aches","sudden_onset","sore_throat","cough","runny_nose"],confirmatory:["fever","body_aches","dry_cough"],routing_if_confirmed:"GREEN",doctor_alert:"Rapid flu test. Oseltamivir within 48h for high-risk. Annual vaccination. Secondary bacterial pneumonia risk.",source:"CDC; IDSA 2018"},
  lumbar_radiculopathy:{name:"Lumbar Disc / Radiculopathy",icd:"M54.4",base_prevalence:5.0,sprt_lr:3.0,risk:"moderate",triggers:["lower_back_pain","leg_pain","sciatica","numbness_leg","tingling_leg","weakness_leg","pain_radiates_leg","worse_sitting","better_walking","straight_leg_raise"],required_any:["lower_back_pain","leg_pain","sciatica"],confirmatory:["lower_back_pain","leg_pain","numbness_leg"],routing_if_confirmed:"YELLOW",doctor_alert:"SLR test sensitivity 80%. MRI if neurological deficit or red flags. Conservative: physio + NSAIDs. Surgery if cauda equina.",source:"NICE NG59; SPINE"},
  cauda_equina:{name:"Cauda Equina Syndrome",icd:"G83.4",base_prevalence:0.01,sprt_lr:6.0,risk:"critical",triggers:["lower_back_pain","saddle_anesthesia","bladder_dysfunction","bowel_dysfunction","bilateral_leg_weakness","sexual_dysfunction","urinary_retention","leg_numbness"],required_any:["saddle_anesthesia","bladder_dysfunction","urinary_retention"],confirmatory:["saddle_anesthesia","bladder_dysfunction","lower_back_pain"],routing_if_confirmed:"RED",doctor_alert:"SURGICAL EMERGENCY. MRI immediately. Decompression within 24-48h critical for recovery. Do not delay.",source:"NICE; BASS"},
  psoriasis:{name:"Psoriasis",icd:"L40",base_prevalence:2.0,sprt_lr:1.8,risk:"low",triggers:["red_plaques","silver_scales","itchy_skin","skin_patches","scalp_involvement","nail_changes","joint_pain","elbow_knee_rash"],required_any:["red_plaques","silver_scales","skin_patches"],confirmatory:["red_plaques","silver_scales"],routing_if_confirmed:"GREEN",doctor_alert:"PASI score. Dermatology if moderate-severe. Psoriatic arthritis in 30%: joint pain + psoriasis = rheumatology referral. Biologics for severe.",source:"BAD; AAD 2020"},
  acute_glaucoma:{name:"Acute Angle-Closure Glaucoma",icd:"H40.2",base_prevalence:0.1,sprt_lr:4.5,risk:"critical",triggers:["eye_pain","sudden_vision_loss","halos_around_lights","red_eye","headache","nausea","vomiting","blurred_vision"],required_any:["eye_pain","sudden_vision_loss","halos_around_lights"],confirmatory:["eye_pain","sudden_vision_loss","halos_around_lights"],routing_if_confirmed:"RED",doctor_alert:"Ophthalmic emergency. IOP measurement. IV acetazolamide + topical pressure-lowering drops. Ophthalmology immediately.",source:"AAO 2020"},
  head_injury:{name:"Head Injury / Concussion (mTBI)",icd:"S06.0",base_prevalence:1.2,sprt_lr:3.0,risk:"high",triggers:["head_trauma","headache","dizziness","nausea","brief_confusion","memory_gap","loss_of_consciousness","repeated_vomiting","seizure_after_injury"],required_any:["head_trauma"],confirmatory:["head_trauma","brief_confusion","memory_gap"],routing_if_confirmed:"YELLOW",doctor_alert:"Canadian CT Head Rule governs imaging. LOC, repeated vomiting, post-injury seizure, GCS drop, anticoagulant use = ED. Observe 24h for deterioration.",source:"Canadian CT Head Rule"},
  fracture_suspect:{name:"Suspected Fracture",icd:"T14.2",base_prevalence:1.5,sprt_lr:3.2,risk:"high",triggers:["injury_mechanism","deformity","unable_bear_weight","severe_swelling","heard_snap","limited_motion","open_wound","limb_numb_pale","bruising"],required_any:["injury_mechanism","deformity","heard_snap","unable_bear_weight"],confirmatory:["deformity","heard_snap","unable_bear_weight"],routing_if_confirmed:"YELLOW",doctor_alert:"Ottawa rules guide X-ray decision. Open wound over fracture site or neurovascular compromise (numb/pale/cold limb) = surgical emergency.",source:"Ottawa Rules"},
  sprain_strain:{name:"Sprain / Strain",icd:"S93.4",base_prevalence:6.0,sprt_lr:2.0,risk:"low",triggers:["injury_mechanism","joint_swelling","pain_on_movement","bruising","twisted_joint"],required_any:["injury_mechanism","twisted_joint"],confirmatory:["twisted_joint","joint_swelling"],routing_if_confirmed:"GREEN",doctor_alert:"RICE protocol. Ottawa criteria negative with partial weight-bearing supports conservative care. Re-assess at 72h if not improving.",source:"Ottawa Rules"},
  laceration:{name:"Laceration / Open Wound",icd:"S61.9",base_prevalence:2.5,sprt_lr:2.8,risk:"moderate",triggers:["open_cut","bleeding","gaping_wound","deep_cut","bleeding_uncontrolled","numb_below_cut"],required_any:["open_cut","bleeding"],confirmatory:["gaping_wound","deep_cut"],routing_if_confirmed:"YELLOW",doctor_alert:"Closure window ~6-12h (face up to 24h). Uncontrolled bleeding, tendon/nerve signs (distal numbness, loss of motion) = ED. Check tetanus status.",source:"ACEP"},
  cellulitis:{name:"Cellulitis",icd:"L03.9",base_prevalence:1.8,sprt_lr:3.5,risk:"high",triggers:["spreading_redness","warm_skin","skin_pain","skin_swelling","fever","red_streaks","chills"],required_any:["spreading_redness","warm_skin"],confirmatory:["spreading_redness","warm_skin"],routing_if_confirmed:"YELLOW",doctor_alert:"Mark borders to track spread. Fever, red streaks (lymphangitis), rapid progression or immunocompromise = IV antibiotics / ED. Rule out DVT in lower limb.",source:"IDSA 2014"},
  urticaria_allergy:{name:"Urticaria / Allergic Reaction",icd:"L50.9",base_prevalence:4.0,sprt_lr:2.2,risk:"moderate",triggers:["itchy_welts","hives","rash_after_exposure","skin_swelling","lip_face_swelling","throat_tightness","breathing_difficulty_allergy"],required_any:["itchy_welts","hives","rash_after_exposure"],confirmatory:["itchy_welts","hives"],routing_if_confirmed:"GREEN",doctor_alert:"Antihistamines first-line. ANY airway involvement (lip/tongue/throat swelling, stridor, wheeze) = anaphylaxis pathway: epinephrine + ED.",source:"WAO 2020"},
  contact_dermatitis:{name:"Contact Dermatitis / Eczema Flare",icd:"L23.9",base_prevalence:5.0,sprt_lr:1.8,risk:"low",triggers:["itchy_rash","dry_scaly_patches","rash_after_exposure","localized_redness"],required_any:["itchy_rash","localized_redness"],confirmatory:["rash_after_exposure","dry_scaly_patches"],routing_if_confirmed:"GREEN",doctor_alert:"Identify and remove trigger. Topical steroids + emollients. Weeping, honey-colored crust or fever suggests secondary infection.",source:"AAD"},
  shingles:{name:"Herpes Zoster (Shingles)",icd:"B02.9",base_prevalence:0.8,sprt_lr:5.0,risk:"high",triggers:["one_sided_band_rash","burning_pain_before_rash","blisters_cluster","skin_pain","rash_near_eye","fever"],required_any:["one_sided_band_rash","blisters_cluster"],confirmatory:["one_sided_band_rash","burning_pain_before_rash"],routing_if_confirmed:"YELLOW",doctor_alert:"Antivirals most effective <72h from rash onset. Ophthalmic involvement (rash near eye / nose tip, Hutchinson sign) is sight-threatening: urgent ophthalmology.",source:"CDC"},
  conjunctivitis:{name:"Conjunctivitis",icd:"H10.9",base_prevalence:4.5,sprt_lr:2.0,risk:"low",triggers:["red_eye","eye_discharge","gritty_feeling","itchy_eyes","crusted_lashes","watery_eyes"],required_any:["red_eye"],confirmatory:["eye_discharge","crusted_lashes"],routing_if_confirmed:"GREEN",doctor_alert:"Mostly viral and self-limited. True pain (not grit), photophobia, vision change or contact-lens wear = urgent evaluation (keratitis risk).",source:"AAO"},
  corneal_abrasion:{name:"Corneal Abrasion / Foreign Body",icd:"S05.0",base_prevalence:1.5,sprt_lr:3.0,risk:"moderate",triggers:["foreign_body_sensation","eye_pain","tearing","light_sensitivity","red_eye","pain_on_blinking"],required_any:["foreign_body_sensation","pain_on_blinking"],confirmatory:["foreign_body_sensation","pain_on_blinking"],routing_if_confirmed:"YELLOW",doctor_alert:"Fluorescein exam. Never patch contact-lens-related abrasions (pseudomonas). Retained foreign body, rust ring or penetrating mechanism = ophthalmology.",source:"AAO"},
  retinal_detachment:{name:"Retinal Detachment / Acute Vision Loss",icd:"H33.2",base_prevalence:0.1,sprt_lr:6.0,risk:"critical",triggers:["sudden_floaters","flashes_of_light","curtain_vision","painless_vision_loss","sudden_vision_loss"],required_any:["curtain_vision","sudden_vision_loss","painless_vision_loss","sudden_floaters"],confirmatory:["curtain_vision","painless_vision_loss"],routing_if_confirmed:"RED",doctor_alert:"Time-critical: macula-on detachment is a surgical emergency. Curtain/shadow, photopsia with floater shower, painless monocular loss = same-day retina service. Sudden total loss: consider CRAO (stroke pathway).",source:"AAO 2022"},
};

const TR_TRIGGER_MAP = {
  "bulantı":"nausea","mide bulantısı":"nausea","kusma":"vomiting","ateş":"fever","yorgunluk":"fatigue",
  "halsizlik":"fatigue","baş ağrısı":"severe_headache","şiddetli baş ağrısı":"severe_headache",
  "ani baş ağrısı":"sudden_headache","baş dönmesi":"dizziness","sersemlik":"dizziness","zonklayan baş ağrısı":"throbbing_headache",
  "titreme":"tremor","terleme":"sweating","gece terlemesi":"night_sweats","üşüme":"chills","titiz titreme":"rigors",
  "çarpıntı":"palpitations","kalp çarpıntısı":"palpitations","kalp atışı hızlı":"racing_heart","düzensiz kalp":"irregular_heartbeat",
  "nefes darlığı":"shortness_of_breath","nefes alamıyorum":"shortness_of_breath","nefes almakta güçlük":"breathlessness",
  "ani nefes darlığı":"sudden_breathlessness","egzersizde nefes darlığı":"exercise_triggered",
  "bacak şişliği":"leg_swelling","ayak şişliği":"leg_swelling","tek bacak şişliği":"leg_swelling_one_sided",
  "topuk şişliği":"ankle_swelling","göğüs ağrısı":"chest_pain","göğüste sıkışma":"chest_tightness",
  "göğüste baskı":"chest_pressure","sol kol ağrısı":"left_arm_pain","çene ağrısı":"jaw_pain","omuz ağrısı":"shoulder_pain",
  "sırt ağrısı":"back_pain","bel ağrısı":"lower_back_pain","boyun ağrısı":"neck_pain",
  "karın ağrısı":"abdominal_pain","karın ağrısı sağ alt":"right_lower_pain","sağ alt karın ağrısı":"right_lower_pain",
  "kasık ağrısı":"pelvic_pain","pelvik ağrı":"pelvic_pain","kasık":"pelvic_pain",
  "kilo kaybı":"weight_loss","kilo veriyorum":"weight_loss","açıklanamaz kilo kaybı":"unexplained_weight_loss",
  "kilo aldım":"weight_gain","kilo alıyorum":"weight_gain","iştah kaybı":"loss_of_appetite","iştahsızlık":"loss_of_appetite",
  "susuzluk":"thirst","çok su içiyorum":"thirst","sık idrara çıkıyorum":"frequent_urination","sık tuvalet":"frequent_urination",
  "bulanık görme":"blurred_vision","görme bozukluğu":"vision_change","ani görme kaybı":"sudden_vision_loss",
  "bir gözde görme kaybı":"vision_loss_one_eye","çift görme":"double_vision","ışık hassasiyeti":"light_sensitivity",
  "fotofobiyi":"photophobia","gözde ağrı":"eye_pain","gözde kızarıklık":"red_eye","halo görme":"halos_around_lights",
  "göz fışkırması":"eye_bulging","gözler dışarı çıkıyor":"eye_bulging",
  "boyun tutulması":"neck_stiffness","boyun sertliği":"neck_stiffness","ense sertliği":"neck_stiffness",
  "yüz felci":"facial_drooping","yüzde sarkma":"facial_drooping","ağız eğriliği":"facial_drooping",
  "kol güçsüzlüğü":"arm_weakness","konuşma güçlüğü":"speech_difficulty","slur konuşma":"speech_difficulty",
  "uyuşma":"numbness_one_side","hissizlik":"numbness_one_side","karıncalanma":"tingling","ayaklarda karıncalanma":"numbness_feet",
  "ani baş dönmesi":"dizziness_sudden","denge kaybı":"loss_of_balance","dengeyi kaybediyorum":"balance_problems",
  "nöbet":"seizure","sara nöbeti":"seizure","konvülsiyon":"convulsion","bilinç kaybı":"loss_of_consciousness",
  "boş bakma":"blank_staring","kasılma":"jerking_movements","dil ısırma":"tongue_biting","idrar kaçırma nöbet":"urinary_incontinence",
  "koku alamıyorum":"loss_of_smell","koku kaybı":"loss_of_smell","tat alamıyorum":"loss_of_taste",
  "hafıza problemi":"memory_problems","unutkanlık":"memory_problems","konsantrasyon güçlüğü":"concentration_problems",
  "yavaş hareket":"slow_movement","hareketlerim yavaşladı":"slow_movement","kas sertliği":"stiffness",
  "sürüklenerek yürüme":"shuffling_gait","küçük adımlarla yürüme":"shuffling_gait",
  "eklem ağrısı":"joint_pain","eklem şişliği":"joint_swelling","eklem kızarıklığı":"red_swollen_joint",
  "eklem ısınması":"joint_warmth","sabah tutukluğu":"morning_stiffness","simetrik eklem ağrısı":"symmetric_joints",
  "kavrama güçlüğü":"grip_weakness","el bileği ağrısı":"wrist_pain","küçük eklem ağrısı":"small_joint_involvement",
  "ayak başparmak ağrısı":"big_toe_pain","ani eklem ağrısı":"sudden_joint_pain","gece ağrısı":"pain_at_night",
  "kas ağrısı":"body_aches","yaygın ağrı":"widespread_pain","hassas noktalar":"tender_points",
  "kas güçsüzlüğü":"muscle_weakness","güçsüzlük":"muscle_weakness","kas krampı":"muscle_cramps",
  "bel fıtığı":"lumbar_radiculopathy","sinir sıkışması":"sciatica","bacağa vuran ağrı":"leg_pain","siyatik":"sciatica",
  "bacakta uyuşma":"numbness_leg","bacakta karıncalanma":"tingling_leg","bacak güçsüzlüğü":"weakness_leg",
  "oturuncak ağrı":"worse_sitting","at kuyruğu sendromu":"saddle_anesthesia","idrar yapamıyorum":"urinary_retention",
  "eyer bölgesi uyuşma":"saddle_anesthesia",
  "kelebek döküntü":"butterfly_rash","yüzde döküntü":"butterfly_rash","deri döküntüsü":"skin_rash",
  "solmayan döküntü":"rash_non_blanching","kızarık cilt":"spreading_redness","cilt sıcak":"warm_skin",
  "ciltte şişlik":"skin_swelling","geniş cilt kızarıklığı":"spreading_redness","cilt ağrısı":"skin_tenderness",
  "kırmızı yama":"red_plaques","gümüş pullar":"silver_scales","kaşıntı":"itching","cilt kaşıntısı":"itching",
  "yavaş iyileşme":"slow_healing","kolay morarma":"easy_bruising","germe çizgileri":"stretch_marks",
  "mor çizgiler":"stretch_marks","yuvarlak yüz":"round_face","yağ tümseği":"hump_back","cilt koyulaşması":"skin_darkening",
  "ishal":"diarrhea","kronik ishal":"chronic_diarrhea","dışkıda kan":"blood_in_stool","kanlı dışkı":"blood_in_stool","rektal kanama":"rectal_bleeding",
  "şişkinlik":"bloating","gaz şikayeti":"bloating","kabızlık":"constipation","dışkı yapamıyorum":"no_bowel_movement",
  "gaz çıkaramıyorum":"no_flatus","karın şişliği":"abdominal_distension","kolik ağrı":"colicky_pain",
  "mide yanması":"heartburn","mide ekşimesi":"acid_reflux","göğüste yanma":"chest_burning","regürjitasyon":"regurgitation",
  "yatınca kötüleşiyor":"worse_lying_down","yemekten sonra kötüleşiyor":"worse_after_eating","ekşi tat":"sour_taste",
  "mide ülseri":"burning_stomach_pain","aç karnına ağrı":"hunger_pain","epigastrik ağrı":"epigastric_pain",
  "yemekle geçiyor":"pain_relieved_by_eating","siyah dışkı":"black_stool","katran gibi dışkı":"black_stool",
  "yutma güçlüğü":"difficulty_swallowing","yutarken ağrı":"difficulty_swallowing",
  "sağ üst karın ağrısı":"right_upper_pain","yağlı yemek sonrası ağrı":"pain_after_fatty_meal",
  "sarılık":"jaundice","açık renkli dışkı":"clay_stool","sırta vuran karın ağrısı":"pain_radiates_back",
  "öne eğilince geçiyor":"better_leaning_forward","alkol geçmişi":"alcohol_history",
  "kanlı kusma":"vomiting","safra ile kusma":"vomiting_fecal","karın hassasiyeti":"abdominal_tenderness",
  "öksürük":"cough","kronik öksürük":"chronic_cough","kuru öksürük":"dry_cough","balgamlı öksürük":"sputum_production",
  "hırıltı":"wheezing","hırıltılı nefes":"wheezing","balgam":"sputum_production","fıçı göğüs":"barrel_chest",
  "sabah öksürüğü":"morning_cough","gece kötüleşiyor":"worse_at_night","allerjen tetikliyor":"allergen_triggered",
  "kan öksürme":"coughing_blood","kanlı balgam":"coughing_blood","yatarken nefes darlığı":"orthopnea",
  "yatınca nefes alamıyorum":"orthopnea","hızlı kilo alıyorum":"rapid_weight_gain",
  "boğaz ağrısı":"sore_throat","burun akması":"runny_nose","ani başlangıç":"sudden_onset",
  "köpüklü idrar":"foamy_urine","az idrar":"reduced_urine","idrarda kan":"blood_in_urine","kanlı idrar":"blood_in_urine",
  "yanmalı işeme":"burning_urination","ağrılı işeme":"painful_urination","sık tuvalet ihtiyacı":"urgency",
  "idrar bulanık":"cloudy_urine","idrar kokusu":"strong_urine_smell","alt karın ağrısı":"lower_abdominal_pain",
  "böğür ağrısı":"flank_pain","yan ağrısı":"flank_pain","şiddetli yan ağrısı":"severe_flank_pain",
  "kasığa vuran ağrı":"pain_radiates_groin",
  "kalpte hızlanma":"racing_heart","kalp hızlanması":"racing_heart","taşikardi":"tachycardia",
  "düzensiz nabız":"irregular_heartbeat","egzersiz intoleransı":"reduced_exercise",
  "düşük tansiyon":"low_blood_pressure","yüksek tansiyon":"high_blood_pressure","nabız farkı":"difference_in_arm_pulses",
  "çok ani şiddetli göğüs ağrısı":"sudden_severe_chest_pain","yırtılır gibi ağrı":"tearing_pain",
  "sırta vuran ağrı":"pain_radiation_back","soğuk terleme":"cold_sweat","bayılma hissi":"dizziness",
  "çarpıntı ve nefes darlığı":"palpitations","bacak ağrısı":"leg_pain","baldır ağrısı":"calf_pain",
  "bacak sıcaklığı":"leg_warmth","bacak kızarıklığı":"leg_redness","bacak hassasiyeti":"tenderness",
  "depresyon":"persistent_sadness","üzüntü":"persistent_sadness","mutsuzluk":"persistent_sadness",
  "ilgi kaybı":"loss_of_interest","zevk alamıyorum":"loss_of_interest","umutsuzluk":"hopelessness",
  "değersizlik hissi":"worthlessness","ağlama":"crying","sosyal çekilme":"social_withdrawal",
  "uyku değişikliği":"sleep_changes","insomnia":"insomnia","çok uyuyorum":"sleep_changes",
  "iştah değişikliği":"appetite_changes","intihar düşüncesi":"suicidal_thoughts",
  "endişe":"excessive_worry","panik":"panic_attacks","aşırı endişe":"excessive_worry","korku":"fear",
  "kas gerginliği":"muscle_tension","ani yükselen mod":"elevated_mood",
  "uyku azaldı":"decreased_sleep","grandiözite":"grandiosity","hızlı konuşma":"rapid_speech",
  "impulsivite":"impulsivity","riskli davranış":"risky_behavior","hızlı düşünceler":"racing_thoughts",
  "sinirlilik":"irritability","mod değişimi":"mood_swings","travma geçmişi":"trauma_history",
  "flashback":"flashbacks","kaçınma":"avoidance","aşırı uyanıklık":"hypervigilance","duygusal uyuşma":"emotional_numbing",
  "saç dökülmesi":"hair_loss","kuru cilt":"dry_skin","yavaş nabız":"slow_heart_rate",
  "ses kalınlaştı":"hoarse_voice","soğuğa dayanamıyorum":"cold_intolerance","sıcağa dayanamıyorum":"heat_intolerance",
  "tuz isteği":"salt_craving","akne":"acne","tüylenme fazlalığı":"excess_hair","adet düzensizliği":"irregular_periods",
  "adet gecikmesi":"missed_period","düzensiz adet":"irregular_periods","gebelenemiyorum":"difficulty_conceiving",
  "yağlı cilt":"oily_skin","şişik yüz":"puffy_face","kırılgan tırnak":"brittle_nails",
  "yüksek ateş":"high_fever","konfüzyon":"confusion","bilinç bulanıklığı":"confusion",
  "hızlı nefes":"rapid_breathing","hızlı kalp":"rapid_heart_rate","idrar yapamıyorum":"not_urinating",
  "aşırı soğukluk":"very_cold","aşırı yorgunluk":"extreme_fatigue","benekli cilt":"mottled_skin",
  "şüpheli enfeksiyon":"suspected_infection","ense tutulması":"neck_stiffness",
  "vajinal kanama":"vaginal_bleeding","gebelik testi pozitif":"positive_pregnancy_test",
  "hamile olabilirim":"missed_period",
  "horlama":"loud_snoring","gündüz uykusu":"daytime_sleepiness","sabah baş ağrısı":"morning_headache",
  "gece nefes durması":"witnessed_apnea","sık uyanma":"frequent_waking","ağız kuruluğu":"dry_mouth",
  "büyük boyun":"large_neck","soluk kesilme":"witnessed_apnea",
  "açıklanamaz yorgunluk":"persistent_fatigue","açıklanamaz kanama":"unexplained_bleeding",
  "kitle":"lump","şişlik":"lump","bağırsak değişikliği":"change_in_bowel","kemik ağrısı":"bone_pain",
  "soluk deri":"pale_skin","solgun":"pale_skin","soğuk eller":"cold_hands","çabuk yorulma":"fatigue",
  "nefes nefese kalma":"breathlessness","pika":"pica","diş eti solukluğu":"pale_gums",
  "daha önce kırık":"fracture_low_trauma","uzunluk kaybı":"height_loss","kamburlaşma":"stooped_posture",
  "stres kırığı":"fragility_fracture","kalça ağrısı":"hip_pain","omurga ağrısı":"spine_pain",
  "dizi dirsek döküntü":"elbow_knee_rash","saç derisi tutulumu":"scalp_involvement","tırnak değişimi":"nail_changes",
  "psoriazis":"red_plaques","sedef":"red_plaques","eklem ağrısı ile döküntü":"joint_pain",
  "ağız yaraları":"mouth_sores","güneş hassasiyeti":"sun_sensitivity","böbrek şikayeti":"kidney_symptoms",
  "sık enfeksiyon":"frequent_infections","cilt koyulaşması":"dark_skin_patches","mantar":"recurrent_thrush",
  "mantar tekrarlıyor":"recurrent_thrush","turuncu idrar":"blood_in_urine",
};

const COLLOQUIAL_MAP = {
  "kalbim sıkışıyor":"chest_tightness","baskı hissediyorum":"chest_pressure",
  "nefesim kesiliyor":"shortness_of_breath","ciğerlerim yanıyor":"chest_pain",
  "başım zonkluyor":"throbbing_headache","kafam zonkluyor":"throbbing_headache",
  "gözlerim kararıyor":"dizziness","yıldızlar görüyorum":"dizziness",
  "içim bulanıyor":"nausea","midem bulanıyor":"nausea",
  "dünya dönüyor":"dizziness","ayakta duramıyorum":"balance_problems",
  "ellerim uyuşuyor":"numbness_one_side","ayaklarım uyuşuyor":"numbness_feet",
  "soluğum daralıyor":"shortness_of_breath","nefes almakta zorlanıyorum":"shortness_of_breath",
  "kalbim atlıyor":"palpitations","kalbim hızlı atıyor":"racing_heart",
  "uyuyamıyorum":"insomnia","geceleri uyanıyorum":"sleep_changes",
  "her şey tuhaf geliyor":"confusion","aklım karışıyor":"confusion",
  "kaslarım tutuldu":"muscle_weakness","kollarım tutuyor":"grip_weakness",
  "kemiklerim ağrıyor":"body_aches","tüm vücudum ağrıyor":"widespread_pain",
  "tight chest":"chest_tightness","heart racing":"racing_heart","heart pounding":"palpitations",
  "can't breathe":"shortness_of_breath","short of breath":"shortness_of_breath",
  "head spinning":"dizziness","room spinning":"dizziness","feel faint":"dizziness",
  "stomach turning":"nausea","feel sick":"nausea","throwing up":"vomiting",
  "legs giving out":"weakness_leg","hands shaking":"tremor","body shaking":"tremor",
  "everything blurry":"blurred_vision","seeing double":"double_vision",
  "can't think straight":"concentration_problems","brain fog":"memory_problems",
  "pins and needles":"tingling","numb all over":"numbness_one_side",
};

function normalizeTR(text) {
  return text
    .toLowerCase()
    .replace(/ğ/g,"g").replace(/ü/g,"u").replace(/ş/g,"s")
    .replace(/ı/g,"i").replace(/ö/g,"o").replace(/ç/g,"c");
}

function matchPatterns(st, riskMods) {
  let normalized = st.toLowerCase();
  let englishSt = normalized;

  const colloquialKeys = Object.keys(COLLOQUIAL_MAP).sort((a,b)=>b.length-a.length);
  for (const phrase of colloquialKeys) {
    const normPhrase = normalizeTR(phrase);
    if (normalizeTR(normalized).includes(normPhrase)) {
      englishSt += " " + COLLOQUIAL_MAP[phrase];
    }
  }

  const sortedKeys = Object.keys(TR_TRIGGER_MAP).sort((a,b)=>b.length-a.length);
  for (const tr of sortedKeys) {
    if (normalizeTR(normalized).includes(normalizeTR(tr))) {
      englishSt += " " + TR_TRIGGER_MAP[tr];
    }
  }

  const words = englishSt.toLowerCase().split(/[\s,;.!?_]+/).filter(Boolean);

  const results = [];
  for (const [key,pat] of Object.entries(PATTERNS)) {
    const triggerHits = pat.triggers.filter(t => {
      const tParts = t.split("_");
      return words.some(w =>
        tParts.some(tp =>
          tp === w ||
          (w.length > 4 && tp.length > 4 && (w === tp || w.startsWith(tp) || tp.startsWith(w)))
        )
      );
    }).length;
    const requiredMet = pat.required_any.some(r => {
      const rParts = r.split("_");
      return words.some(w =>
        rParts.some(rp =>
          rp === w ||
          (w.length > 4 && rp.length > 4 && (w === rp || w.startsWith(rp) || rp.startsWith(w)))
        )
      );
    });
    const confirmatoryMet = pat.confirmatory.length > 0 && pat.confirmatory.every(c => {
      const cParts = c.split("_");
      return words.some(w =>
        cParts.some(cp =>
          cp === w ||
          (w.length > 4 && cp.length > 4 && (w === cp || w.startsWith(cp) || cp.startsWith(w)))
        )
      );
    });
    if (!requiredMet || triggerHits < 2) continue;
    const profileMod = riskMods?.[key] ?? 1.0;
    const score = triggerHits * 10 + (confirmatoryMet ? 30 : 0) + Math.log(profileMod + 0.1) * 5;
    results.push({...pat, key, score, confirmatoryMet, triggerHits, profileMod});
  }
  return results.sort((a,b) => b.score - a.score).slice(0, 6);
}

const ALL_TRIGGERS = new Set(Object.values(PATTERNS).flatMap(p => p.triggers || []));
const DANGER_TRIGGERS = ["jaundice","clay_stool","fever","tachycardia","shortness_of_breath","vomiting","fruity_breath","rapid_onset","abdominal_pain","low_blood_pressure","dizziness","rebound_tenderness","chest_pain","coughing_blood","loss_of_consciousness","repeated_vomiting","open_wound","limb_numb_pale","bleeding_uncontrolled","red_streaks","rash_near_eye","throat_tightness","lip_face_swelling","curtain_vision","sudden_vision_loss"];

function buildSystemPrompt(lang, symptomText, profile, matches, followUpHistory, docSummary) {
  const vocab = [...new Set([...matches.flatMap(m => m.triggers || []), ...DANGER_TRIGGERS])].join(", ");
  const langName = lang==="tr"?"Turkish":"English";
  const profileStr = profile?[profile.age&&`Age: ${profile.age}`,profile.sex&&`Sex: ${profile.sex}`,profile.bmi&&`BMI: ${profile.bmi.toFixed(1)}`,profile.smoking&&"Current smoker",profile.diabetes&&"Known diabetes",profile.hypertension&&"Known hypertension",profile.familyHistory&&"Family history"].filter(Boolean).join(", "):"Not collected";
  const matchStr = matches.length>0?matches.map(m=>`${m.name} [ICD ${m.icd}]: ${m.triggerHits} hits, confirmatory: ${m.confirmatoryMet}, profileMod: ${m.profileMod.toFixed(2)}, LR: ${m.sprt_lr}, routing: ${m.routing_if_confirmed}`).join("\n"):"None";
  const fuStr = followUpHistory.length>0?followUpHistory.slice(-6).map(f=>`Q: ${f.q}  A: ${f.a}`).join("\n"):"None";
  const docStr = docSummary ? `\nMEDICAL DOCUMENTS ON FILE:\n${docSummary}\n` : "";
  return `You are SHC (Standard HealthCare), a clinical triage system. CRITICAL: ALL your output text must be in ${langName}. Never switch languages.

PATIENT PROFILE: ${profileStr}
SYMPTOMS: "${symptomText}"
PATTERN MATCHES:\n${matchStr}
FOLLOW-UPS SO FAR:\n${fuStr}${docStr}

TASK:
1. Use pattern matches and profile multipliers to build differential.
2. Ask ONE focused follow-up question unless you have enough for routing.
3. If medical documents are on file, use them to refine your assessment. You may ask the patient to upload relevant documents (lab results, MRI, etc.) if they would meaningfully change your routing.
4. When sufficient info exists, give routing with doctor alert.
5. Tone: calm, direct. Never say "I understand your concern."
6. IMPORTANT: All condition names in "differentials" MUST be in ${langName}. All text fields must be in ${langName}.

SYMPTOM EXTRACTION — the on-device SPRT engine makes the final routing decision; your task is structured extraction, never the decision:
  In "symptoms", report every finding the patient has AFFIRMED or explicitly DENIED across the entire conversation so far (cumulative), mapped to these ids:
  In "confidence", give your calibrated probability of PRESENCE (0.0-1.0) for any id you are NOT fully certain about — ambiguous mentions ("a strange feeling in my chest") belong at 0.4-0.7. Omit ids you are certain of; certainty is assumed at 1.0. The engine integrates these as soft evidence, so honest uncertainty here makes the routing safer.
  ${vocab}
  "present" = affirmed by the patient. "absent" = explicitly denied. Never infer absence from silence. Only use ids from the list.
  Your "routing" and "lambda" fields are ADVISORY — a second opinion shown to the physician. The deterministic engine computes the actual routing from your extracted symptoms and may override you.

ROUTING (advisory only): RED | YELLOW | GREEN | GREY if abstention.boundary=true

MANDATORY SAFETY ESCALATIONS (override the score — these are emergencies a kiosk cannot rule out):
- Head injury + (loss of consciousness | repeated vomiting | post-injury seizure) => routing RED.
- Suspected fracture + (open wound over site | numb/pale/cold limb) => routing RED (open fracture / neurovascular compromise).
- Bleeding that does not stop with direct pressure => routing RED.
- Allergic reaction + any airway sign (throat tightness, lip/tongue swelling, wheeze) => routing RED (anaphylaxis).
- Shingles rash near the eye or nose tip => routing RED (sight-threatening zoster).
- Cellulitis + (fever | red streaks) => routing RED (systemic spread / lymphangitis).
- Sudden vision loss or a curtain over vision => routing RED.
- Cholecystitis / biliary picture (ICD K81) WITH jaundice or pale/clay-colored stool → RED (possible biliary obstruction or ascending cholangitis, Charcot triad; untreated cholangitis is rapidly fatal).
- Acute pancreatitis (ICD K85) WITH any systemic inflammatory sign (fever, tachycardia, breathlessness, low blood pressure / SIRS) → RED (risk of severe acute pancreatitis).
- Type 1 diabetes (ICD E10) WITH DKA features (fruity/acetone breath, or vomiting with rapid onset or abdominal pain) → RED (diabetic ketoacidosis is life-threatening).
- Adrenal insufficiency / Addison's (ICD E27.1) WITH low blood pressure, or vomiting plus dizziness → RED (adrenal crisis / shock).
- Appendicitis (ICD K37) WITH rebound tenderness or peritoneal signs → RED (perforation/peritonitis, surgical emergency).
- Kidney stones (ICD N20) WITH fever → RED (infected obstructed stone / urosepsis).
- DVT (ICD I80.2) WITH breathlessness, chest pain, or coughing up blood → RED (pulmonary embolism).

Respond ONLY in this exact JSON (no markdown fences). Every text field MUST be in ${langName}:
{
  "text": "Reply in ${langName}. 2-3 sentences.",
  "phase": "collecting|decision",
  "differentials": [{"name": "Condition name in ${langName}", "icd": "ICD-10 code", "pct": 75, "risk": "critical|high|moderate|low", "source": "guideline"}],
  "symptoms": {"present": ["trigger_id"], "absent": ["trigger_id"], "confidence": {"trigger_id": 0.0}},
  "routing": null or "RED|YELLOW|GREEN",
  "lambda": null or number,
  "urgency": null or "action string in ${langName}",
  "doctor_alert": null or "doctor note in ${langName}",
  "abstention": {"boundary": false, "multiple": false, "unusual": false}
}`;
}



// ═══════════════════ QR (gömülü qrcode-generator, internet yok) ═══════════════════
// Kanıtlanmış kompakt encoder. Tüm veri QR'ın İÇİNDE — sunucu/link yok.
// Kaynak: qrcode-generator (MIT), byte-mode + ECC-M. Telefon kamerası okur.
/* qrcode-generator v2.0.4 (MIT, Kazuhiko Arase) — gömülü, internet yok */
var qrcode = function() {

  //---------------------------------------------------------------------
  // qrcode
  //---------------------------------------------------------------------

  /**
   * qrcode
   * @param typeNumber 1 to 40
   * @param errorCorrectionLevel 'L','M','Q','H'
   */
  var qrcode = function(typeNumber, errorCorrectionLevel) {

    var PAD0 = 0xEC;
    var PAD1 = 0x11;

    var _typeNumber = typeNumber;
    var _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];
    var _modules = null;
    var _moduleCount = 0;
    var _dataCache = null;
    var _dataList = [];

    var _this = {};

    var makeImpl = function(test, maskPattern) {

      _moduleCount = _typeNumber * 4 + 17;
      _modules = function(moduleCount) {
        var modules = new Array(moduleCount);
        for (var row = 0; row < moduleCount; row += 1) {
          modules[row] = new Array(moduleCount);
          for (var col = 0; col < moduleCount; col += 1) {
            modules[row][col] = null;
          }
        }
        return modules;
      }(_moduleCount);

      setupPositionProbePattern(0, 0);
      setupPositionProbePattern(_moduleCount - 7, 0);
      setupPositionProbePattern(0, _moduleCount - 7);
      setupPositionAdjustPattern();
      setupTimingPattern();
      setupTypeInfo(test, maskPattern);

      if (_typeNumber >= 7) {
        setupTypeNumber(test);
      }

      if (_dataCache == null) {
        _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
      }

      mapData(_dataCache, maskPattern);
    };

    var setupPositionProbePattern = function(row, col) {

      for (var r = -1; r <= 7; r += 1) {

        if (row + r <= -1 || _moduleCount <= row + r) continue;

        for (var c = -1; c <= 7; c += 1) {

          if (col + c <= -1 || _moduleCount <= col + c) continue;

          if ( (0 <= r && r <= 6 && (c == 0 || c == 6) )
              || (0 <= c && c <= 6 && (r == 0 || r == 6) )
              || (2 <= r && r <= 4 && 2 <= c && c <= 4) ) {
            _modules[row + r][col + c] = true;
          } else {
            _modules[row + r][col + c] = false;
          }
        }
      }
    };

    var getBestMaskPattern = function() {

      var minLostPoint = 0;
      var pattern = 0;

      for (var i = 0; i < 8; i += 1) {

        makeImpl(true, i);

        var lostPoint = QRUtil.getLostPoint(_this);

        if (i == 0 || minLostPoint > lostPoint) {
          minLostPoint = lostPoint;
          pattern = i;
        }
      }

      return pattern;
    };

    var setupTimingPattern = function() {

      for (var r = 8; r < _moduleCount - 8; r += 1) {
        if (_modules[r][6] != null) {
          continue;
        }
        _modules[r][6] = (r % 2 == 0);
      }

      for (var c = 8; c < _moduleCount - 8; c += 1) {
        if (_modules[6][c] != null) {
          continue;
        }
        _modules[6][c] = (c % 2 == 0);
      }
    };

    var setupPositionAdjustPattern = function() {

      var pos = QRUtil.getPatternPosition(_typeNumber);

      for (var i = 0; i < pos.length; i += 1) {

        for (var j = 0; j < pos.length; j += 1) {

          var row = pos[i];
          var col = pos[j];

          if (_modules[row][col] != null) {
            continue;
          }

          for (var r = -2; r <= 2; r += 1) {

            for (var c = -2; c <= 2; c += 1) {

              if (r == -2 || r == 2 || c == -2 || c == 2
                  || (r == 0 && c == 0) ) {
                _modules[row + r][col + c] = true;
              } else {
                _modules[row + r][col + c] = false;
              }
            }
          }
        }
      }
    };

    var setupTypeNumber = function(test) {

      var bits = QRUtil.getBCHTypeNumber(_typeNumber);

      for (var i = 0; i < 18; i += 1) {
        var mod = (!test && ( (bits >> i) & 1) == 1);
        _modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;
      }

      for (var i = 0; i < 18; i += 1) {
        var mod = (!test && ( (bits >> i) & 1) == 1);
        _modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
      }
    };

    var setupTypeInfo = function(test, maskPattern) {

      var data = (_errorCorrectionLevel << 3) | maskPattern;
      var bits = QRUtil.getBCHTypeInfo(data);

      // vertical
      for (var i = 0; i < 15; i += 1) {

        var mod = (!test && ( (bits >> i) & 1) == 1);

        if (i < 6) {
          _modules[i][8] = mod;
        } else if (i < 8) {
          _modules[i + 1][8] = mod;
        } else {
          _modules[_moduleCount - 15 + i][8] = mod;
        }
      }

      // horizontal
      for (var i = 0; i < 15; i += 1) {

        var mod = (!test && ( (bits >> i) & 1) == 1);

        if (i < 8) {
          _modules[8][_moduleCount - i - 1] = mod;
        } else if (i < 9) {
          _modules[8][15 - i - 1 + 1] = mod;
        } else {
          _modules[8][15 - i - 1] = mod;
        }
      }

      // fixed module
      _modules[_moduleCount - 8][8] = (!test);
    };

    var mapData = function(data, maskPattern) {

      var inc = -1;
      var row = _moduleCount - 1;
      var bitIndex = 7;
      var byteIndex = 0;
      var maskFunc = QRUtil.getMaskFunction(maskPattern);

      for (var col = _moduleCount - 1; col > 0; col -= 2) {

        if (col == 6) col -= 1;

        while (true) {

          for (var c = 0; c < 2; c += 1) {

            if (_modules[row][col - c] == null) {

              var dark = false;

              if (byteIndex < data.length) {
                dark = ( ( (data[byteIndex] >>> bitIndex) & 1) == 1);
              }

              var mask = maskFunc(row, col - c);

              if (mask) {
                dark = !dark;
              }

              _modules[row][col - c] = dark;
              bitIndex -= 1;

              if (bitIndex == -1) {
                byteIndex += 1;
                bitIndex = 7;
              }
            }
          }

          row += inc;

          if (row < 0 || _moduleCount <= row) {
            row -= inc;
            inc = -inc;
            break;
          }
        }
      }
    };

    var createBytes = function(buffer, rsBlocks) {

      var offset = 0;

      var maxDcCount = 0;
      var maxEcCount = 0;

      var dcdata = new Array(rsBlocks.length);
      var ecdata = new Array(rsBlocks.length);

      for (var r = 0; r < rsBlocks.length; r += 1) {

        var dcCount = rsBlocks[r].dataCount;
        var ecCount = rsBlocks[r].totalCount - dcCount;

        maxDcCount = Math.max(maxDcCount, dcCount);
        maxEcCount = Math.max(maxEcCount, ecCount);

        dcdata[r] = new Array(dcCount);

        for (var i = 0; i < dcdata[r].length; i += 1) {
          dcdata[r][i] = 0xff & buffer.getBuffer()[i + offset];
        }
        offset += dcCount;

        var rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
        var rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);

        var modPoly = rawPoly.mod(rsPoly);
        ecdata[r] = new Array(rsPoly.getLength() - 1);
        for (var i = 0; i < ecdata[r].length; i += 1) {
          var modIndex = i + modPoly.getLength() - ecdata[r].length;
          ecdata[r][i] = (modIndex >= 0)? modPoly.getAt(modIndex) : 0;
        }
      }

      var totalCodeCount = 0;
      for (var i = 0; i < rsBlocks.length; i += 1) {
        totalCodeCount += rsBlocks[i].totalCount;
      }

      var data = new Array(totalCodeCount);
      var index = 0;

      for (var i = 0; i < maxDcCount; i += 1) {
        for (var r = 0; r < rsBlocks.length; r += 1) {
          if (i < dcdata[r].length) {
            data[index] = dcdata[r][i];
            index += 1;
          }
        }
      }

      for (var i = 0; i < maxEcCount; i += 1) {
        for (var r = 0; r < rsBlocks.length; r += 1) {
          if (i < ecdata[r].length) {
            data[index] = ecdata[r][i];
            index += 1;
          }
        }
      }

      return data;
    };

    var createData = function(typeNumber, errorCorrectionLevel, dataList) {

      var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, errorCorrectionLevel);

      var buffer = qrBitBuffer();

      for (var i = 0; i < dataList.length; i += 1) {
        var data = dataList[i];
        buffer.put(data.getMode(), 4);
        buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
        data.write(buffer);
      }

      // calc num max data.
      var totalDataCount = 0;
      for (var i = 0; i < rsBlocks.length; i += 1) {
        totalDataCount += rsBlocks[i].dataCount;
      }

      if (buffer.getLengthInBits() > totalDataCount * 8) {
        throw 'code length overflow. ('
          + buffer.getLengthInBits()
          + '>'
          + totalDataCount * 8
          + ')';
      }

      // end code
      if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
        buffer.put(0, 4);
      }

      // padding
      while (buffer.getLengthInBits() % 8 != 0) {
        buffer.putBit(false);
      }

      // padding
      while (true) {

        if (buffer.getLengthInBits() >= totalDataCount * 8) {
          break;
        }
        buffer.put(PAD0, 8);

        if (buffer.getLengthInBits() >= totalDataCount * 8) {
          break;
        }
        buffer.put(PAD1, 8);
      }

      return createBytes(buffer, rsBlocks);
    };

    _this.addData = function(data, mode) {

      mode = mode || 'Byte';

      var newData = null;

      switch(mode) {
      case 'Numeric' :
        newData = qrNumber(data);
        break;
      case 'Alphanumeric' :
        newData = qrAlphaNum(data);
        break;
      case 'Byte' :
        newData = qr8BitByte(data);
        break;
      case 'Kanji' :
        newData = qrKanji(data);
        break;
      default :
        throw 'mode:' + mode;
      }

      _dataList.push(newData);
      _dataCache = null;
    };

    _this.isDark = function(row, col) {
      if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) {
        throw row + ',' + col;
      }
      return _modules[row][col];
    };

    _this.getModuleCount = function() {
      return _moduleCount;
    };

    _this.make = function() {
      if (_typeNumber < 1) {
        var typeNumber = 1;

        for (; typeNumber < 40; typeNumber++) {
          var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, _errorCorrectionLevel);
          var buffer = qrBitBuffer();

          for (var i = 0; i < _dataList.length; i++) {
            var data = _dataList[i];
            buffer.put(data.getMode(), 4);
            buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
            data.write(buffer);
          }

          var totalDataCount = 0;
          for (var i = 0; i < rsBlocks.length; i++) {
            totalDataCount += rsBlocks[i].dataCount;
          }

          if (buffer.getLengthInBits() <= totalDataCount * 8) {
            break;
          }
        }

        _typeNumber = typeNumber;
      }

      makeImpl(false, getBestMaskPattern() );
    };

    _this.createTableTag = function(cellSize, margin) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var qrHtml = '';

      qrHtml += '<table style="';
      qrHtml += ' border-width: 0px; border-style: none;';
      qrHtml += ' border-collapse: collapse;';
      qrHtml += ' padding: 0px; margin: ' + margin + 'px;';
      qrHtml += '">';
      qrHtml += '<tbody>';

      for (var r = 0; r < _this.getModuleCount(); r += 1) {

        qrHtml += '<tr>';

        for (var c = 0; c < _this.getModuleCount(); c += 1) {
          qrHtml += '<td style="';
          qrHtml += ' border-width: 0px; border-style: none;';
          qrHtml += ' border-collapse: collapse;';
          qrHtml += ' padding: 0px; margin: 0px;';
          qrHtml += ' width: ' + cellSize + 'px;';
          qrHtml += ' height: ' + cellSize + 'px;';
          qrHtml += ' background-color: ';
          qrHtml += _this.isDark(r, c)? '#000000' : '#ffffff';
          qrHtml += ';';
          qrHtml += '"/>';
        }

        qrHtml += '</tr>';
      }

      qrHtml += '</tbody>';
      qrHtml += '</table>';

      return qrHtml;
    };

    _this.createSvgTag = function(cellSize, margin, alt, title) {

      var opts = {};
      if (typeof arguments[0] == 'object') {
        // Called by options.
        opts = arguments[0];
        // overwrite cellSize and margin.
        cellSize = opts.cellSize;
        margin = opts.margin;
        alt = opts.alt;
        title = opts.title;
      }

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      // Compose alt property surrogate
      alt = (typeof alt === 'string') ? {text: alt} : alt || {};
      alt.text = alt.text || null;
      alt.id = (alt.text) ? alt.id || 'qrcode-description' : null;

      // Compose title property surrogate
      title = (typeof title === 'string') ? {text: title} : title || {};
      title.text = title.text || null;
      title.id = (title.text) ? title.id || 'qrcode-title' : null;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var c, mc, r, mr, qrSvg='', rect;

      rect = 'l' + cellSize + ',0 0,' + cellSize +
        ' -' + cellSize + ',0 0,-' + cellSize + 'z ';

      qrSvg += '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"';
      qrSvg += !opts.scalable ? ' width="' + size + 'px" height="' + size + 'px"' : '';
      qrSvg += ' viewBox="0 0 ' + size + ' ' + size + '" ';
      qrSvg += ' preserveAspectRatio="xMinYMin meet"';
      qrSvg += (title.text || alt.text) ? ' role="img" aria-labelledby="' +
          escapeXml([title.id, alt.id].join(' ').trim() ) + '"' : '';
      qrSvg += '>';
      qrSvg += (title.text) ? '<title id="' + escapeXml(title.id) + '">' +
          escapeXml(title.text) + '</title>' : '';
      qrSvg += (alt.text) ? '<description id="' + escapeXml(alt.id) + '">' +
          escapeXml(alt.text) + '</description>' : '';
      qrSvg += '<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>';
      qrSvg += '<path d="';

      for (r = 0; r < _this.getModuleCount(); r += 1) {
        mr = r * cellSize + margin;
        for (c = 0; c < _this.getModuleCount(); c += 1) {
          if (_this.isDark(r, c) ) {
            mc = c*cellSize+margin;
            qrSvg += 'M' + mc + ',' + mr + rect;
          }
        }
      }

      qrSvg += '" stroke="transparent" fill="black"/>';
      qrSvg += '</svg>';

      return qrSvg;
    };

    _this.createDataURL = function(cellSize, margin) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      return createDataURL(size, size, function(x, y) {
        if (min <= x && x < max && min <= y && y < max) {
          var c = Math.floor( (x - min) / cellSize);
          var r = Math.floor( (y - min) / cellSize);
          return _this.isDark(r, c)? 0 : 1;
        } else {
          return 1;
        }
      } );
    };

    _this.createImgTag = function(cellSize, margin, alt) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;

      var img = '';
      img += '<img';
      img += '\u0020src="';
      img += _this.createDataURL(cellSize, margin);
      img += '"';
      img += '\u0020width="';
      img += size;
      img += '"';
      img += '\u0020height="';
      img += size;
      img += '"';
      if (alt) {
        img += '\u0020alt="';
        img += escapeXml(alt);
        img += '"';
      }
      img += '/>';

      return img;
    };

    var escapeXml = function(s) {
      var escaped = '';
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charAt(i);
        switch(c) {
        case '<': escaped += '&lt;'; break;
        case '>': escaped += '&gt;'; break;
        case '&': escaped += '&amp;'; break;
        case '"': escaped += '&quot;'; break;
        default : escaped += c; break;
        }
      }
      return escaped;
    };

    var _createHalfASCII = function(margin) {
      var cellSize = 1;
      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      var y, x, r1, r2, p;

      var blocks = {
        '██': '█',
        '█ ': '▀',
        ' █': '▄',
        '  ': ' '
      };

      var blocksLastLineNoMargin = {
        '██': '▀',
        '█ ': '▀',
        ' █': ' ',
        '  ': ' '
      };

      var ascii = '';
      for (y = 0; y < size; y += 2) {
        r1 = Math.floor((y - min) / cellSize);
        r2 = Math.floor((y + 1 - min) / cellSize);
        for (x = 0; x < size; x += 1) {
          p = '█';

          if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) {
            p = ' ';
          }

          if (min <= x && x < max && min <= y+1 && y+1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) {
            p += ' ';
          }
          else {
            p += '█';
          }

          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.
          ascii += (margin < 1 && y+1 >= max) ? blocksLastLineNoMargin[p] : blocks[p];
        }

        ascii += '\n';
      }

      if (size % 2 && margin > 0) {
        return ascii.substring(0, ascii.length - size - 1) + Array(size+1).join('▀');
      }

      return ascii.substring(0, ascii.length-1);
    };

    _this.createASCII = function(cellSize, margin) {
      cellSize = cellSize || 1;

      if (cellSize < 2) {
        return _createHalfASCII(margin);
      }

      cellSize -= 1;
      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      var y, x, r, p;

      var white = Array(cellSize+1).join('██');
      var black = Array(cellSize+1).join('  ');

      var ascii = '';
      var line = '';
      for (y = 0; y < size; y += 1) {
        r = Math.floor( (y - min) / cellSize);
        line = '';
        for (x = 0; x < size; x += 1) {
          p = 1;

          if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cellSize))) {
            p = 0;
          }

          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.
          line += p ? white : black;
        }

        for (r = 0; r < cellSize; r += 1) {
          ascii += line + '\n';
        }
      }

      return ascii.substring(0, ascii.length-1);
    };

    _this.renderTo2dContext = function(context, cellSize) {
      cellSize = cellSize || 2;
      var length = _this.getModuleCount();
      for (var row = 0; row < length; row++) {
        for (var col = 0; col < length; col++) {
          context.fillStyle = _this.isDark(row, col) ? 'black' : 'white';
          context.fillRect(col * cellSize, row * cellSize, cellSize, cellSize);
        }
      }
    }

    return _this;
  };

  //---------------------------------------------------------------------
  // qrcode.stringToBytes
  //---------------------------------------------------------------------

  qrcode.stringToBytesFuncs = {
    'default' : function(s) {
      var bytes = [];
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charCodeAt(i);
        bytes.push(c & 0xff);
      }
      return bytes;
    }
  };

  qrcode.stringToBytes = qrcode.stringToBytesFuncs['default'];

  //---------------------------------------------------------------------
  // qrcode.createStringToBytes
  //---------------------------------------------------------------------

  /**
   * @param unicodeData base64 string of byte array.
   * [16bit Unicode],[16bit Bytes], ...
   * @param numChars
   */
  qrcode.createStringToBytes = function(unicodeData, numChars) {

    // create conversion map.

    var unicodeMap = function() {

      var bin = base64DecodeInputStream(unicodeData);
      var read = function() {
        var b = bin.read();
        if (b == -1) throw 'eof';
        return b;
      };

      var count = 0;
      var unicodeMap = {};
      while (true) {
        var b0 = bin.read();
        if (b0 == -1) break;
        var b1 = read();
        var b2 = read();
        var b3 = read();
        var k = String.fromCharCode( (b0 << 8) | b1);
        var v = (b2 << 8) | b3;
        unicodeMap[k] = v;
        count += 1;
      }
      if (count != numChars) {
        throw count + ' != ' + numChars;
      }

      return unicodeMap;
    }();

    var unknownChar = '?'.charCodeAt(0);

    return function(s) {
      var bytes = [];
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charCodeAt(i);
        if (c < 128) {
          bytes.push(c);
        } else {
          var b = unicodeMap[s.charAt(i)];
          if (typeof b == 'number') {
            if ( (b & 0xff) == b) {
              // 1byte
              bytes.push(b);
            } else {
              // 2bytes
              bytes.push(b >>> 8);
              bytes.push(b & 0xff);
            }
          } else {
            bytes.push(unknownChar);
          }
        }
      }
      return bytes;
    };
  };

  //---------------------------------------------------------------------
  // QRMode
  //---------------------------------------------------------------------

  var QRMode = {
    MODE_NUMBER :    1 << 0,
    MODE_ALPHA_NUM : 1 << 1,
    MODE_8BIT_BYTE : 1 << 2,
    MODE_KANJI :     1 << 3
  };

  //---------------------------------------------------------------------
  // QRErrorCorrectionLevel
  //---------------------------------------------------------------------

  var QRErrorCorrectionLevel = {
    L : 1,
    M : 0,
    Q : 3,
    H : 2
  };

  //---------------------------------------------------------------------
  // QRMaskPattern
  //---------------------------------------------------------------------

  var QRMaskPattern = {
    PATTERN000 : 0,
    PATTERN001 : 1,
    PATTERN010 : 2,
    PATTERN011 : 3,
    PATTERN100 : 4,
    PATTERN101 : 5,
    PATTERN110 : 6,
    PATTERN111 : 7
  };

  //---------------------------------------------------------------------
  // QRUtil
  //---------------------------------------------------------------------

  var QRUtil = function() {

    var PATTERN_POSITION_TABLE = [
      [],
      [6, 18],
      [6, 22],
      [6, 26],
      [6, 30],
      [6, 34],
      [6, 22, 38],
      [6, 24, 42],
      [6, 26, 46],
      [6, 28, 50],
      [6, 30, 54],
      [6, 32, 58],
      [6, 34, 62],
      [6, 26, 46, 66],
      [6, 26, 48, 70],
      [6, 26, 50, 74],
      [6, 30, 54, 78],
      [6, 30, 56, 82],
      [6, 30, 58, 86],
      [6, 34, 62, 90],
      [6, 28, 50, 72, 94],
      [6, 26, 50, 74, 98],
      [6, 30, 54, 78, 102],
      [6, 28, 54, 80, 106],
      [6, 32, 58, 84, 110],
      [6, 30, 58, 86, 114],
      [6, 34, 62, 90, 118],
      [6, 26, 50, 74, 98, 122],
      [6, 30, 54, 78, 102, 126],
      [6, 26, 52, 78, 104, 130],
      [6, 30, 56, 82, 108, 134],
      [6, 34, 60, 86, 112, 138],
      [6, 30, 58, 86, 114, 142],
      [6, 34, 62, 90, 118, 146],
      [6, 30, 54, 78, 102, 126, 150],
      [6, 24, 50, 76, 102, 128, 154],
      [6, 28, 54, 80, 106, 132, 158],
      [6, 32, 58, 84, 110, 136, 162],
      [6, 26, 54, 82, 110, 138, 166],
      [6, 30, 58, 86, 114, 142, 170]
    ];
    var G15 = (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | (1 << 0);
    var G18 = (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | (1 << 0);
    var G15_MASK = (1 << 14) | (1 << 12) | (1 << 10) | (1 << 4) | (1 << 1);

    var _this = {};

    var getBCHDigit = function(data) {
      var digit = 0;
      while (data != 0) {
        digit += 1;
        data >>>= 1;
      }
      return digit;
    };

    _this.getBCHTypeInfo = function(data) {
      var d = data << 10;
      while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {
        d ^= (G15 << (getBCHDigit(d) - getBCHDigit(G15) ) );
      }
      return ( (data << 10) | d) ^ G15_MASK;
    };

    _this.getBCHTypeNumber = function(data) {
      var d = data << 12;
      while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {
        d ^= (G18 << (getBCHDigit(d) - getBCHDigit(G18) ) );
      }
      return (data << 12) | d;
    };

    _this.getPatternPosition = function(typeNumber) {
      return PATTERN_POSITION_TABLE[typeNumber - 1];
    };

    _this.getMaskFunction = function(maskPattern) {

      switch (maskPattern) {

      case QRMaskPattern.PATTERN000 :
        return function(i, j) { return (i + j) % 2 == 0; };
      case QRMaskPattern.PATTERN001 :
        return function(i, j) { return i % 2 == 0; };
      case QRMaskPattern.PATTERN010 :
        return function(i, j) { return j % 3 == 0; };
      case QRMaskPattern.PATTERN011 :
        return function(i, j) { return (i + j) % 3 == 0; };
      case QRMaskPattern.PATTERN100 :
        return function(i, j) { return (Math.floor(i / 2) + Math.floor(j / 3) ) % 2 == 0; };
      case QRMaskPattern.PATTERN101 :
        return function(i, j) { return (i * j) % 2 + (i * j) % 3 == 0; };
      case QRMaskPattern.PATTERN110 :
        return function(i, j) { return ( (i * j) % 2 + (i * j) % 3) % 2 == 0; };
      case QRMaskPattern.PATTERN111 :
        return function(i, j) { return ( (i * j) % 3 + (i + j) % 2) % 2 == 0; };

      default :
        throw 'bad maskPattern:' + maskPattern;
      }
    };

    _this.getErrorCorrectPolynomial = function(errorCorrectLength) {
      var a = qrPolynomial([1], 0);
      for (var i = 0; i < errorCorrectLength; i += 1) {
        a = a.multiply(qrPolynomial([1, QRMath.gexp(i)], 0) );
      }
      return a;
    };

    _this.getLengthInBits = function(mode, type) {

      if (1 <= type && type < 10) {

        // 1 - 9

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 10;
        case QRMode.MODE_ALPHA_NUM : return 9;
        case QRMode.MODE_8BIT_BYTE : return 8;
        case QRMode.MODE_KANJI     : return 8;
        default :
          throw 'mode:' + mode;
        }

      } else if (type < 27) {

        // 10 - 26

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 12;
        case QRMode.MODE_ALPHA_NUM : return 11;
        case QRMode.MODE_8BIT_BYTE : return 16;
        case QRMode.MODE_KANJI     : return 10;
        default :
          throw 'mode:' + mode;
        }

      } else if (type < 41) {

        // 27 - 40

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 14;
        case QRMode.MODE_ALPHA_NUM : return 13;
        case QRMode.MODE_8BIT_BYTE : return 16;
        case QRMode.MODE_KANJI     : return 12;
        default :
          throw 'mode:' + mode;
        }

      } else {
        throw 'type:' + type;
      }
    };

    _this.getLostPoint = function(qrcode) {

      var moduleCount = qrcode.getModuleCount();

      var lostPoint = 0;

      // LEVEL1

      for (var row = 0; row < moduleCount; row += 1) {
        for (var col = 0; col < moduleCount; col += 1) {

          var sameCount = 0;
          var dark = qrcode.isDark(row, col);

          for (var r = -1; r <= 1; r += 1) {

            if (row + r < 0 || moduleCount <= row + r) {
              continue;
            }

            for (var c = -1; c <= 1; c += 1) {

              if (col + c < 0 || moduleCount <= col + c) {
                continue;
              }

              if (r == 0 && c == 0) {
                continue;
              }

              if (dark == qrcode.isDark(row + r, col + c) ) {
                sameCount += 1;
              }
            }
          }

          if (sameCount > 5) {
            lostPoint += (3 + sameCount - 5);
          }
        }
      };

      // LEVEL2

      for (var row = 0; row < moduleCount - 1; row += 1) {
        for (var col = 0; col < moduleCount - 1; col += 1) {
          var count = 0;
          if (qrcode.isDark(row, col) ) count += 1;
          if (qrcode.isDark(row + 1, col) ) count += 1;
          if (qrcode.isDark(row, col + 1) ) count += 1;
          if (qrcode.isDark(row + 1, col + 1) ) count += 1;
          if (count == 0 || count == 4) {
            lostPoint += 3;
          }
        }
      }

      // LEVEL3

      for (var row = 0; row < moduleCount; row += 1) {
        for (var col = 0; col < moduleCount - 6; col += 1) {
          if (qrcode.isDark(row, col)
              && !qrcode.isDark(row, col + 1)
              &&  qrcode.isDark(row, col + 2)
              &&  qrcode.isDark(row, col + 3)
              &&  qrcode.isDark(row, col + 4)
              && !qrcode.isDark(row, col + 5)
              &&  qrcode.isDark(row, col + 6) ) {
            lostPoint += 40;
          }
        }
      }

      for (var col = 0; col < moduleCount; col += 1) {
        for (var row = 0; row < moduleCount - 6; row += 1) {
          if (qrcode.isDark(row, col)
              && !qrcode.isDark(row + 1, col)
              &&  qrcode.isDark(row + 2, col)
              &&  qrcode.isDark(row + 3, col)
              &&  qrcode.isDark(row + 4, col)
              && !qrcode.isDark(row + 5, col)
              &&  qrcode.isDark(row + 6, col) ) {
            lostPoint += 40;
          }
        }
      }

      // LEVEL4

      var darkCount = 0;

      for (var col = 0; col < moduleCount; col += 1) {
        for (var row = 0; row < moduleCount; row += 1) {
          if (qrcode.isDark(row, col) ) {
            darkCount += 1;
          }
        }
      }

      var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
      lostPoint += ratio * 10;

      return lostPoint;
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // QRMath
  //---------------------------------------------------------------------

  var QRMath = function() {

    var EXP_TABLE = new Array(256);
    var LOG_TABLE = new Array(256);

    // initialize tables
    for (var i = 0; i < 8; i += 1) {
      EXP_TABLE[i] = 1 << i;
    }
    for (var i = 8; i < 256; i += 1) {
      EXP_TABLE[i] = EXP_TABLE[i - 4]
        ^ EXP_TABLE[i - 5]
        ^ EXP_TABLE[i - 6]
        ^ EXP_TABLE[i - 8];
    }
    for (var i = 0; i < 255; i += 1) {
      LOG_TABLE[EXP_TABLE[i] ] = i;
    }

    var _this = {};

    _this.glog = function(n) {

      if (n < 1) {
        throw 'glog(' + n + ')';
      }

      return LOG_TABLE[n];
    };

    _this.gexp = function(n) {

      while (n < 0) {
        n += 255;
      }

      while (n >= 256) {
        n -= 255;
      }

      return EXP_TABLE[n];
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // qrPolynomial
  //---------------------------------------------------------------------

  function qrPolynomial(num, shift) {

    if (typeof num.length == 'undefined') {
      throw num.length + '/' + shift;
    }

    var _num = function() {
      var offset = 0;
      while (offset < num.length && num[offset] == 0) {
        offset += 1;
      }
      var _num = new Array(num.length - offset + shift);
      for (var i = 0; i < num.length - offset; i += 1) {
        _num[i] = num[i + offset];
      }
      return _num;
    }();

    var _this = {};

    _this.getAt = function(index) {
      return _num[index];
    };

    _this.getLength = function() {
      return _num.length;
    };

    _this.multiply = function(e) {

      var num = new Array(_this.getLength() + e.getLength() - 1);

      for (var i = 0; i < _this.getLength(); i += 1) {
        for (var j = 0; j < e.getLength(); j += 1) {
          num[i + j] ^= QRMath.gexp(QRMath.glog(_this.getAt(i) ) + QRMath.glog(e.getAt(j) ) );
        }
      }

      return qrPolynomial(num, 0);
    };

    _this.mod = function(e) {

      if (_this.getLength() - e.getLength() < 0) {
        return _this;
      }

      var ratio = QRMath.glog(_this.getAt(0) ) - QRMath.glog(e.getAt(0) );

      var num = new Array(_this.getLength() );
      for (var i = 0; i < _this.getLength(); i += 1) {
        num[i] = _this.getAt(i);
      }

      for (var i = 0; i < e.getLength(); i += 1) {
        num[i] ^= QRMath.gexp(QRMath.glog(e.getAt(i) ) + ratio);
      }

      // recursive call
      return qrPolynomial(num, 0).mod(e);
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // QRRSBlock
  //---------------------------------------------------------------------

  var QRRSBlock = function() {

    var RS_BLOCK_TABLE = [

      // L
      // M
      // Q
      // H

      // 1
      [1, 26, 19],
      [1, 26, 16],
      [1, 26, 13],
      [1, 26, 9],

      // 2
      [1, 44, 34],
      [1, 44, 28],
      [1, 44, 22],
      [1, 44, 16],

      // 3
      [1, 70, 55],
      [1, 70, 44],
      [2, 35, 17],
      [2, 35, 13],

      // 4
      [1, 100, 80],
      [2, 50, 32],
      [2, 50, 24],
      [4, 25, 9],

      // 5
      [1, 134, 108],
      [2, 67, 43],
      [2, 33, 15, 2, 34, 16],
      [2, 33, 11, 2, 34, 12],

      // 6
      [2, 86, 68],
      [4, 43, 27],
      [4, 43, 19],
      [4, 43, 15],

      // 7
      [2, 98, 78],
      [4, 49, 31],
      [2, 32, 14, 4, 33, 15],
      [4, 39, 13, 1, 40, 14],

      // 8
      [2, 121, 97],
      [2, 60, 38, 2, 61, 39],
      [4, 40, 18, 2, 41, 19],
      [4, 40, 14, 2, 41, 15],

      // 9
      [2, 146, 116],
      [3, 58, 36, 2, 59, 37],
      [4, 36, 16, 4, 37, 17],
      [4, 36, 12, 4, 37, 13],

      // 10
      [2, 86, 68, 2, 87, 69],
      [4, 69, 43, 1, 70, 44],
      [6, 43, 19, 2, 44, 20],
      [6, 43, 15, 2, 44, 16],

      // 11
      [4, 101, 81],
      [1, 80, 50, 4, 81, 51],
      [4, 50, 22, 4, 51, 23],
      [3, 36, 12, 8, 37, 13],

      // 12
      [2, 116, 92, 2, 117, 93],
      [6, 58, 36, 2, 59, 37],
      [4, 46, 20, 6, 47, 21],
      [7, 42, 14, 4, 43, 15],

      // 13
      [4, 133, 107],
      [8, 59, 37, 1, 60, 38],
      [8, 44, 20, 4, 45, 21],
      [12, 33, 11, 4, 34, 12],

      // 14
      [3, 145, 115, 1, 146, 116],
      [4, 64, 40, 5, 65, 41],
      [11, 36, 16, 5, 37, 17],
      [11, 36, 12, 5, 37, 13],

      // 15
      [5, 109, 87, 1, 110, 88],
      [5, 65, 41, 5, 66, 42],
      [5, 54, 24, 7, 55, 25],
      [11, 36, 12, 7, 37, 13],

      // 16
      [5, 122, 98, 1, 123, 99],
      [7, 73, 45, 3, 74, 46],
      [15, 43, 19, 2, 44, 20],
      [3, 45, 15, 13, 46, 16],

      // 17
      [1, 135, 107, 5, 136, 108],
      [10, 74, 46, 1, 75, 47],
      [1, 50, 22, 15, 51, 23],
      [2, 42, 14, 17, 43, 15],

      // 18
      [5, 150, 120, 1, 151, 121],
      [9, 69, 43, 4, 70, 44],
      [17, 50, 22, 1, 51, 23],
      [2, 42, 14, 19, 43, 15],

      // 19
      [3, 141, 113, 4, 142, 114],
      [3, 70, 44, 11, 71, 45],
      [17, 47, 21, 4, 48, 22],
      [9, 39, 13, 16, 40, 14],

      // 20
      [3, 135, 107, 5, 136, 108],
      [3, 67, 41, 13, 68, 42],
      [15, 54, 24, 5, 55, 25],
      [15, 43, 15, 10, 44, 16],

      // 21
      [4, 144, 116, 4, 145, 117],
      [17, 68, 42],
      [17, 50, 22, 6, 51, 23],
      [19, 46, 16, 6, 47, 17],

      // 22
      [2, 139, 111, 7, 140, 112],
      [17, 74, 46],
      [7, 54, 24, 16, 55, 25],
      [34, 37, 13],

      // 23
      [4, 151, 121, 5, 152, 122],
      [4, 75, 47, 14, 76, 48],
      [11, 54, 24, 14, 55, 25],
      [16, 45, 15, 14, 46, 16],

      // 24
      [6, 147, 117, 4, 148, 118],
      [6, 73, 45, 14, 74, 46],
      [11, 54, 24, 16, 55, 25],
      [30, 46, 16, 2, 47, 17],

      // 25
      [8, 132, 106, 4, 133, 107],
      [8, 75, 47, 13, 76, 48],
      [7, 54, 24, 22, 55, 25],
      [22, 45, 15, 13, 46, 16],

      // 26
      [10, 142, 114, 2, 143, 115],
      [19, 74, 46, 4, 75, 47],
      [28, 50, 22, 6, 51, 23],
      [33, 46, 16, 4, 47, 17],

      // 27
      [8, 152, 122, 4, 153, 123],
      [22, 73, 45, 3, 74, 46],
      [8, 53, 23, 26, 54, 24],
      [12, 45, 15, 28, 46, 16],

      // 28
      [3, 147, 117, 10, 148, 118],
      [3, 73, 45, 23, 74, 46],
      [4, 54, 24, 31, 55, 25],
      [11, 45, 15, 31, 46, 16],

      // 29
      [7, 146, 116, 7, 147, 117],
      [21, 73, 45, 7, 74, 46],
      [1, 53, 23, 37, 54, 24],
      [19, 45, 15, 26, 46, 16],

      // 30
      [5, 145, 115, 10, 146, 116],
      [19, 75, 47, 10, 76, 48],
      [15, 54, 24, 25, 55, 25],
      [23, 45, 15, 25, 46, 16],

      // 31
      [13, 145, 115, 3, 146, 116],
      [2, 74, 46, 29, 75, 47],
      [42, 54, 24, 1, 55, 25],
      [23, 45, 15, 28, 46, 16],

      // 32
      [17, 145, 115],
      [10, 74, 46, 23, 75, 47],
      [10, 54, 24, 35, 55, 25],
      [19, 45, 15, 35, 46, 16],

      // 33
      [17, 145, 115, 1, 146, 116],
      [14, 74, 46, 21, 75, 47],
      [29, 54, 24, 19, 55, 25],
      [11, 45, 15, 46, 46, 16],

      // 34
      [13, 145, 115, 6, 146, 116],
      [14, 74, 46, 23, 75, 47],
      [44, 54, 24, 7, 55, 25],
      [59, 46, 16, 1, 47, 17],

      // 35
      [12, 151, 121, 7, 152, 122],
      [12, 75, 47, 26, 76, 48],
      [39, 54, 24, 14, 55, 25],
      [22, 45, 15, 41, 46, 16],

      // 36
      [6, 151, 121, 14, 152, 122],
      [6, 75, 47, 34, 76, 48],
      [46, 54, 24, 10, 55, 25],
      [2, 45, 15, 64, 46, 16],

      // 37
      [17, 152, 122, 4, 153, 123],
      [29, 74, 46, 14, 75, 47],
      [49, 54, 24, 10, 55, 25],
      [24, 45, 15, 46, 46, 16],

      // 38
      [4, 152, 122, 18, 153, 123],
      [13, 74, 46, 32, 75, 47],
      [48, 54, 24, 14, 55, 25],
      [42, 45, 15, 32, 46, 16],

      // 39
      [20, 147, 117, 4, 148, 118],
      [40, 75, 47, 7, 76, 48],
      [43, 54, 24, 22, 55, 25],
      [10, 45, 15, 67, 46, 16],

      // 40
      [19, 148, 118, 6, 149, 119],
      [18, 75, 47, 31, 76, 48],
      [34, 54, 24, 34, 55, 25],
      [20, 45, 15, 61, 46, 16]
    ];

    var qrRSBlock = function(totalCount, dataCount) {
      var _this = {};
      _this.totalCount = totalCount;
      _this.dataCount = dataCount;
      return _this;
    };

    var _this = {};

    var getRsBlockTable = function(typeNumber, errorCorrectionLevel) {

      switch(errorCorrectionLevel) {
      case QRErrorCorrectionLevel.L :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
      case QRErrorCorrectionLevel.M :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
      case QRErrorCorrectionLevel.Q :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
      case QRErrorCorrectionLevel.H :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
      default :
        return undefined;
      }
    };

    _this.getRSBlocks = function(typeNumber, errorCorrectionLevel) {

      var rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);

      if (typeof rsBlock == 'undefined') {
        throw 'bad rs block @ typeNumber:' + typeNumber +
            '/errorCorrectionLevel:' + errorCorrectionLevel;
      }

      var length = rsBlock.length / 3;

      var list = [];

      for (var i = 0; i < length; i += 1) {

        var count = rsBlock[i * 3 + 0];
        var totalCount = rsBlock[i * 3 + 1];
        var dataCount = rsBlock[i * 3 + 2];

        for (var j = 0; j < count; j += 1) {
          list.push(qrRSBlock(totalCount, dataCount) );
        }
      }

      return list;
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // qrBitBuffer
  //---------------------------------------------------------------------

  var qrBitBuffer = function() {

    var _buffer = [];
    var _length = 0;

    var _this = {};

    _this.getBuffer = function() {
      return _buffer;
    };

    _this.getAt = function(index) {
      var bufIndex = Math.floor(index / 8);
      return ( (_buffer[bufIndex] >>> (7 - index % 8) ) & 1) == 1;
    };

    _this.put = function(num, length) {
      for (var i = 0; i < length; i += 1) {
        _this.putBit( ( (num >>> (length - i - 1) ) & 1) == 1);
      }
    };

    _this.getLengthInBits = function() {
      return _length;
    };

    _this.putBit = function(bit) {

      var bufIndex = Math.floor(_length / 8);
      if (_buffer.length <= bufIndex) {
        _buffer.push(0);
      }

      if (bit) {
        _buffer[bufIndex] |= (0x80 >>> (_length % 8) );
      }

      _length += 1;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrNumber
  //---------------------------------------------------------------------

  var qrNumber = function(data) {

    var _mode = QRMode.MODE_NUMBER;
    var _data = data;

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _data.length;
    };

    _this.write = function(buffer) {

      var data = _data;

      var i = 0;

      while (i + 2 < data.length) {
        buffer.put(strToNum(data.substring(i, i + 3) ), 10);
        i += 3;
      }

      if (i < data.length) {
        if (data.length - i == 1) {
          buffer.put(strToNum(data.substring(i, i + 1) ), 4);
        } else if (data.length - i == 2) {
          buffer.put(strToNum(data.substring(i, i + 2) ), 7);
        }
      }
    };

    var strToNum = function(s) {
      var num = 0;
      for (var i = 0; i < s.length; i += 1) {
        num = num * 10 + chatToNum(s.charAt(i) );
      }
      return num;
    };

    var chatToNum = function(c) {
      if ('0' <= c && c <= '9') {
        return c.charCodeAt(0) - '0'.charCodeAt(0);
      }
      throw 'illegal char :' + c;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrAlphaNum
  //---------------------------------------------------------------------

  var qrAlphaNum = function(data) {

    var _mode = QRMode.MODE_ALPHA_NUM;
    var _data = data;

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _data.length;
    };

    _this.write = function(buffer) {

      var s = _data;

      var i = 0;

      while (i + 1 < s.length) {
        buffer.put(
          getCode(s.charAt(i) ) * 45 +
          getCode(s.charAt(i + 1) ), 11);
        i += 2;
      }

      if (i < s.length) {
        buffer.put(getCode(s.charAt(i) ), 6);
      }
    };

    var getCode = function(c) {

      if ('0' <= c && c <= '9') {
        return c.charCodeAt(0) - '0'.charCodeAt(0);
      } else if ('A' <= c && c <= 'Z') {
        return c.charCodeAt(0) - 'A'.charCodeAt(0) + 10;
      } else {
        switch (c) {
        case ' ' : return 36;
        case '$' : return 37;
        case '%' : return 38;
        case '*' : return 39;
        case '+' : return 40;
        case '-' : return 41;
        case '.' : return 42;
        case '/' : return 43;
        case ':' : return 44;
        default :
          throw 'illegal char :' + c;
        }
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qr8BitByte
  //---------------------------------------------------------------------

  var qr8BitByte = function(data) {

    var _mode = QRMode.MODE_8BIT_BYTE;
    var _data = data;
    var _bytes = qrcode.stringToBytes(data);

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _bytes.length;
    };

    _this.write = function(buffer) {
      for (var i = 0; i < _bytes.length; i += 1) {
        buffer.put(_bytes[i], 8);
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrKanji
  //---------------------------------------------------------------------

  var qrKanji = function(data) {

    var _mode = QRMode.MODE_KANJI;
    var _data = data;

    var stringToBytes = qrcode.stringToBytesFuncs['SJIS'];
    if (!stringToBytes) {
      throw 'sjis not supported.';
    }
    !function(c, code) {
      // self test for sjis support.
      var test = stringToBytes(c);
      if (test.length != 2 || ( (test[0] << 8) | test[1]) != code) {
        throw 'sjis not supported.';
      }
    }('\u53cb', 0x9746);

    var _bytes = stringToBytes(data);

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return ~~(_bytes.length / 2);
    };

    _this.write = function(buffer) {

      var data = _bytes;

      var i = 0;

      while (i + 1 < data.length) {

        var c = ( (0xff & data[i]) << 8) | (0xff & data[i + 1]);

        if (0x8140 <= c && c <= 0x9FFC) {
          c -= 0x8140;
        } else if (0xE040 <= c && c <= 0xEBBF) {
          c -= 0xC140;
        } else {
          throw 'illegal char at ' + (i + 1) + '/' + c;
        }

        c = ( (c >>> 8) & 0xff) * 0xC0 + (c & 0xff);

        buffer.put(c, 13);

        i += 2;
      }

      if (i < data.length) {
        throw 'illegal char at ' + (i + 1);
      }
    };

    return _this;
  };

  //=====================================================================
  // GIF Support etc.
  //

  //---------------------------------------------------------------------
  // byteArrayOutputStream
  //---------------------------------------------------------------------

  var byteArrayOutputStream = function() {

    var _bytes = [];

    var _this = {};

    _this.writeByte = function(b) {
      _bytes.push(b & 0xff);
    };

    _this.writeShort = function(i) {
      _this.writeByte(i);
      _this.writeByte(i >>> 8);
    };

    _this.writeBytes = function(b, off, len) {
      off = off || 0;
      len = len || b.length;
      for (var i = 0; i < len; i += 1) {
        _this.writeByte(b[i + off]);
      }
    };

    _this.writeString = function(s) {
      for (var i = 0; i < s.length; i += 1) {
        _this.writeByte(s.charCodeAt(i) );
      }
    };

    _this.toByteArray = function() {
      return _bytes;
    };

    _this.toString = function() {
      var s = '';
      s += '[';
      for (var i = 0; i < _bytes.length; i += 1) {
        if (i > 0) {
          s += ',';
        }
        s += _bytes[i];
      }
      s += ']';
      return s;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // base64EncodeOutputStream
  //---------------------------------------------------------------------

  var base64EncodeOutputStream = function() {

    var _buffer = 0;
    var _buflen = 0;
    var _length = 0;
    var _base64 = '';

    var _this = {};

    var writeEncoded = function(b) {
      _base64 += String.fromCharCode(encode(b & 0x3f) );
    };

    var encode = function(n) {
      if (n < 0) {
        // error.
      } else if (n < 26) {
        return 0x41 + n;
      } else if (n < 52) {
        return 0x61 + (n - 26);
      } else if (n < 62) {
        return 0x30 + (n - 52);
      } else if (n == 62) {
        return 0x2b;
      } else if (n == 63) {
        return 0x2f;
      }
      throw 'n:' + n;
    };

    _this.writeByte = function(n) {

      _buffer = (_buffer << 8) | (n & 0xff);
      _buflen += 8;
      _length += 1;

      while (_buflen >= 6) {
        writeEncoded(_buffer >>> (_buflen - 6) );
        _buflen -= 6;
      }
    };

    _this.flush = function() {

      if (_buflen > 0) {
        writeEncoded(_buffer << (6 - _buflen) );
        _buffer = 0;
        _buflen = 0;
      }

      if (_length % 3 != 0) {
        // padding
        var padlen = 3 - _length % 3;
        for (var i = 0; i < padlen; i += 1) {
          _base64 += '=';
        }
      }
    };

    _this.toString = function() {
      return _base64;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // base64DecodeInputStream
  //---------------------------------------------------------------------

  var base64DecodeInputStream = function(str) {

    var _str = str;
    var _pos = 0;
    var _buffer = 0;
    var _buflen = 0;

    var _this = {};

    _this.read = function() {

      while (_buflen < 8) {

        if (_pos >= _str.length) {
          if (_buflen == 0) {
            return -1;
          }
          throw 'unexpected end of file./' + _buflen;
        }

        var c = _str.charAt(_pos);
        _pos += 1;

        if (c == '=') {
          _buflen = 0;
          return -1;
        } else if (c.match(/^\s$/) ) {
          // ignore if whitespace.
          continue;
        }

        _buffer = (_buffer << 6) | decode(c.charCodeAt(0) );
        _buflen += 6;
      }

      var n = (_buffer >>> (_buflen - 8) ) & 0xff;
      _buflen -= 8;
      return n;
    };

    var decode = function(c) {
      if (0x41 <= c && c <= 0x5a) {
        return c - 0x41;
      } else if (0x61 <= c && c <= 0x7a) {
        return c - 0x61 + 26;
      } else if (0x30 <= c && c <= 0x39) {
        return c - 0x30 + 52;
      } else if (c == 0x2b) {
        return 62;
      } else if (c == 0x2f) {
        return 63;
      } else {
        throw 'c:' + c;
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // gifImage (B/W)
  //---------------------------------------------------------------------

  var gifImage = function(width, height) {

    var _width = width;
    var _height = height;
    var _data = new Array(width * height);

    var _this = {};

    _this.setPixel = function(x, y, pixel) {
      _data[y * _width + x] = pixel;
    };

    _this.write = function(out) {

      //---------------------------------
      // GIF Signature

      out.writeString('GIF87a');

      //---------------------------------
      // Screen Descriptor

      out.writeShort(_width);
      out.writeShort(_height);

      out.writeByte(0x80); // 2bit
      out.writeByte(0);
      out.writeByte(0);

      //---------------------------------
      // Global Color Map

      // black
      out.writeByte(0x00);
      out.writeByte(0x00);
      out.writeByte(0x00);

      // white
      out.writeByte(0xff);
      out.writeByte(0xff);
      out.writeByte(0xff);

      //---------------------------------
      // Image Descriptor

      out.writeString(',');
      out.writeShort(0);
      out.writeShort(0);
      out.writeShort(_width);
      out.writeShort(_height);
      out.writeByte(0);

      //---------------------------------
      // Local Color Map

      //---------------------------------
      // Raster Data

      var lzwMinCodeSize = 2;
      var raster = getLZWRaster(lzwMinCodeSize);

      out.writeByte(lzwMinCodeSize);

      var offset = 0;

      while (raster.length - offset > 255) {
        out.writeByte(255);
        out.writeBytes(raster, offset, 255);
        offset += 255;
      }

      out.writeByte(raster.length - offset);
      out.writeBytes(raster, offset, raster.length - offset);
      out.writeByte(0x00);

      //---------------------------------
      // GIF Terminator
      out.writeString(';');
    };

    var bitOutputStream = function(out) {

      var _out = out;
      var _bitLength = 0;
      var _bitBuffer = 0;

      var _this = {};

      _this.write = function(data, length) {

        if ( (data >>> length) != 0) {
          throw 'length over';
        }

        while (_bitLength + length >= 8) {
          _out.writeByte(0xff & ( (data << _bitLength) | _bitBuffer) );
          length -= (8 - _bitLength);
          data >>>= (8 - _bitLength);
          _bitBuffer = 0;
          _bitLength = 0;
        }

        _bitBuffer = (data << _bitLength) | _bitBuffer;
        _bitLength = _bitLength + length;
      };

      _this.flush = function() {
        if (_bitLength > 0) {
          _out.writeByte(_bitBuffer);
        }
      };

      return _this;
    };

    var getLZWRaster = function(lzwMinCodeSize) {

      var clearCode = 1 << lzwMinCodeSize;
      var endCode = (1 << lzwMinCodeSize) + 1;
      var bitLength = lzwMinCodeSize + 1;

      // Setup LZWTable
      var table = lzwTable();

      for (var i = 0; i < clearCode; i += 1) {
        table.add(String.fromCharCode(i) );
      }
      table.add(String.fromCharCode(clearCode) );
      table.add(String.fromCharCode(endCode) );

      var byteOut = byteArrayOutputStream();
      var bitOut = bitOutputStream(byteOut);

      // clear code
      bitOut.write(clearCode, bitLength);

      var dataIndex = 0;

      var s = String.fromCharCode(_data[dataIndex]);
      dataIndex += 1;

      while (dataIndex < _data.length) {

        var c = String.fromCharCode(_data[dataIndex]);
        dataIndex += 1;

        if (table.contains(s + c) ) {

          s = s + c;

        } else {

          bitOut.write(table.indexOf(s), bitLength);

          if (table.size() < 0xfff) {

            if (table.size() == (1 << bitLength) ) {
              bitLength += 1;
            }

            table.add(s + c);
          }

          s = c;
        }
      }

      bitOut.write(table.indexOf(s), bitLength);

      // end code
      bitOut.write(endCode, bitLength);

      bitOut.flush();

      return byteOut.toByteArray();
    };

    var lzwTable = function() {

      var _map = {};
      var _size = 0;

      var _this = {};

      _this.add = function(key) {
        if (_this.contains(key) ) {
          throw 'dup key:' + key;
        }
        _map[key] = _size;
        _size += 1;
      };

      _this.size = function() {
        return _size;
      };

      _this.indexOf = function(key) {
        return _map[key];
      };

      _this.contains = function(key) {
        return typeof _map[key] != 'undefined';
      };

      return _this;
    };

    return _this;
  };

  var createDataURL = function(width, height, getPixel) {
    var gif = gifImage(width, height);
    for (var y = 0; y < height; y += 1) {
      for (var x = 0; x < width; x += 1) {
        gif.setPixel(x, y, getPixel(x, y) );
      }
    }

    var b = byteArrayOutputStream();
    gif.write(b);

    var base64 = base64EncodeOutputStream();
    var bytes = b.toByteArray();
    for (var i = 0; i < bytes.length; i += 1) {
      base64.writeByte(bytes[i]);
    }
    base64.flush();

    return 'data:image/gif;base64,' + base64;
  };

  //---------------------------------------------------------------------
  // returns qrcode function.

  return qrcode;
}();

// multibyte support
!function() {

  qrcode.stringToBytesFuncs['UTF-8'] = function(s) {
    // http://stackoverflow.com/questions/18729405/how-to-convert-utf8-string-to-byte-array
    function toUTF8Array(str) {
      var utf8 = [];
      for (var i=0; i < str.length; i++) {
        var charcode = str.charCodeAt(i);
        if (charcode < 0x80) utf8.push(charcode);
        else if (charcode < 0x800) {
          utf8.push(0xc0 | (charcode >> 6),
              0x80 | (charcode & 0x3f));
        }
        else if (charcode < 0xd800 || charcode >= 0xe000) {
          utf8.push(0xe0 | (charcode >> 12),
              0x80 | ((charcode>>6) & 0x3f),
              0x80 | (charcode & 0x3f));
        }
        // surrogate pair
        else {
          i++;
          // UTF-16 encodes 0x10000-0x10FFFF by
          // subtracting 0x10000 and splitting the
          // 20 bits of 0x0-0xFFFFF into two halves
          charcode = 0x10000 + (((charcode & 0x3ff)<<10)
            | (str.charCodeAt(i) & 0x3ff));
          utf8.push(0xf0 | (charcode >>18),
              0x80 | ((charcode>>12) & 0x3f),
              0x80 | ((charcode>>6) & 0x3f),
              0x80 | (charcode & 0x3f));
        }
      }
      return utf8;
    }
    return toUTF8Array(s);
  };

  return qrcode;
}();

function asciiFold(s) {
  // QR taşınabilirliği için Türkçe karakterleri ASCII'ye indirge (telefon tarayıcı uyumu)
  return (s || "").replace(/[şŞ]/g,"s").replace(/[ıİ]/g,"i").replace(/[ğĞ]/g,"g").replace(/[üÜ]/g,"u").replace(/[öÖ]/g,"o").replace(/[çÇ]/g,"c").replace(/λ/g,"L");
}

// Motor sonucundan belirsizlik bayraklarını türetir (SPRT verisine bağlı, online+offline ortak).
// boundary: routing GREY (motor çekimser) → risk sınırı net değil.
// multiple: ayırıcı tanıda 2+ hipotez kayda değer payda (ikincil ≥ %15).
// unusual: belirtiler var ama hiçbir hipotez confirmed değil (net örüntüye oturmuyor).
function deriveAbstention(res) {
  if (!res) return { boundary: false, multiple: false, unusual: false };
  const diffs = res.diffs || [];
  const confirmedCount = res.sprt?.confirmed?.length || 0;
  const boundary = res.routing === "GREY";
  const multiple = diffs.length >= 2 && diffs[1] && diffs[1].pct >= 15;
  // unusual yalnız KARARSIZ bölgede anlamlı: net RED (red-flag/escalation) veya GREEN net karardır.
  const unusual = diffs.length > 0 && confirmedCount === 0 && (res.routing === "GREY" || res.routing === "YELLOW") && !res.escalated;
  return { boundary, multiple, unusual };
}

function buildQRPayload(routing, symptoms, lambda, reason, lang, doctorAlert, diffs, sprt) {
  const L = lang === "tr"
    ? { head:"SHC TRIYAJ OZETI", sl:"Bulgular", gl:"Gerekce", dx:"Ayirici Tani", al:"Klinik Not", lam:"Risk(L)", calc:"SPRT" }
    : { head:"SHC TRIAGE SUMMARY", sl:"Symptoms", gl:"Basis", dx:"Differentials", al:"Clinical Note", lam:"Risk(L)", calc:"SPRT" };
  const sx = asciiFold((symptoms || []).slice(0, 10).join(", ")) || "-";
  const lam = lambda != null ? lambda.toFixed(2) : "-";
  const rsn = asciiFold((reason || "-").slice(0, 90));
  const lines = [
    L.head,
    `${L.lam}: ${routing || "-"} (L=${lam})`,
    `${L.sl}: ${sx}`,
    `${L.gl}: ${rsn}`,
  ];
  // SPRT hesap özeti: S skoru, prior, karar sınırı, olabilirlik oranı (odds). Sığarsa girer.
  if (sprt && typeof sprt.S === "number") {
    const odds = Math.exp(sprt.S);
    const oddsStr = odds >= 1 ? `${odds.toFixed(1)}:1` : `1:${(1/odds).toFixed(1)}`;
    const steps = sprt.traj ? sprt.traj.length - 1 : 0;
    const s0 = typeof sprt.s0 === "number" ? sprt.s0.toFixed(2) : "-";
    lines.push(`${L.calc}: S=${sprt.S.toFixed(2)} (prior ${s0}, ${steps} bulgu, sinir +-2.94) odds ${oddsStr}`);
    // Adım adım birikim: prior + her bulgunun S'e katkısı (λ skorunun nasıl oluştuğu)
    if (sprt.traj && sprt.traj.length) {
      const trace = sprt.traj.map(t => {
        if (t.t === "prior") return `prior ${t.S.toFixed(2)}`;
        const sign = t.present ? "+" : "-";
        const yv = t.y >= 0 ? `+${t.y.toFixed(2)}` : t.y.toFixed(2);
        const short = asciiFold(t.t).replace(/_/g, " ").split(" ")[0].slice(0, 8);
        return `${sign}${short}${yv}`;
      }).join(" ");
      lines.push(`Hesap: ${trace} = ${sprt.S.toFixed(2)}`);
    }
  }
  // Ayırıcı tanı tablosu (ilk 4, yüzde + kaynak)
  if (diffs && diffs.length) {
    const dx = diffs.slice(0, 4).map(d =>
      `${asciiFold(d.name)} ${d.pct}%`
    ).join("; ");
    lines.push(`${L.dx}: ${dx}`);
  }
  // Klinik kılavuz notu — [SPRT] teknik izini at (QR'da gereksiz, panelde zaten var), kalanı kırp
  if (doctorAlert) {
    let note = doctorAlert.replace(/\[SPRT\][^\n]*\n*/g, "").trim();
    note = note.split("\n\n").filter(Boolean).pop() || note; // son anlamlı paragraf (klinik öneri)
    if (note) lines.push(`${L.al}: ${asciiFold(note).slice(0, 160)}`);
  }
  return lines.join("\n");
}
function qrMatrix(text) {
  const qr = qrcode(0, "M");
  qr.addData(text, "Byte");
  qr.make();
  const n = qr.getModuleCount();
  const m = [];
  for (let r = 0; r < n; r++) { const row = []; for (let c = 0; c < n; c++) row.push(qr.isDark(r, c) ? 1 : 0); m.push(row); }
  return m;
}

function OnboardingScreen({onStart, dark, setDark}) {
  const [step, setStep] = useState("lang");
  const [selected, setSelected] = useState(null);
  const [selectedMode, setSelectedMode] = useState(null);
  const [consent, setConsent] = useState(false);
  const SF = "-apple-system,BlinkMacSystemFont,'SF Pro Text','Helvetica Neue',sans-serif";
  const bg  = dark ? "#1c1c1e" : "#ffffff";
  const bg2 = dark ? "#2c2c2e" : "#f5f5f7";
  const txt = dark ? "#ffffff" : "#1d1d1f";
  const txt3= dark ? "#aeaeb2" : "#6e6e73";
  const sep = dark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)";

  const content = {
    en: {
      proceed: "Continue",
      infoTitle: "Before we begin",
      bullets: [
        { key:"science", title: "Evidence-based", body: "70+ clinical patterns · ADA · AHA · NICE · WHO." },
        { key:"medical", title: "Not a diagnosis", body: "Decision-support only. Does not replace a doctor." },
        { key:"alert",   title: "Emergency? Call 911", body: "If in immediate danger, call 911. Don't wait for SHC." },
        { key:"lock",    title: "Your privacy", body: "No personal records stored or shared." },
      ],
      consentLabel: "I understand SHC does not replace medical advice.",
      startBtn: "Start",
      back: "Back",
    },
    tr: {
      proceed: "Devam",
      infoTitle: "Başlamadan önce",
      bullets: [
        { key:"science", title: "Kanıta dayalı", body: "70+ klinik örüntü · ADA · AHA · NICE · WHO." },
        { key:"medical", title: "Tanı koymaz", body: "Karar destek aracıdır. Doktorun yerini almaz." },
        { key:"alert",   title: "Acil mi? Hemen 112", body: "Hayati tehlike varsa bu aracı beklemeyin, 112'yi arayın." },
        { key:"lock",    title: "Gizliliğiniz", body: "Bireysel kaydınız saklanmaz veya paylaşılmaz." },
      ],
      consentLabel: "SHC'nin tıbbi tavsiye niteliği taşımadığını anlıyorum.",
      startBtn: "Başla",
      back: "Geri",
    }
  };

  if (step === "lang") {
    return (
      <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100vh",background:bg,fontFamily:SF,WebkitFontSmoothing:"antialiased",position:"relative"}}>
        <button onClick={()=>setDark(v=>!v)} style={{position:"absolute",top:16,left:16,width:36,height:36,borderRadius:"50%",border:"none",background:"transparent",color:txt3,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>
          {dark
            ? <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
            : <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>
          }
        </button>
        <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:0,width:"100%",maxWidth:330,margin:"0 auto"}}>
          <div style={{textAlign:"center",marginBottom:40}}>
            <div style={{width:56,height:56,borderRadius:14,background:txt,display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 18px"}}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={bg} strokeWidth="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            </div>
            <div style={{fontSize:22,fontWeight:600,color:txt,letterSpacing:"-0.03em",marginBottom:6}}>SHC</div>
            <div style={{fontSize:12,color:txt3,letterSpacing:"-0.01em"}}>Select Language / Dil Seçin</div>
          </div>
          <div style={{display:"flex",gap:12,marginBottom:40}}>
            {[{code:"en",label:"English",sub:"EN"},{code:"tr",label:"Türkçe",sub:"TR"}].map(l=>(
              <button key={l.code} onClick={()=>setSelected(l.code)} style={{
                padding:"18px 36px",borderRadius:14,
                background:selected===l.code?txt:bg2,
                border:"none",
                color:selected===l.code?bg:txt,
                cursor:"pointer",fontFamily:SF,fontSize:13,fontWeight:500,
                display:"flex",flexDirection:"column",alignItems:"center",gap:6,
                transition:"all 0.2s",letterSpacing:"-0.01em",
              }}>
                <span style={{fontSize:11,fontWeight:600,letterSpacing:"0.04em",opacity:0.5}}>{l.sub}</span>
                <span>{l.label}</span>
              </button>
            ))}
          </div>
          <div style={{height:50,display:"flex",alignItems:"center",justifyContent:"center"}}>
            {selected&&(
              <button onClick={()=>setStep("mode")} style={{padding:"13px 40px",borderRadius:12,background:txt,border:"none",color:bg,cursor:"pointer",fontFamily:SF,fontSize:13,fontWeight:400,letterSpacing:"-0.01em",transition:"opacity 0.15s"}}
                onMouseEnter={e=>e.currentTarget.style.opacity="0.85"}
                onMouseLeave={e=>e.currentTarget.style.opacity="1"}>
                {content[selected].proceed}
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  const c = content[selected];

  const DarkToggle = () => (
    <button onClick={()=>setDark(v=>!v)} style={{width:36,height:36,borderRadius:"50%",border:"none",background:"transparent",color:txt3,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>
      {dark
        ? <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
        : <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>
      }
    </button>
  );

  if (step === "mode") {
    const modeOpts = selected === "tr" ? [
      { code:"online",  label:"Çevrimiçi",   sub:"Yapay zeka destekli örüntü analizi ve diferansiyel tanı",  color:"#0071e3" },
      { code:"offline", label:"Çevrimdışı",  sub:"İnternet gerektirmez · Soru-cevap tabanlı örüntü analizi", color:"#8e8e93" },
    ] : [
      { code:"online",  label:"Online",      sub:"AI-powered pattern analysis and differential diagnosis",   color:"#0071e3" },
      { code:"offline", label:"Offline",     sub:"No internet · Question-based pattern analysis",            color:"#8e8e93" },
    ];
    return (
      <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100vh",background:bg,fontFamily:SF,WebkitFontSmoothing:"antialiased",position:"relative"}}>
        <div style={{position:"absolute",top:16,left:16}}><DarkToggle/></div>
        <div style={{display:"flex",flexDirection:"column",alignItems:"center",width:"100%",maxWidth:330,margin:"0 auto",padding:"0 20px",boxSizing:"border-box"}}>
          <div style={{textAlign:"center",marginBottom:40}}>
            <div style={{width:56,height:56,borderRadius:14,background:txt,display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 18px"}}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={bg} strokeWidth="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            </div>
            <div style={{fontSize:22,fontWeight:600,color:txt,letterSpacing:"-0.03em",marginBottom:6}}>
              {selected==="tr" ? "Mod Seçin" : "Select Mode"}
            </div>
            <div style={{fontSize:11,color:txt3,letterSpacing:"-0.01em"}}>
              {selected==="tr" ? "İnternet bağlantınıza göre seçin" : "Choose based on your connectivity"}
            </div>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:10,width:"100%",maxWidth:300,margin:"0 auto 32px"}}>
            {modeOpts.map(m=>(
              <button key={m.code} onClick={()=>setSelectedMode(m.code)} style={{
                display:"flex",alignItems:"center",gap:14,padding:"16px 18px",
                borderRadius:14,border:`1.5px solid ${selectedMode===m.code?m.color:sep}`,
                background:selectedMode===m.code?(dark?"rgba(255,255,255,0.05)":bg2):bg,
                cursor:"pointer",fontFamily:SF,textAlign:"left",transition:"all 0.15s",
              }}>
                <div style={{flex:1}}>
                  <div style={{fontSize:13,fontWeight:500,color:txt,letterSpacing:"-0.02em"}}>{m.label}</div>
                  <div style={{fontSize:11,color:txt3,marginTop:2,letterSpacing:"-0.01em"}}>{m.sub}</div>
                </div>
                {selectedMode===m.code&&<div style={{width:18,height:18,borderRadius:"50%",background:m.color,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                  <svg width="9" height="9" viewBox="0 0 12 12" fill="none"><polyline points="2,6 5,9 10,3" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </div>}
              </button>
            ))}
          </div>
          <div style={{display:"flex",gap:10,width:"100%"}}>
            <button onClick={()=>setStep("lang")} style={{flex:1,padding:"13px",borderRadius:10,background:bg2,border:"none",color:txt,cursor:"pointer",fontFamily:SF,fontSize:12}}>
              {selected==="tr"?"Geri":"Back"}
            </button>
            <button onClick={()=>selectedMode&&setStep("info")} style={{flex:3,padding:"13px",borderRadius:10,background:selectedMode?txt:bg2,border:"none",color:selectedMode?bg:txt3,cursor:selectedMode?"pointer":"default",fontFamily:SF,fontSize:12,transition:"all 0.2s"}}>
              {selected==="tr"?"Devam":"Continue"}
            </button>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100vh",background:bg,padding:"20px",fontFamily:SF,WebkitFontSmoothing:"antialiased",position:"relative"}}>
      <div style={{position:"absolute",top:16,left:16}}><DarkToggle/></div>
      <div style={{display:"flex",flexDirection:"column",alignItems:"center",width:"100%",maxWidth:330,margin:"0 auto"}}>
        <div style={{textAlign:"center",marginBottom:40}}>
          <div style={{width:56,height:56,borderRadius:14,background:txt,display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 18px"}}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={bg} strokeWidth="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
          </div>
          <div style={{fontSize:22,fontWeight:600,color:txt,letterSpacing:"-0.03em"}}>{c.infoTitle}</div>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:0,marginBottom:12,border:`1px solid ${sep}`,borderRadius:12,overflow:"hidden",background:bg}}>
          {c.bullets.map((b,i)=>{
            const iconMap = {
              science: {path:<><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></>},
              medical: {path:<><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></>},
              alert:   {path:<><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></>},
              lock:    {path:<><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></>},
            };
            const ic = iconMap[b.key];
            return (
              <div key={i} style={{padding:"10px 14px",display:"flex",gap:10,alignItems:"center",borderBottom:i<c.bullets.length-1?`1px solid ${sep}`:"none"}}>
                <div style={{width:26,height:26,borderRadius:7,background:bg2,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={txt} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{ic.path}</svg>
                </div>
                <div style={{flex:1,minWidth:0}}>
                  <span style={{fontSize:11,fontWeight:500,color:txt,letterSpacing:"-0.01em"}}>{b.title} </span>
                  <span style={{fontSize:11,color:txt3,letterSpacing:"-0.01em"}}>{b.body}</span>
                </div>
              </div>
            );
          })}
        </div>
        <div onClick={()=>setConsent(v=>!v)} style={{display:"flex",alignItems:"center",gap:10,padding:"11px 14px",borderRadius:10,background:bg2,cursor:"pointer",marginBottom:12,transition:"background 0.15s",border:`1px solid ${sep}`,width:"100%",boxSizing:"border-box"}}
          onMouseEnter={e=>e.currentTarget.style.background=dark?"#48484a":"#efefef"}
          onMouseLeave={e=>e.currentTarget.style.background=bg2}>
          <div style={{width:18,height:18,borderRadius:5,background:consent?"#0071e3":bg,border:`1.5px solid ${consent?"#0071e3":sep}`,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.15s"}}>
            {consent&&<svg width="9" height="9" viewBox="0 0 12 12" fill="none"><polyline points="2,6 5,9 10,3" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>}
          </div>
          <div style={{fontSize:11,color:txt,lineHeight:1.4,letterSpacing:"-0.01em"}}>{c.consentLabel}</div>
        </div>
        <div style={{display:"flex",gap:10,width:"100%"}}>
          <button onClick={()=>{setStep("mode");setConsent(false);}} style={{flex:1,padding:"12px",borderRadius:10,background:bg2,border:"none",color:txt,cursor:"pointer",fontFamily:SF,fontSize:12,fontWeight:400,letterSpacing:"-0.01em"}}>
            {c.back}
          </button>
          <button onClick={()=>consent&&onStart(selected, selectedMode==="offline")} style={{flex:3,padding:"12px",borderRadius:10,background:consent?txt:bg2,border:"none",color:consent?bg:txt3,cursor:consent?"pointer":"default",fontFamily:SF,fontSize:12,fontWeight:400,letterSpacing:"-0.01em",transition:"all 0.2s"}}>
            {c.startBtn}
          </button>
        </div>
      </div>
    </div>
  );
}

function getRouting(dark) { return {
  RED:    { color:"#c0392b", bg:dark?"rgba(192,57,43,0.12)":"#fff5f5", border:"rgba(192,57,43,0.25)", dot:"#c0392b" },
  YELLOW: { color:"#8e8e93", bg:dark?"rgba(160,82,45,0.12)":"#fffaf0", border:"rgba(160,82,45,0.25)", dot:"#92400e" },
  GREEN:  { color:"#1a7a3c", bg:dark?"rgba(26,122,60,0.12)":"#f5fff9",  border:"rgba(26,122,60,0.25)",  dot:"#166534" },
  GREY:   { color:"#8e8e93", bg:dark?"rgba(142,142,147,0.12)":"#f7f7f8", border:"rgba(142,142,147,0.30)", dot:"#8e8e93" },
}; }

function CloseSessionButton({lang, onConfirm, dark}) {
  const [confirming, setConfirming] = useState(false);
  const mutedRed = dark ? "#a05050" : "#c0392b";
  const subtleRed = dark ? "#7a3a3a" : "#c0392b";
  if (confirming) {
    return (
      <div style={{display:"flex",alignItems:"center",gap:6}}>
        <span style={{fontSize:11,color:dark?"#8e8e93":"#6e6e73",whiteSpace:"nowrap"}}>{lang==="tr"?"Emin misin?":"Sure?"}</span>
        <button onClick={()=>{setConfirming(false);onConfirm();}} style={{fontSize:11,fontWeight:500,color:mutedRed,background:"transparent",border:"none",cursor:"pointer",fontFamily:"inherit",padding:"0 4px"}}>
          {lang==="tr"?"Evet":"Yes"}
        </button>
        <button onClick={()=>setConfirming(false)} style={{fontSize:11,fontWeight:500,color:dark?"#8e8e93":"#6e6e73",background:"transparent",border:"none",cursor:"pointer",fontFamily:"inherit",padding:"0 4px"}}>
          {lang==="tr"?"İptal":"Cancel"}
        </button>
      </div>
    );
  }
  return (
    <button onClick={()=>setConfirming(true)} style={{fontSize:11,fontWeight:400,color:dark?"#8e8e93":"#6e6e73",background:"transparent",border:"none",cursor:"pointer",fontFamily:"inherit",padding:"4px 8px",borderRadius:6,transition:"color 0.15s"}}
      onMouseEnter={e=>e.currentTarget.style.color=subtleRed}
      onMouseLeave={e=>e.currentTarget.style.color=dark?"#8e8e93":"#6e6e73"}>
      {lang==="tr"?"Seansı Kapat":"End Session"}
    </button>
  );
}

export default function App() {
  const [lang, setLang] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [uiPhase, setUiPhase] = useState("profiling");
  const [profileAnswers, setProfileAnswers] = useState({});
  const [profileIdx, setProfileIdx] = useState(0);
  const [profile, setProfile] = useState(null);
  const [riskMods, setRiskMods] = useState({});
  const [symptomText, setSymptomText] = useState("");
  const [matches, setMatches] = useState([]);
  const [followUpHistory, setFollowUpHistory] = useState([]);
  const [history, setHistory] = useState([]);
  const [diffs, setDiffs] = useState([]);
  const [routing, setRouting] = useState(null);
  const [lambda, setLambda] = useState(null);
  const [urgency, setUrgency] = useState(null);
  const [doctorAlert, setDoctorAlert] = useState(null);
  const [abstention, setAbstention] = useState({});
  const [panelTab, setPanelTab] = useState("result");
  const [docText, setDocText]   = useState("");
  const [docResult, setDocResult] = useState("");
  const [docLoading, setDocLoading] = useState(false);
  const [docSummary, setDocSummary] = useState("");   // özetlenmiş belge — API context'ine girer
  const [docPhase, setDocPhase]   = useState("idle");
  const [isListening, setIsListening] = useState(false);
  const [doctorMode, setDoctorMode] = useState(false);
  const [dark, setDark] = useState(false);
  const [offlineMode, setOfflineMode] = useState(false);
  const [akinatorAsked, setAkinatorAsked] = useState([]);
  const [akinatorTriggers, setAkinatorTriggers] = useState([]);
  const [akinatorCurrent, setAkinatorCurrent] = useState(null);
  const [akinatorDone, setAkinatorDone] = useState(false);
  const [akinatorScale, setAkinatorScale] = useState(5);
  const [akinatorAnsweredNo, setAkinatorAnsweredNo] = useState([]);
  const [akinatorAbsent, setAkinatorAbsent] = useState([]);
  const [sprtViz, setSprtViz] = useState(null);
  const [akinatorGate, setAkinatorGate] = useState(null);
  const C = dark ? {
    bg:"#1c1c1e",bg2:"#2c2c2e",bg3:"#3a3a3c",surface:"#2c2c2e",
    sep:"rgba(255,255,255,0.08)",text:"#ffffff",text2:"#ebebf5cc",text3:"#ebebf599",
    placeholder:"#636366",userBubble:"#2c2c2e",userText:"#ffffff",
    shcBubble:"#3a3a3c",shcText:"#ffffff",btnBg:"#3a3a3c",
    btnBorder:"rgba(255,255,255,0.12)",accent:"#0a84ff",dot:"#ffffff",
  } : {
    bg:"#ffffff",bg2:"#f5f5f7",bg3:"#efefef",surface:"#ffffff",
    sep:"rgba(0,0,0,0.08)",text:"#1d1d1f",text2:"#1d1d1f",text3:"#6e6e73",
    placeholder:"#aeaeb2",userBubble:"#1d1d1f",userText:"#ffffff",
    shcBubble:"#f5f5f7",shcText:"#1d1d1f",btnBg:"#ffffff",
    btnBorder:"rgba(0,0,0,0.12)",accent:"#0071e3",dot:"#1d1d1f",
  };
  const bottomRef = useRef(null);
  const scrollRef = useRef(null);
  const textareaRef = useRef(null);
  const fileInputRef = useRef(null);
  const chatFileRef  = useRef(null);
  const recognitionRef = useRef(null);

  useEffect(() => {
    if (!lang) return; // onboarding'de scroll yok
    const sc = scrollRef.current;
    if (!sc) return;
    const id = requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        sc.scrollTo({ top: sc.scrollHeight, behavior: "smooth" });
      });
    });
    return () => cancelAnimationFrame(id);
  }, [messages, loading, akinatorCurrent, akinatorGate, akinatorDone, routing, lang]);

  // Body + theme-color'ı app temasına eşitle (alt safe-area boşluğu app arka planıyla aynı olsun)
  useEffect(() => {
    const c = dark ? "#1c1c1e" : "#ffffff";
    document.documentElement.style.setProperty("background", c, "important");
    document.body.style.setProperty("background", c, "important");
    const root = document.getElementById("root");
    if (root) root.style.setProperty("background", c, "important");
    let meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", c);
    const sb = document.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]');
    if (sb) sb.setAttribute("content", dark ? "black" : "default");
  }, [dark]);
  function addMsg(text, role="shc") { setMessages(m => [...m, {role, text, ts:Date.now()}]); }

  function doReset() {
    setMessages([]); setInput(""); setLoading(false); setUiPhase("profiling");
    setProfileAnswers({}); setProfileIdx(0); setProfile(null); setRiskMods({});
    setSymptomText(""); setMatches([]); setFollowUpHistory([]); setHistory([]);
    setDiffs([]); setRouting(null); setLambda(null); setUrgency(null); setSprtViz(null);
    setDoctorAlert(null); setAbstention({}); setPanelTab("result"); setLang(null);
    setDocText(""); setDocResult(""); setDocLoading(false);
    setDocSummary(""); setDocPhase("idle");
    setOfflineMode(false); setAkinatorAsked([]); setAkinatorTriggers([]); setAkinatorCurrent(null); setAkinatorDone(false); setAkinatorScale(5); setAkinatorAnsweredNo([]); setAkinatorAbsent([]); setAkinatorGate(null); setSprtViz(null);
  }

  function startSession(selectedLang, isOffline=false) {
    setLang(selectedLang);
    setOfflineMode(isOffline);
    setUiPhase("profiling");
    const t = T[selectedLang];
    setTimeout(() => { addMsg(t.profileIntro.trim() + "\n\n" + t.questions[0].q); }, 100);
  }

  function toggleListen() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }
    const rec = new SR();
    rec.lang = lang === "tr" ? "tr-TR" : "en-US";
    rec.continuous = false;
    rec.interimResults = false;
    rec.onresult = (e) => {
      const transcript = e.results[0]?.[0]?.transcript || "";
      if (transcript) setInput(prev => prev ? prev + " " + transcript : transcript);
    };
    rec.onend = () => setIsListening(false);
    rec.onerror = () => setIsListening(false);
    recognitionRef.current = rec;
    rec.start();
    setIsListening(true);
  }

  async function send() {
    const text = input.trim();
    if (!text || loading) return;
    setInput("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";
    addMsg(text, "user");
    const t = T[lang];
    const isProfilingDone = profileIdx >= t.questions.length;
    if (uiPhase === "profiling" && !isProfilingDone) { await handleProfileAnswer(text); return; }
    if (uiPhase === "doc_upload") {
      const isNone = /^(yok|no|none|hayır|nope|-)$/i.test(text.trim());
      if (isNone) {
        setDocPhase("done");
        setUiPhase("symptoms");
        setTimeout(() => addMsg(T[lang].profileComplete(false)), 200);
      } else {
        // Belge var — özetle
        setLoading(true);
        setDocPhase("uploading");
        const summary = await summarizeDoc(text, profile);
        if (summary === "NOT_MEDICAL") {
          const warn = lang==="tr"
            ? "Bu metin tıbbi bir belge gibi görünmüyor. Kan tahlili, MR raporu veya muayene notu yapıştırabilirsiniz. Devam etmek için \"yok\" yazın."
            : "This doesn't look like a medical document. You can paste a lab result, MRI report, or clinic note. Type \"none\" to continue without a document.";
          addMsg(warn);
          setDocPhase("asking");
          setUiPhase("doc_upload");
        } else if (summary) {
          setDocSummary(summary);
          setDocResult(summary);
          const ack = lang==="tr"
            ? `Belgenizi aldım, özetledim ve değerlendirmeme dahil ettim.\n\nŞimdi bana neden geldiğinizi anlatın — sizi en çok ne rahatsız ediyor?`
            : `Got it — I've summarized your document and included it in my assessment.\n\nNow tell me what brought you in — what's been bothering you most?`;
          addMsg(ack);
          setDocPhase("done");
          setUiPhase("symptoms");
        } else {
          const fail = lang==="tr"
            ? "Belgeyi işleyemedim ama devam edebiliriz.\n\nBana neden geldiğinizi anlatın."
            : "Couldn't process the document, but we can continue.\n\nTell me what's been bothering you.";
          addMsg(fail);
          setDocPhase("done");
          setUiPhase("symptoms");
        }
        setLoading(false);
      }
      return;
    }
    await handleSymptomTurn(text);
  }

  function handleKey(e) { if (e.key==="Enter" && !e.shiftKey) { e.preventDefault(); send(); } }

  function validateProfileAnswer(key, type, text) {
    const tv = text.trim().toLowerCase();
    const t = T[lang];
    if (!tv) return {ok:false, hint:t.validation.empty};
    if (type==="choice") return {ok:true};
    if (type==="number") {
      const n = parseFloat(tv);
      if (isNaN(n)||n<=0) return {ok:false, hint:t.validation.number};
      if (key==="age"&&n<18) return {ok:false, hint:t.validation.age};
      if (key==="age"&&n>120) return {ok:false, hint:t.validation.age_over};
      if (key==="height_cm"&&(n<50||n>250)) return {ok:false, hint:t.validation.height};
      if (key==="weight_kg"&&(n<10||n>400)) return {ok:false, hint:t.validation.weight};
    }
    return {ok:true};
  }

  async function summarizeDoc(rawText, profileData, pdfBase64) {
    const pStr = profileData ? [profileData.age&&`${profileData.age}y`, profileData.sex, profileData.bmi&&`BMI ${profileData.bmi.toFixed(0)}`, profileData.diabetes&&"DM", profileData.hypertension&&"HTN"].filter(Boolean).join(", ") : "";
    const sys = lang==="tr"
      ? `Sen klinik bir asistansın. Verilen belgenin tıbbi bir belge olup olmadığını önce kontrol et (kan tahlili, MR/BT raporu, epikriz, muayene notu, reçete, laboratuvar sonucu vb.). Eğer tıbbi bir belge DEĞİLSE, sadece şunu yaz: "NOT_MEDICAL". Tıbbi belgeyse doktor için özetle. Hasta: ${pStr}. Çıktı: önemli bulgular, anormal değerler, doktor için dikkat çekici noktalar. Maksimum 300 kelime. Sadece özet yaz.`
      : `You are a clinical assistant. First check if the document is a medical document (blood work, MRI/CT report, discharge summary, clinic note, prescription, lab result, etc.). If it is NOT a medical document, respond only with: "NOT_MEDICAL". If it is medical, summarize it for a doctor. Patient: ${pStr}. Output: key findings, abnormal values, clinically notable points. Max 300 words. Output summary only.`;
    const userContent = pdfBase64
      ? [{type:"document", source:{type:"base64", media_type:"application/pdf", data:pdfBase64}}, {type:"text", text:"Check if this is a medical document and summarize as instructed."}]
      : `Document:\n\n${rawText.trim()}`;
    try {
      const data = await callAPI(sys, [{role:"user", content:userContent}]);
      const result = (data?.text || "").trim();
      if (result === "NOT_MEDICAL") return "NOT_MEDICAL";
      return result;
    } catch { return ""; }
  }

  async function readFileAsBase64(file) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result.split(",")[1]);
      r.onerror = rej;
      r.readAsDataURL(file);
    });
  }

  async function handleFileUpload(file, source) {
    // source: "chat" | "panel"
    if (!file) return;
    const isPdf = file.type === "application/pdf";
    const isText = file.type.startsWith("text/");
    if (!isPdf && !isText) {
      if (source === "chat") addMsg(lang==="tr" ? "Sadece PDF veya metin dosyası yükleyebilirsiniz." : "Only PDF or text files are supported.");
      return;
    }
    if (source === "chat") {
      addMsg(lang==="tr" ? `📄 ${file.name}` : `📄 ${file.name}`, "user");
      setLoading(true);
    } else {
      setDocLoading(true); setDocResult("");
    }
    let summary = "";
    if (isPdf) {
      const b64 = await readFileAsBase64(file);
      summary = await summarizeDoc("", profile, b64);
    } else {
      const text = await file.text();
      summary = await summarizeDoc(text, profile);
    }
    if (summary === "NOT_MEDICAL") {
      const warn = lang==="tr"
        ? "Bu belge tıbbi bir belge gibi görünmüyor. Lütfen kan tahlili, MR/BT raporu, epikriz veya muayene notu yükleyin."
        : "This doesn't look like a medical document. Please upload a lab result, MRI/CT report, discharge summary, or clinic note.";
      if (source === "chat") addMsg(warn);
      else setDocResult(warn);
    } else if (summary) {
      setDocSummary(prev => prev ? prev + "\n\n---\n\n" + summary : summary);
      setDocResult(summary);
      if (source === "chat") {
        const ack = lang==="tr"
          ? `Belgenizi okudum ve değerlendirmeme dahil ettim.\n\nDevam edelim — sizi en çok ne rahatsız ediyor?`
          : `I've read your document and included it in my assessment.\n\nLet's continue — what's been bothering you most?`;
        addMsg(ack);
        if (uiPhase === "doc_upload") { setDocPhase("done"); setUiPhase("symptoms"); }
      }
    } else {
      const fail = lang==="tr" ? "Belge okunamadı." : "Couldn't read the document.";
      if (source === "chat") addMsg(fail);
      else setDocResult(fail);
    }
    setLoading(false); setDocLoading(false);
  }

  async function handleProfileAnswer(text) {
    const t = T[lang];
    const q = t.questions[profileIdx];
    if (!q) { await handleSymptomTurn(text); return; }
    const validation = validateProfileAnswer(q.key, q.type, text);
    if (!validation.ok) { setTimeout(() => addMsg(`${validation.hint}\n\n${q.q}`), 150); return; }
    const newAnswers = {...profileAnswers, [q.key]: text};
    setProfileAnswers(newAnswers);
    const nextIdx = profileIdx + 1;
    setProfileIdx(nextIdx);
    if (nextIdx < t.questions.length) {
      setTimeout(() => addMsg(t.questions[nextIdx].q), 200);
    } else {
      const p = parseProfile(newAnswers);
      setProfile(p);
      const {mods} = computeRiskProfile({age:p.age,sex:p.sex,bmi:p.bmi,smoking:p.smoking,diabetes:p.diabetes,hypertension:p.hypertension,familyHistory:p.familyHistory});
      setRiskMods(mods);
      if (!offlineMode) {
        // Online modda önce belge sorusu
        setDocPhase("asking");
        const docQ = lang==="tr"
          ? `Teşekkürler, bilgilerinizi aldım.\n\nDevam etmeden önce: Mevcut bir tıbbi belgeniz var mı? (Kan tahlili, MR/BT raporu, epikriz, muayene notu vb.)\n\nVarsa aşağıdaki alana yapıştırabilirsiniz. Yoksa "yok" yazın.`
          : `Got it, thank you.\n\nBefore we continue: do you have any medical documents on hand? (Blood work, MRI/CT report, discharge summary, clinic note, etc.)\n\nIf so, paste it below. If not, just type "none".`;
        setTimeout(() => { addMsg(docQ); setUiPhase("doc_upload"); }, 200);
      } else {
        setTimeout(() => {
          addMsg(t.profileComplete(offlineMode));
          setUiPhase("symptoms");
        }, 200);
      }
    }
  }

  function startAkinator() {
    setAkinatorAsked([]);
    setAkinatorTriggers([]);
    
    setAkinatorAnsweredNo([]);
    setAkinatorAbsent([]);
    setAkinatorGate(null);
    setAkinatorDone(false);
    setAkinatorScale(5);
    setAkinatorCurrent(null);
  }

  function handleGateSelect(gateId) {
    const gates = AKINATOR_GATES[lang] || AKINATOR_GATES.tr;
    const gate = gates.find(g => g.id === gateId);
    if (!gate) return;
    setAkinatorGate(gateId);
    addMsg(gate.label, "user");
    const firstQ = pickNextQuestion([], gateId, [], riskMods, [], []);
    if (firstQ) {
      setAkinatorCurrent(firstQ);
      setTimeout(() => addMsg(lang==="tr" ? firstQ.text_tr : firstQ.text_en), 250);
    }
  }

  function handleAkinatorAnswer(answer, scaleVal) {
    if (!akinatorCurrent) return;
    const q = akinatorCurrent;
    const newAsked = [...akinatorAsked, q.id];
    let newTriggers = [...akinatorTriggers];
    let newAnsweredNo  = [...akinatorAnsweredNo];
    let newAbsent = [...akinatorAbsent];

    if (q.type === "yn") {
      if (answer === "yes") {
        newTriggers = [...newTriggers, ...(q.triggers_yes||[])];
      } else {
        newAnsweredNo = [...newAnsweredNo, q.id];
        // Negatif kanıt: yalnızca açık "hayır" yokluk sayılır; "emin değilim" nötrdür
        if (answer === "no") newAbsent = [...newAbsent, ...(q.triggers_yes || [])];
      }
    } else if (q.type === "scale") {
      const val = scaleVal ?? akinatorScale;
      if (val >= 7) newTriggers = [...newTriggers, ...(q.scale_high_triggers||[])];
      if (val >= 4) newTriggers = [...newTriggers, q.scale_trigger];
    }

    const labelMap = {
      yes:   lang==="tr" ? "Evet" : "Yes",
      no:    lang==="tr" ? "Hayır" : "No",
      unsure:lang==="tr" ? "Emin Değilim" : "Unsure",
    };
    const displayLabel = q.type==="scale"
      ? `${scaleVal ?? akinatorScale}/10`
      : labelMap[answer];
    addMsg(displayLabel, "user");

    setAkinatorAsked(newAsked);
    setAkinatorTriggers(newTriggers);
    setAkinatorAnsweredNo(newAnsweredNo);
    setAkinatorAbsent(newAbsent);

    const MAX_QUESTIONS = 12; // SPRT erken durdurma + negatif kanıtla 12 yeterli; limitte GREY/karar
    const result = computeOfflineResult(newTriggers, riskMods, newAsked.length, akinatorGate, lang, false, newAbsent);

    const finalize = (res, forced=false) => {
      setAkinatorDone(true);
      setAkinatorCurrent(null);
      if (res) {
        setRouting(res.routing);
        setLambda(res.lambda);
        setDiffs(res.diffs);
        setSprtViz(res.sprt || null);
        setDoctorAlert(res.doctorAlert);
        setAbstention(deriveAbstention(res));
        setUrgency(res.urgency);
        setUiPhase("decision");
        setPanelTab("result");
        const routingLabel = T[lang].routing[res.routing];
        const prefix = forced
          ? (lang==="tr" ? `Tüm sorular tamamlandı.` : `Assessment complete.`)
          : (lang==="tr" ? `Değerlendirme tamamlandı.` : `Assessment complete.`);
        addMsg(`${prefix}\n\n▸ ${routingLabel.label}`);
      } else {
        addMsg(lang==="tr"
          ? "Tüm sorular tamamlandı. Bu kategoride net bir örüntü eşleşmesi bulunamadı. Lütfen bir sağlık uzmanına başvurun."
          : "All questions complete. No clear pattern match found in this category. Please consult a healthcare professional."
        );
      }
    };

    if (result) { finalize(result, false); return; }
    if (newAsked.length >= MAX_QUESTIONS) {
      finalize(computeOfflineResult(newTriggers, riskMods, 999, akinatorGate, lang, true, newAbsent), true);
      return;
    }

    const nextQ = pickNextQuestion(newAsked, akinatorGate, newTriggers, riskMods, newAnsweredNo, newAbsent);
    if (nextQ) {
      setAkinatorCurrent(nextQ);
      setAkinatorScale(5);
      const totalQs = AKINATOR_QUESTIONS.filter(q => q.ask_if === akinatorGate).length;
      setTimeout(() => addMsg(lang==="tr" ? nextQ.text_tr : nextQ.text_en), 250);
    } else {
      // Bu kapının soruları bitti — zorla karar ver
      finalize(computeOfflineResult(newTriggers, riskMods, 999, akinatorGate, lang, true, newAbsent), true);
    }
  }

  function parseProfile(answers) {
    const p = {};
    for (const [k,v] of Object.entries(answers)) {
      const n = parseFloat(v);
      if (k==="age"&&!isNaN(n)) p.age=n;
      else if (k==="height_cm"&&!isNaN(n)) p.height=n;
      else if (k==="weight_kg"&&!isNaN(n)) p.weight=n;
      else if (k==="sex") p.sex = /female|kadın|kadin/i.test(v) ? "female" : "male";
      else if (k==="smoking") p.smoking = /yes|evet/i.test(v);
      else if (k==="diabetes") p.diabetes = /yes|evet/i.test(v);
      else if (k==="hypertension") p.hypertension = /yes|evet/i.test(v);
      else if (k==="family_history") p.familyHistory = /yes|evet/i.test(v);
    }
    if (p.height && p.weight) p.bmi = p.weight / Math.pow(p.height/100, 2);
    return p;
  }

  const EMERGENCY_PATTERNS = {
    tr: /bilinç kaybı|bayılıyorum|nefes duruyor|kalp durdu|felç geçiriyorum|ölüyorum|çok şiddetli kanama/i,
    en: /unconscious|not breathing|heart stopped|having a stroke|i'm dying|severe bleeding/i,
  };

  function trimHistory(hist) {
    const MAX_TURNS = 12;
    if (hist.length <= MAX_TURNS) return hist;
    return [hist[0], ...hist.slice(-(MAX_TURNS - 1))];
  }

  function toGeminiParts(content) {
    if (typeof content === "string") return [{ text: content }];
    if (!Array.isArray(content)) return [{ text: String(content || "") }];

    return content.map((block) => {
      if (block?.type === "text") return { text: block.text || "" };
      if (block?.type === "document" && block?.source?.type === "base64") {
        return {
          inlineData: {
            mimeType: block.source.media_type || "application/pdf",
            data: block.source.data || ""
          }
        };
      }
      return { text: block?.text || "" };
    });
  }

  function toGeminiContents(messages) {
    return (messages || []).map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: toGeminiParts(m.content)
    }));
  }

  async function callAPI(system, messages, retries = 2) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 90000);
    try {
      const wantsJson = /Respond ONLY in this exact JSON|exact JSON|\{\s*"text"/i.test(system || "");
      const res = await fetch("/api/gemini/generate", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        signal: controller.signal,
        body: JSON.stringify({
          system,
          contents: toGeminiContents(messages),
          maxOutputTokens: wantsJson ? 1400 : 1200,
          temperature: wantsJson ? 0.2 : 0.35,
          wantsJson
        })
      });
      clearTimeout(timeout);
      if (res.status === 529 || res.status === 503 || res.status === 504 || res.status === 502) {
        if (retries > 0) { await new Promise(r => setTimeout(r, 3000)); return callAPI(system, messages, retries - 1); }
        throw new Error("overloaded");
      }
      if (res.status === 429) {
        if (retries > 0) { await new Promise(r => setTimeout(r, 5000)); return callAPI(system, messages, retries - 1); }
        throw new Error("rate_limit");
      }
      if (!res.ok) {
        let detail = "";
        try { detail = (await res.json())?.error || ""; } catch {}
        throw new Error(detail || `http_${res.status}`);
      }
      return await res.json();
    } catch (err) {
      clearTimeout(timeout);
      if (err.name === "AbortError" && retries > 0) return callAPI(system, messages, retries - 1);
      throw err;
    }
  }

  async function handleSymptomTurn(text) {
    if (EMERGENCY_PATTERNS[lang]?.test(text)) {
      const emergencyMsg = lang === "tr"
        ? "Anlattıklarınız acil bir durum işareti taşıyor.\n\nLütfen hemen 112'yi arayın veya en yakın acil servise gidin. SHC'yi beklemeyin."
        : "What you've described may be an emergency.\n\nPlease call 911 immediately or go to your nearest ED. Do not wait for SHC.";
      addMsg(emergencyMsg);
      setLoading(false);
      return;
    }

    // Çevrimdışı modda Akinator başlat
    if (offlineMode) {
      startAkinator();
      return;
    }

    setLoading(true);
    const allSymptoms = (symptomText + " " + text).trim();
    setSymptomText(allSymptoms);
    const newMatches = matchPatterns(allSymptoms, riskMods);
    setMatches(newMatches);

    const rawHistory = [...history, {role:"user", content:text}];
    const trimmedHistory = trimHistory(rawHistory);
    setHistory(rawHistory);

    try {
      const data = await callAPI(
        buildSystemPrompt(lang, allSymptoms, profile, newMatches, followUpHistory, docSummary),
        trimmedHistory
      );
      const raw = data.text || "";
      let parsed;
      try {
        // Strip markdown fences, leading/trailing whitespace, and any text before first {
        const cleaned = raw.replace(/```json|```/g,"").trim();
        const jsonStart = cleaned.indexOf("{");
        const jsonEnd = cleaned.lastIndexOf("}");
        const jsonStr = jsonStart >= 0 && jsonEnd > jsonStart
          ? cleaned.slice(jsonStart, jsonEnd + 1)
          : cleaned;
        parsed = JSON.parse(jsonStr);
      } catch {
        // Parse failed — show a neutral message, never show raw JSON to user
        const fallbackMsg = lang === "tr"
          ? "Değerlendirme tamamlandı. Lütfen semptomlarınızı tekrar özetler misiniz?"
          : "Assessment complete. Could you summarize your symptoms once more?";
        parsed = {text: fallbackMsg, phase:"collecting", differentials:[], routing:null};
      }
      // Never show raw JSON or code as text — if text looks like JSON, replace it
      const displayText = (parsed.text && !parsed.text.trim().startsWith("{") && !parsed.text.trim().startsWith("["))
        ? parsed.text
        : (lang === "tr" ? "Değerlendiriyorum..." : "Processing...");
      addMsg(displayText);
      setHistory(h => [...h, {role:"assistant", content:displayText}]);
      if (parsed.differentials?.length) setDiffs(parsed.differentials);
      if (parsed.lambda != null) setLambda(parsed.lambda);
      if (parsed.routing) {
        // Deterministic clinical safety net — fires regardless of LLM routing
        const sx = allSymptoms.toLowerCase();
        const dT = [];
        if (/jaundice|yellow(ing)? (skin|eyes)|sarıl|gözler.{0,6}sarı|cild.{0,4}sarı|der.{0,4}sarı/.test(sx)) dT.push("jaundice");
        if (/clay.?colou?red stool|pale stool|acholic|açık renkli dışkı|beyaz dışkı|kil renginde/.test(sx)) dT.push("clay_stool");
        if (/fever|febrile|ateş|titreme|üşüme|rigor/.test(sx)) dT.push("fever");
        if (/tachycardi|racing heart|rapid heart|heart racing|kalp.{0,8}hızl|çarpıntı/.test(sx)) dT.push("tachycardia");
        if (/short(ness)? of breath|breathless|nefes darlığı|nefes alam/.test(sx)) dT.push("shortness_of_breath");
        if (/vomit|throwing up|kusma|kusuyor|kustu/.test(sx)) dT.push("vomiting");
        if (/fruity breath|aceton|keton|asetonlu nefes|meyve.{0,5}nefes|nefes.{0,6}meyve/.test(sx)) dT.push("fruity_breath");
        if (/sudden onset|rapid onset|came on (fast|suddenly)|ani(den)? başla|hızla başla|aniden|birden/.test(sx)) dT.push("rapid_onset");
        if (/abdominal pain|stomach pain|belly pain|karın ağrı|mide ağrı/.test(sx)) dT.push("abdominal_pain");
        if (/low blood pressure|hypotension|düşük tansiyon|tansiyon.{0,4}düşük/.test(sx)) dT.push("low_blood_pressure");
        if (/dizz|lighthead|baş dön|sersem/.test(sx)) dT.push("dizziness");
        if (/rebound|releasing the press|bırakınca ağrı|elini? çekince ağrı/.test(sx)) dT.push("rebound_tenderness");
        if (/chest pain|göğüs ağrı/.test(sx)) dT.push("chest_pain");
        if (/cough(ing)? (up )?blood|hemoptys|kan tükür|kanlı balgam/.test(sx)) dT.push("coughing_blood");
        if (/bayıl|bilinc?ini kaybet|kendinden geç|passed out|blacked out|lost consciousness/i.test(sx)) dT.push("loss_of_consciousness");
        if (/boğaz(ım)? (daral|şiş)|dil(im)? şiş|nefes borusu|throat (closing|tight)|tongue swell/i.test(sx)) dT.push("throat_tightness");
        if (/kanama durm|kanamayı durduram|won'?t stop bleeding|bleeding heavily|can'?t stop the bleed/i.test(sx)) dT.push("bleeding_uncontrolled");
        if (/perde in|gölge indi|curtain (over|coming|across)/i.test(sx)) dT.push("curtain_vision");
        if (/ani görme kayb|göremiyorum|görmüyor|lost (my )?vision|can'?t see/i.test(sx)) dT.push("sudden_vision_loss");
        if (/kırmızı çizgi|red streak/i.test(sx)) dT.push("red_streaks");
        // ── "LLM extracts, never decides": karar deterministik SPRT motorunda ──
        const llmPresent = (parsed.symptoms?.present || []).filter(t => ALL_TRIGGERS.has(t));
        const llmAbsent  = (parsed.symptoms?.absent  || []).filter(t => ALL_TRIGGERS.has(t));
        const enginePresent = [...new Set([...llmPresent, ...dT])];
        const engineAbsent = llmAbsent.filter(t => !enginePresent.includes(t));
        // Soft evidence: LLM'in kalibre olasılıkları (Tez 3.3). dT regex tespitleri kesin sayılır (c=1).
        const llmConfRaw = parsed.symptoms?.confidence || {};
        const confMap = {};
        for (const t of [...enginePresent, ...engineAbsent]) {
          const c = llmConfRaw[t];
          if (typeof c === "number" && c >= 0 && c <= 1 && !dT.includes(t)) confMap[t] = c;
        }
        const engineRes = enginePresent.length > 0 ? sprtDecide({
          collected: enginePresent, absent: engineAbsent, riskMods, askedCount: 999,
          gate: null, lang, force: true,
          patternKeys: Object.keys(PATTERNS), PAT: PATTERNS,
          namesTR: OFFLINE_PATTERN_NAMES_TR, urgTR: OFFLINE_URGENCY_TR, urgEN: OFFLINE_URGENCY_EN,
          escalateFn: clinicalEscalation, escNoteFn: escalationNote, redFlagFn: checkRedFlags,
          minQuestions: 0, gatePatterns: GATE_PATTERNS, confMap}) : null;

        let finalRouting, escId = "";
        if (engineRes?.routing) {
          // Güvenlik: motor kıt çıkarımla LLM'in RED'ini ASLA düşürmesin (yalnız yükseltebilir)
          const RANK = { RED:3, GREY:2, YELLOW:1, GREEN:0 };
          finalRouting = (parsed.routing && RANK[parsed.routing] > RANK[engineRes.routing])
            ? parsed.routing : engineRes.routing;
          const advisory = parsed.doctor_alert
            ? (lang==="tr" ? `LLM klinik notu (danışma): ${parsed.doctor_alert}` : `LLM clinical note (advisory): ${parsed.doctor_alert}`)
            : "";
          const disagree = parsed.routing && parsed.routing !== finalRouting
            ? (lang==="tr" ? `LLM yönlendirme görüşü: ${parsed.routing} → motor kararı: ${finalRouting}` : `LLM routing opinion: ${parsed.routing} → engine decision: ${finalRouting}`)
            : "";
          setRouting(finalRouting);
          setUrgency(finalRouting === engineRes.routing ? engineRes.urgency : (lang==="tr"?OFFLINE_URGENCY_TR[finalRouting]:OFFLINE_URGENCY_EN[finalRouting]));
          setSprtViz(engineRes.sprt || null);
          setDoctorAlert([engineRes.doctorAlert, disagree, advisory].filter(Boolean).join("\n\n"));
          setLambda(engineRes.lambda);
        } else {
          // Çıkarım boş — güvenlik ağı: LLM görüşü + deterministik escalation override
          finalRouting = parsed.routing;
          const topConds = [...newMatches.slice(0,3).map(m=>(m.icd||"").toUpperCase()), ...((parsed.differentials||[]).slice(0,3).map(d=>(d.icd||"").toUpperCase()))];
          for (const cid of ["K81","K85","E10","E27.1","K37","N20","I80.2","S06.0","T14.2","S61.9","L03.9","B02.9","L50.9"]) {
            if (topConds.includes(cid)) {
              const r = clinicalEscalation(parsed.routing, cid, dT);
              if (r !== parsed.routing) { finalRouting = r; escId = cid; break; }
            }
          }
          const escNote = escId ? escalationNote(escId, dT, lang) : "";
          setRouting(finalRouting);
          setUrgency(escId ? (lang==="tr"?OFFLINE_URGENCY_TR.RED:OFFLINE_URGENCY_EN.RED) : parsed.urgency);
          setSprtViz(null);
          setDoctorAlert(escNote ? `${escNote}\n\n${parsed.doctor_alert||""}` : parsed.doctor_alert);
          if (escId) setLambda(Math.max(9.6, parsed.lambda || 10));
        }
        setUiPhase("decision");
        setPanelTab("result");
        // If pattern engine found matches, keep them.
        // If empty (short final turn), build matches from LLM differentials so Analiz Motoru isn't blank.
        if (newMatches.length === 0 && parsed.differentials?.length) {
          const syntheticMatches = parsed.differentials.slice(0, 5).map((d, i) => ({
            name: d.name || d.condition || "—",
            icd: d.icd || "—",
            triggerHits: Math.max(1, Math.round((d.score || 50) / 20)),
            sprt_lr: d.lr || d.sprt_lr || 2.0,
            profileMod: d.profileMod || 1.0,
            confirmatoryMet: i === 0,
            routing_if_confirmed: d.routing || parsed.routing || "YELLOW",
            source: d.source || "LLM clinical reasoning",
          }));
          setMatches(syntheticMatches);
        }
      }
// Belirsizlik bayrakları: motorun gerçek sonucundan türetilir (LLM tahminine değil).
      const absSource = (typeof engineRes !== "undefined" && engineRes) ? engineRes : { routing: parsed.routing, diffs: parsed.differentials || [], sprt: null };
      setAbstention(deriveAbstention(absSource));
      if (parsed.phase==="collecting" && parsed.text) setFollowUpHistory(h => { const updated=[...h]; if(updated.length>0&&updated[updated.length-1].a===""){updated[updated.length-1]={...updated[updated.length-1],a:text};} return [...updated,{q:parsed.text,a:""}]; });
    } catch (err) {
      // API hata verince otomatik çevrimdışı moda geç
      setOfflineMode(true);
      const switchMsg = lang === "tr"
        ? "Bağlantı kurulamadı — çevrimdışı moda geçildi.\n\nAşağıdaki listeden size en çok uyan şikayeti seçin:"
        : "Could not connect — switched to offline mode.\n\nSelect the complaint that best describes what you're experiencing:";
      addMsg(switchMsg);
      setTimeout(() => startAkinator(), 100);
    }
    setLoading(false);
  }

  if (!lang) return <OnboardingScreen onStart={startSession} dark={dark} setDark={setDark}/>;

  const t = T[lang];
  const APPLE_ROUTING = getRouting(dark);

  const ar = routing ? APPLE_ROUTING[routing] : null;
  const rl = routing ? t.routing[routing] : null;
  const pct = Math.round((profileIdx / t.questions.length) * 100);
  const needlePct = lambda ? Math.min(Math.max((Math.log10(Math.max(lambda,0.001))+2)/4*100,2),98) : null;
  const needleColor = routing==="RED"?"#c0392b":routing==="GREEN"?"#1a7a3c":routing==="YELLOW"?"#a0522d":"#aeaeb2";


  function exportPDF() {
    const now = new Date();
    const dateStr = now.toLocaleString(lang==="tr"?"tr-TR":"en-GB");
    const tr = lang==="tr";
    const routingColor = routing==="RED"?"#c0392b":routing==="GREEN"?"#1a7a3c":routing==="YELLOW"?"#92400e":"#555";
    const routingBg   = routing==="RED"?"#fef2f2":routing==="GREEN"?"#f0fdf4":routing==="YELLOW"?"#fffbeb":"#f9f9f9";
    const profileStr  = profile ? [
      profile.age   && (tr?`Yaş: ${profile.age}`:`Age: ${profile.age}`),
      profile.sex   && (tr?`Cinsiyet: ${profile.sex==="female"?"Kadın":"Erkek"}`:`Sex: ${profile.sex}`),
      profile.bmi   && `BMI: ${profile.bmi.toFixed(1)}`,
      profile.smoking    && (tr?"Sigara: Evet":"Smoking: Yes"),
      profile.diabetes   && (tr?"Diyabet: Evet":"Diabetes: Yes"),
      profile.hypertension && (tr?"Hipertansiyon: Evet":"Hypertension: Yes"),
      profile.familyHistory && (tr?"Aile Geçmişi: Evet":"Family History: Yes"),
    ].filter(Boolean).join("  ·  ") : "—";

    const diffsHTML = diffs.length>0 ? diffs.slice(0,6).map(d=>{
      const riskColor = d.risk==="critical"?"#c0392b":d.risk==="high"?"#d35400":d.risk==="moderate"?"#92400e":"#1a7a3c";
      return `<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #f0f0f0">
        <div style="flex:1">
          <span style="font-weight:600;color:#111;font-size:11px">${d.name}</span>
          ${d.source?`<span style="color:#aaa;font-size:10px;margin-left:6px">${d.source}</span>`:""}
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <div style="width:80px;height:4px;background:#eee;border-radius:4px;overflow:hidden">
            <div style="height:100%;width:${d.pct}%;background:${riskColor};border-radius:4px"></div>
          </div>
          <span style="font-size:11px;font-weight:600;color:${riskColor};min-width:32px;text-align:right">${d.pct}%</span>
          <span style="font-size:9px;color:#999;text-transform:uppercase;letter-spacing:0.05em;min-width:56px">${d.risk}</span>
        </div>
      </div>`;
    }).join("") : `<p style="color:#aaa;font-size:11px">${tr?"Mevcut değil":"Not available"}</p>`;

    const matchesHTML = matches.length>0 ? matches.slice(0,6).map(m=>`
      <div style="background:#fafafa;border:1px solid #eee;border-radius:8px;padding:10px 14px;margin-bottom:8px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
          <span style="font-weight:600;font-size:11px;color:#111">${m.name}</span>
          <span style="font-size:9px;color:#999">ICD ${m.icd}</span>
        </div>
        <div style="font-size:10px;color:#777;font-family:monospace">${m.triggerHits} hits · LR ${m.sprt_lr} · ×${m.profileMod.toFixed(1)}${m.confirmatoryMet?" · <b style='color:#1a7a3c'>CONF</b>":""}</div>
      </div>`).join("") : `<p style="color:#aaa;font-size:11px">${tr?"Mevcut değil":"Not available"}</p>`;

    const convoHTML = history.map(m=>{
      const isUser = m.role==="user";
      return `<div style="margin-bottom:12px">
        <div style="font-size:9px;font-weight:600;color:${isUser?"#1a7a3c":"#1F3864"};text-transform:uppercase;letter-spacing:0.06em;margin-bottom:3px">${isUser?(tr?"Hasta":"Patient"):"SHC"}</div>
        <div style="font-size:11px;color:#333;line-height:1.6;background:${isUser?"#f8fffe":"#f5f7ff"};border-radius:8px;padding:10px 12px;border-left:3px solid ${isUser?"#1a7a3c":"#1F3864"}">${m.content.replace(/\n/g,"<br>")}</div>
      </div>`;
    }).join("");

    const docSummaryHTML = docSummary ? `
      <div style="margin-top:24px">
        <h2 style="font-size:10px;font-weight:700;color:#999;text-transform:uppercase;letter-spacing:0.1em;margin:0 0 12px">${tr?"Yüklenen Belgeler":"Uploaded Documents"}</h2>
        <div style="background:#fffef0;border:1px solid #e8e0a0;border-radius:10px;padding:14px 16px;font-size:11px;color:#444;line-height:1.7;white-space:pre-wrap">${docSummary}</div>
      </div>` : "";

    const html = `<!DOCTYPE html><html lang="${lang}"><head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      <title>SHC Clinical Report — ${dateStr}</title>
      <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:-apple-system,BlinkMacSystemFont,'Helvetica Neue',Arial,sans-serif;background:#fff;color:#111;font-size:12px;line-height:1.5}
        @media print{body{padding:0}.no-print{display:none!important}@page{margin:20mm 18mm}}
      </style>
    </head><body style="padding:32px 36px;max-width:800px;margin:0 auto">

      <!-- HEADER -->
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:28px;padding-bottom:20px;border-bottom:2px solid #1F3864">
        <div>
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px">
            <div style="width:32px;height:32px;border-radius:8px;background:#1F3864;display:flex;align-items:center;justify-content:center">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            </div>
            <div>
              <div style="font-size:15px;font-weight:700;color:#1F3864;letter-spacing:-0.02em">SHC</div>
              <div style="font-size:10px;color:#888">Standard HealthCare</div>
            </div>
          </div>
        </div>
        <div style="text-align:right">
          <div style="font-size:10px;color:#888;text-transform:uppercase;letter-spacing:0.05em">${tr?"Rapor Tarihi":"Report Date"}</div>
          <div style="font-size:11px;font-weight:600;color:#333;margin-top:2px">${dateStr}</div>
          <div style="margin-top:8px;display:inline-block;padding:3px 10px;background:#fee2e2;border-radius:20px;font-size:9px;font-weight:700;color:#991b1b;letter-spacing:0.05em">${tr?"TANIM YERİNE GEÇMEZ":"NOT A DIAGNOSIS"}</div>
        </div>
      </div>

      <!-- PATIENT + TRIAGE ROW -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px">
        <div style="background:#f8f9fc;border-radius:10px;padding:16px">
          <div style="font-size:9px;font-weight:700;color:#999;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:8px">${tr?"Hasta Profili":"Patient Profile"}</div>
          <div style="font-size:11px;color:#333;line-height:1.8">${profileStr.split("  ·  ").map(s=>`<div>${s}</div>`).join("")}</div>
        </div>
        <div style="background:${routingBg};border:2px solid ${routingColor}22;border-radius:10px;padding:16px;text-align:center;display:flex;flex-direction:column;justify-content:center">
          <div style="font-size:9px;font-weight:700;color:#999;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:10px">${tr?"Triyaj Sonucu":"Triage Result"}</div>
          <div style="font-size:19px;font-weight:700;color:${routingColor};letter-spacing:-0.02em;line-height:1.2">${rl?.label||"—"}</div>
          ${urgency?`<div style="margin-top:8px;font-size:11px;color:${routingColor};background:${routingColor}11;border-radius:6px;padding:6px 10px">${urgency}</div>`:""}
          <div style="margin-top:10px;font-size:10px;color:#aaa;font-family:monospace">λ = ${lambda?.toFixed(3)||"—"}</div>
        </div>
      </div>

      ${doctorAlert?`
      <div style="margin-bottom:24px;background:#fff8f0;border:1px solid #f5a623;border-radius:10px;padding:14px 16px">
        <div style="font-size:9px;font-weight:700;color:#d97706;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:6px">${tr?"Doktor Notu":"Doctor Note"}</div>
        <div style="font-size:11px;color:#333;line-height:1.6">${doctorAlert}</div>
      </div>`:""}

      <!-- DIFFERENTIALS -->
      <div style="margin-bottom:24px">
        <h2 style="font-size:10px;font-weight:700;color:#999;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:12px">${tr?"Olası Tanılar":"Differential Diagnoses"}</h2>
        ${diffsHTML}
      </div>

      <!-- PATTERN ENGINE -->
      ${!offlineMode?`
      <div style="margin-bottom:24px">
        <h2 style="font-size:10px;font-weight:700;color:#999;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:12px">${tr?"Analiz Motoru — Pattern Eşleşmeleri":"Pattern Engine — Matches"}</h2>
        ${matchesHTML}
      </div>`:""}

      ${docSummaryHTML}

      <!-- FOOTER -->
      <div style="border-top:1px solid #eee;padding-top:16px;display:flex;justify-content:space-between;align-items:center">
        <div style="font-size:9px;color:#bbb">SHC · Standard HealthCare · ${dateStr}</div>
        <div style="font-size:9px;color:#bbb">${tr?"Bu rapor karar destek aracı çıktısıdır. Tanı yerine geçmez.":"This report is the output of a decision support tool. Not a clinical diagnosis."}</div>
      </div>

      <script>window.onload=()=>window.print();<\/script>
    </body></html>`;

    const w = window.open("","_blank","width=900,height=700");
    if (w) { w.document.write(html); w.document.close(); }
  }

  const SF = "-apple-system,BlinkMacSystemFont,'SF Pro Text','SF Pro Display','Helvetica Neue',sans-serif";

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100dvh",background:C.bg,fontFamily:SF,overflow:"hidden",fontSize:13,color:C.text,WebkitFontSmoothing:"antialiased"}}>

      <header style={{minHeight:52,borderBottom:`1px solid ${C.sep}`,display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 16px",paddingTop:"env(safe-area-inset-top)",boxSizing:"border-box",flexShrink:0,background:dark?"rgba(28,28,30,0.9)":"rgba(255,255,255,0.9)",backdropFilter:"blur(20px)",WebkitBackdropFilter:"blur(20px)"}}>
        <div style={{display:"flex",alignItems:"center",gap:8,minWidth:0,flex:1}}>
          <button onClick={()=>setDark(v=>!v)} style={{width:28,height:28,borderRadius:"50%",border:"none",background:"transparent",color:C.text3,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            {dark
              ? <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
              : <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>
            }
          </button>
          <div style={{width:26,height:26,borderRadius:6,background:C.dot,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={dark?"#1d1d1f":"white"} strokeWidth="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
          </div>
          <div style={{minWidth:0}}>
            <div style={{fontSize:11,fontWeight:600,color:C.text,letterSpacing:"-0.02em",whiteSpace:"nowrap"}}>SHC</div>
            <div style={{fontSize:8,color:C.text3,letterSpacing:"0.01em",whiteSpace:"nowrap"}}>Standard HealthCare</div>
          </div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:10,flexShrink:0}}>
          
          <button onClick={()=>setDoctorMode(v=>!v)} style={{display:"flex",alignItems:"center",gap:5,padding:"4px 10px",borderRadius:14,background:doctorMode?C.dot:"rgba(128,128,128,0.12)",border:"none",color:doctorMode?(dark?"#1d1d1f":"#ffffff"):C.text3,fontSize:10,fontWeight:500,cursor:"pointer",fontFamily:SF,transition:"all 0.2s",letterSpacing:"-0.01em"}}>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/></svg>
            {lang==="tr"?"Doktor":"Doctor"}
          </button>
          <CloseSessionButton lang={lang} onConfirm={doReset} dark={dark}/>
        </div>
      </header>

      <div style={{flex:1,display:"flex",overflow:"hidden"}}>

        <div style={{flex:1,display:doctorMode?"none":"flex",flexDirection:"column",overflow:"hidden",minWidth:0,background:C.bg}}>
          <div ref={scrollRef} style={{flex:1,overflowY:"auto",padding:offlineMode?"24px 0 calc(env(safe-area-inset-bottom) + 20px)":"24px 0 12px",display:"flex",flexDirection:"column",gap:2,userSelect:"none"}}
            onClick={e=>{
              if(uiPhase!=="profiling" && textareaRef.current && e.target===e.currentTarget){
                textareaRef.current.focus();
              }
            }}>
            {messages.map((msg,i)=>(
              <div key={i} style={{display:"flex",justifyContent:msg.role==="user"?"flex-end":"flex-start",padding:"3px 20px",alignItems:"flex-end",gap:8}}>
                {msg.role!=="user"&&(
                  <div style={{width:28,height:28,borderRadius:"50%",flexShrink:0,background:C.dot,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:2}}>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={dark?"#1d1d1f":"white"} strokeWidth="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                  </div>
                )}
                <div style={{
                  maxWidth:"68%",
                  background:msg.role==="user"?C.userBubble:C.shcBubble,
                  color:msg.role==="user"?C.userText:C.shcText,
                  borderRadius:msg.role==="user"?"18px 18px 4px 18px":"18px 18px 18px 4px",
                  padding:"11px 15px",
                  fontSize:13,
                  lineHeight:1.5,
                  letterSpacing:"-0.01em",
                  whiteSpace:"pre-wrap",
                  fontFamily:SF,
                }}>
                  {msg.text}
                </div>
              </div>
            ))}
            {uiPhase==="profiling" && !loading && (()=>{
              const q = t.questions[profileIdx];
              if (!q) return null;

              if (q.type === "choice") {
                return (
                  <div style={{padding:"4px 20px 4px 56px",display:"flex",gap:8,flexWrap:"wrap"}}>
                    {q.choices.map(choice=>(
                      <button key={choice} onClick={()=>{
                        addMsg(choice,"user");
                        handleProfileAnswer(choice);
                      }} style={{
                        padding:"10px 22px",borderRadius:20,
                        border:`1.5px solid ${C.btnBorder}`,
                        background:C.btnBg,color:C.text,
                        fontSize:13,fontWeight:400,cursor:"pointer",
                        fontFamily:SF,letterSpacing:"-0.01em",transition:"all 0.15s",
                      }}
                      onMouseEnter={e=>{e.currentTarget.style.background=dark?"#48484a":"#f5f5f7";e.currentTarget.style.color=C.text;}}
                      onMouseLeave={e=>{e.currentTarget.style.background=C.btnBg;e.currentTarget.style.color=C.text;}}>
                        {choice}
                      </button>
                    ))}
                  </div>
                );
              }

              if (q.type === "number") {
                const cfg = {
                  age:       {unit:lang==="tr"?"yaş":"yrs", hint:"18–120", min:18, max:120},
                  height_cm: {unit:"cm", hint:"140–220",    min:140, max:220},
                  weight_kg: {unit:"kg", hint:"40–200",     min:40,  max:200},
                }[q.key] || {unit:"", hint:"", min:0, max:999};
                const display = input || "";
                const numVal = parseInt(display, 10);
                const inRange = display.length > 0 && !isNaN(numVal) && numVal >= cfg.min && numVal <= cfg.max;
                const hasInput = display.length > 0;
                const tap = (k) => {
                  if (k==="⌫") { setInput(v=>v.slice(0,-1)); }
                  else if (k==="OK") {
                    if (!hasInput) return;
                    if (!inRange) {
                      const hint = lang==="tr"
                        ? `Lütfen geçerli bir değer girin (${cfg.min}–${cfg.max} ${cfg.unit}).`
                        : `Please enter a valid value (${cfg.min}–${cfg.max} ${cfg.unit}).`;
                      addMsg(hint);
                      setInput("");
                      return;
                    }
                    addMsg(display,"user"); handleProfileAnswer(display); setInput("");
                  }
                  else { if(input.length>=3) return; setInput(v=>v+k); }
                };
                const keys = ["1","2","3","4","5","6","7","8","9","⌫","0","OK"];
                return (
                  <div style={{padding:"6px 20px 6px 20px",display:"flex",gap:14,alignItems:"flex-start"}}>
                    <div style={{display:"flex",flexDirection:"column",justifyContent:"center",minWidth:58,paddingTop:4}}>
                      <div style={{fontSize:22,fontWeight:500,color:display?C.text:C.text3,fontFamily:SF,letterSpacing:"-0.02em",lineHeight:1}}>{display||"—"}</div>
                      <div style={{fontSize:10,color:C.text3,marginTop:3}}>{cfg.unit} · {cfg.hint}</div>
                    </div>
                    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:5}}>
                      {keys.map(k=>(
                        <button key={k} onClick={()=>tap(k)} style={{
                          width:44,height:36,borderRadius:9,border:"none",
                          background:k==="OK"?(inRange?C.dot:C.bg3):k==="⌫"?C.bg2:C.btnBg,
                          color:k==="OK"?(inRange?(dark?"#1d1d1f":"#ffffff"):C.text3):C.text,
                          fontSize:k==="⌫"?15:k==="OK"?12:17,
                          fontWeight:k==="OK"?500:400,
                          cursor:k==="OK"&&!inRange?"default":"pointer",
                          fontFamily:SF,
                          boxShadow:"0 1px 2px rgba(0,0,0,0.07)",
                          transition:"opacity 0.1s",
                        }}
                        onMouseEnter={e=>{if(k!=="OK"||valid)e.currentTarget.style.opacity="0.7";}}
                        onMouseLeave={e=>e.currentTarget.style.opacity="1"}>
                          {k}
                        </button>
                      ))}
                    </div>
                  </div>
                );
              }
              return null;
            })()}
            {/* ── AKİNATOR: KAPI SEÇİMİ ── */}
            {offlineMode && !akinatorGate && !akinatorDone && uiPhase!=="profiling" && !loading && (()=>{
              const gates = AKINATOR_GATES[lang] || AKINATOR_GATES.tr;
              return (
                <div style={{padding:"8px 20px 8px 20px"}}>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,maxWidth:380}}>
                    {gates.map(g=>(
                      <button key={g.id} onClick={()=>handleGateSelect(g.id)} style={{
                        display:"flex",flexDirection:"column",alignItems:"flex-start",
                        padding:"12px 14px",borderRadius:14,
                        border:`1.5px solid ${C.btnBorder}`,
                        background:C.btnBg,cursor:"pointer",fontFamily:SF,
                        textAlign:"left",transition:"all 0.15s",gap:4,
                      }}
                      onMouseEnter={e=>{e.currentTarget.style.background=dark?"#48484a":"#f0f0f2";e.currentTarget.style.borderColor=C.accent;}}
                      onMouseLeave={e=>{e.currentTarget.style.background=C.btnBg;e.currentTarget.style.borderColor=C.btnBorder;}}>
                        <span style={{fontSize:11,fontWeight:500,color:C.text,letterSpacing:"-0.01em",lineHeight:1.3}}>{g.label}</span>
                        <span style={{fontSize:10,color:C.text3,lineHeight:1.3}}>{g.sub}</span>
                      </button>
                    ))}
                  </div>
                </div>
              );
            })()}
            {/* ── AKİNATOR: CEVAP BUTONLARI ── */}
            {offlineMode && akinatorGate && akinatorCurrent && !akinatorDone && uiPhase!=="profiling" && !loading && (()=>{
              const q = akinatorCurrent;
              const totalQs = AKINATOR_QUESTIONS.filter(qq => qq.ask_if === akinatorGate).length;
              const doneQs = akinatorAsked.length;
              if (q.type === "yn") {
                const btns = [
                  { key:"yes", label:lang==="tr"?"✓ Evet":"✓ Yes", bg:dark?"#1a3a1a":"#f0fff4", color:"#166534", border:"rgba(22,101,52,0.3)" },
                  { key:"no",  label:lang==="tr"?"✗ Hayır":"✗ No", bg:dark?"#3a1a1a":"#fff5f5", color:"#c0392b", border:"rgba(192,57,43,0.3)" },
                ];
                return (
                  <div style={{padding:"6px 20px 6px 56px"}}>
                    <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:8}}>
                      {btns.map(b=>(
                        <button key={b.key} onClick={()=>handleAkinatorAnswer(b.key)} style={{
                          padding:"11px 18px",borderRadius:20,border:`1.5px solid ${b.border}`,
                          background:b.bg,color:b.color,fontSize:12,fontWeight:500,cursor:"pointer",
                          fontFamily:SF,letterSpacing:"-0.01em",transition:"all 0.15s",
                        }}
                        onMouseEnter={e=>e.currentTarget.style.opacity="0.8"}
                        onMouseLeave={e=>e.currentTarget.style.opacity="1"}>
                          {b.label}
                        </button>
                      ))}
                    </div>
                  </div>
                );
              }
              if (q.type === "scale") {
                return (
                  <div style={{padding:"6px 20px 10px 56px"}}>
                    <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
                      <span style={{fontSize:10,color:C.text3,minWidth:12}}>1</span>
                      <input type="range" min="1" max="10" value={akinatorScale}
                        onChange={e=>setAkinatorScale(Number(e.target.value))}
                        style={{flex:1,accentColor:C.accent,cursor:"pointer"}}/>
                      <span style={{fontSize:10,color:C.text3,minWidth:16}}>10</span>
                      <div style={{
                        minWidth:38,height:38,borderRadius:"50%",flexShrink:0,
                        background:akinatorScale>=8?"#c0392b":akinatorScale>=5?"#a0522d":"#1a7a3c",
                        display:"flex",alignItems:"center",justifyContent:"center",
                        color:"white",fontSize:13,fontWeight:600,fontFamily:SF,
                        transition:"background 0.2s",
                      }}>
                        {akinatorScale}
                      </div>
                    </div>
                    <div style={{display:"flex",alignItems:"center",gap:8}}>
                      <button onClick={()=>handleAkinatorAnswer("scale", akinatorScale)} style={{
                        padding:"10px 24px",borderRadius:20,border:"none",flexShrink:0,
                        background:C.dot,color:dark?"#1d1d1f":"white",
                        fontSize:12,fontWeight:500,cursor:"pointer",fontFamily:SF,letterSpacing:"-0.01em",
                      }}>
                        {lang==="tr"?"Onayla":"Confirm"} — {akinatorScale}/10
                      </button>
                    </div>
                  </div>
                );
              }
              return null;
            })()}
            {loading&&(
              <div style={{display:"flex",padding:"3px 20px",alignItems:"flex-end",gap:8}}>
                <div style={{width:28,height:28,borderRadius:"50%",background:C.dot,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:2}}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={dark?"#1d1d1f":"white"} strokeWidth="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                </div>
                <div style={{background:C.shcBubble,borderRadius:"18px 18px 18px 4px",padding:"14px 18px",display:"flex",gap:4,alignItems:"center"}}>
                  {[0,1,2].map(j=><div key={j} style={{width:6,height:6,borderRadius:"50%",background:C.text3,animation:`dotBounce 1.2s ${j*0.2}s infinite`}}/>)}
                </div>
              </div>
            )}
            <div ref={bottomRef}/>
          </div>

          {(uiPhase!=="profiling" || !t.questions[profileIdx] || (t.questions[profileIdx].type!=="choice" && t.questions[profileIdx].type!=="number")) && !offlineMode && (
          <div style={{paddingTop:8,paddingLeft:16,paddingRight:16,paddingBottom:"max(12px, calc(env(safe-area-inset-bottom) - 6px))",background:C.surface,borderTop:`1px solid ${C.sep}`,flexShrink:0}}>
            <div style={{display:"flex",gap:8,alignItems:"flex-end",background:C.bg2,borderRadius:22,padding:"8px 8px 8px 16px",transition:"background 0.15s"}}
              onFocusCapture={e=>e.currentTarget.style.background=dark?"#48484a":"#efefef"}
              onBlurCapture={e=>e.currentTarget.style.background=C.bg2}>
              {!offlineMode && (uiPhase==="doc_upload" || uiPhase==="symptoms") && (
                <>
                  <input ref={chatFileRef} type="file" accept=".pdf,.txt,.text,text/plain,application/pdf" style={{display:"none"}} onChange={e=>{const f=e.target.files?.[0]; e.target.value=""; if(f) handleFileUpload(f,"chat");}}/>
                  <button onClick={()=>chatFileRef.current?.click()} disabled={loading} title={lang==="tr"?"Belge yükle":"Upload document"} style={{width:30,height:30,borderRadius:"50%",border:`1px solid ${C.sep}`,flexShrink:0,background:"transparent",color:C.text3,cursor:loading?"default":"pointer",display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.15s"}}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                  </button>
                </>
              )}
              <textarea ref={textareaRef} value={input}
                onChange={e=>{setInput(e.target.value);e.target.style.height="auto";e.target.style.height=Math.min(e.target.scrollHeight,100)+"px";}}
                onKeyDown={handleKey}
                placeholder={t.placeholder_symptom}
                rows={1}
                style={{flex:1,background:"transparent",border:"none",outline:"none",fontFamily:SF,fontSize:14,color:C.text,resize:"none",minHeight:26,maxHeight:100,lineHeight:1.45,padding:"1px 0",letterSpacing:"-0.01em",caretColor:C.accent}}/>
              {!offlineMode && (window.SpeechRecognition||window.webkitSpeechRecognition) && (
                <button onClick={toggleListen} disabled={loading} title={lang==="tr"?"Sesli giriş":"Voice input"} style={{width:30,height:30,borderRadius:"50%",border:"none",flexShrink:0,background:isListening?C.accent:"transparent",color:isListening?"white":C.text3,cursor:loading?"default":"pointer",display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.15s"}}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="2" width="6" height="11" rx="3"/><path d="M19 10a7 7 0 01-14 0"/><line x1="12" y1="19" x2="12" y2="22"/><line x1="8" y1="22" x2="16" y2="22"/></svg>
                </button>
              )}
              <button onClick={send} disabled={loading||!input.trim()} style={{
                width:30,height:30,borderRadius:"50%",border:"none",flexShrink:0,
                background:loading||!input.trim()?"transparent":C.accent,
                cursor:loading||!input.trim()?"default":"pointer",
                display:"flex",alignItems:"center",justifyContent:"center",
                transition:"all 0.15s",
                opacity:loading||!input.trim()?0:1,
              }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" strokeLinecap="round" strokeLinejoin="round"><path d="M12 19V5M5 12l7-7 7 7" stroke="white" strokeWidth="2"/></svg>
              </button>
            </div>
            {uiPhase!=="profiling"&&followUpHistory.length===0&&<div style={{fontSize:10,color:C.text3,marginTop:6,paddingLeft:6,letterSpacing:"-0.01em"}}>{t.hint}</div>}
          </div>
          )}
        </div>

        {doctorMode&&(
          <div style={{flex:1,width:"100%",maxWidth:900,margin:"0 auto",background:C.bg2,display:"flex",flexDirection:"column",overflow:"hidden",fontSize:11}}>
            <div style={{display:"flex",background:C.surface,borderBottom:`1px solid ${C.sep}`,flexShrink:0}}>
              {[{id:"result",label:t.tabResult},{id:"diff",label:t.tabDiff},...(!offlineMode?[{id:"system",label:t.tabEngine}]:[])].map(tab=>(
                <button key={tab.id} onClick={()=>setPanelTab(tab.id)} style={{flex:1,padding:"10px 0",fontSize:10,fontWeight:500,letterSpacing:"-0.01em",border:"none",cursor:"pointer",background:"transparent",color:panelTab===tab.id?C.accent:C.text3,borderBottom:panelTab===tab.id?`1.5px solid ${C.accent}`:"1.5px solid transparent",transition:"all 0.15s",fontFamily:SF}}>{tab.label}</button>
              ))}
            </div>
            <div style={{flex:1,overflowY:"auto",padding:"16px 14px"}}>

              {panelTab==="result"&&<>
                {profile&&(
                  <div style={{marginBottom:16}}>
                    <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:8,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.patientLabel}</div>
                    <div style={{display:"flex",flexWrap:"wrap",gap:4}}>
                      {[profile.age&&`${profile.age}y`,profile.sex&&(profile.sex==="female"?(lang==="tr"?"K":"F"):(lang==="tr"?"E":"M")),profile.bmi&&`BMI ${profile.bmi.toFixed(0)}`,profile.smoking&&(lang==="tr"?"Sigara":"Smoker"),profile.diabetes&&"DM",profile.hypertension&&"HTN",profile.familyHistory&&"FHx"].filter(Boolean).map(chip=>(
                        <span key={chip} style={{background:C.bg2,borderRadius:5,padding:"2px 8px",fontSize:10,color:C.text,fontWeight:400,border:`1px solid ${C.sep}`}}>{chip}</span>
                      ))}
                    </div>
                  </div>
                )}

                <div style={{marginBottom:16}}>
                  <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:8,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.triageLabel}</div>
                  {!routing?(
                    <div style={{border:`1px solid ${C.sep}`,borderRadius:12,padding:"20px 14px",textAlign:"center",background:C.bg2}}>
                      <div style={{fontSize:11,color:C.text3,lineHeight:1.5}}>{t.awaiting}</div>
                    </div>
                  ):(
                    <div style={{border:`1px solid ${ar.border}`,borderRadius:12,background:ar.bg,padding:"16px 14px",textAlign:"center"}}>
                      <div style={{width:8,height:8,borderRadius:"50%",background:ar.dot,margin:"0 auto 10px",boxShadow:`0 0 0 3px ${ar.border}`}}/>
                      <div style={{fontSize:12,fontWeight:600,color:ar.color,lineHeight:1.3,marginBottom:4,letterSpacing:"-0.02em"}}>{rl.label}</div>
                      {lambda&&<div style={{fontSize:9,color:C.text3,marginTop:8,fontFamily:"'SF Mono','Menlo',monospace"}}>λ = {lambda.toFixed(3)}</div>}
                    </div>
                  )}
                  {routing&&(()=>{
                    // Karar özeti QR'ı — hasta doktoruna gösterir / ekran fotosu / indirir. Tüm veri kodun içinde.
                    const reason = (() => {
                      const top = diffs && diffs[0];
                      if (routing==="RED") return lang==="tr"?"Acil bulgu / kritik ayırıcı dışlanamadı":"Emergent finding / critical differential not excluded";
                      if (routing==="GREY") return lang==="tr"?"Örüntü belirsiz — değerlendirme gerekli":"Pattern unclear — evaluation needed";
                      return top ? (lang==="tr"?`Olası: ${top.name}`:`Likely: ${top.name}`) : (lang==="tr"?"Örüntü değerlendirildi":"Pattern assessed");
                    })();
                    const sxList = symptomText
                      ? symptomText.toLowerCase().split(/[\s,.;]+/).filter(Boolean).slice(0,10)
                      : (diffs&&diffs[0]?[diffs[0].name]:[]);
                    const payload = buildQRPayload(routing, sxList, lambda, reason, lang, doctorAlert, diffs, sprtViz);
                    let mat; try { mat = qrMatrix(payload); } catch(e){ return null; }
                    const N = mat.length, quiet = 4, dim = N + quiet*2, px = 8;
                    const W = dim*px;
                    const darkPath = mat.flatMap((row,r)=>row.map((v,c)=>v?`M${(c+quiet)*px} ${(r+quiet)*px}h${px}v${px}h-${px}z`:"")).filter(Boolean).join("");
                    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${W}" viewBox="0 0 ${W} ${W}"><rect width="${W}" height="${W}" fill="#fff"/><path d="${darkPath}" fill="#000"/></svg>`;
                    const dataUrl = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(svg)));
                    return (
                      <div style={{marginTop:10,padding:"12px",borderRadius:12,border:`1px solid ${C.sep}`,background:C.bg2,textAlign:"center"}}>
                        <div style={{fontSize:11,fontWeight:600,color:C.text,marginBottom:10,letterSpacing:"-0.01em"}}>{t.qrLabel}</div>
                        <div style={{display:"inline-block",padding:12,background:"#fff",borderRadius:14,boxShadow:dark?"0 2px 12px rgba(0,0,0,0.4)":"0 1px 4px rgba(0,0,0,0.08)"}}>
                          <img src={dataUrl} alt="QR" style={{display:"block",width:"min(82vw, 340px)",height:"auto",imageRendering:"pixelated"}}/>
                        </div>
                      </div>
                    );
                  })()}
                  {routing&&!offlineMode&&(
                    <button onClick={exportPDF} style={{marginTop:8,width:"100%",padding:"9px 0",borderRadius:8,border:`1px solid ${C.sep}`,background:C.bg2,color:C.text3,cursor:"pointer",fontFamily:"inherit",fontSize:11,fontWeight:500,display:"flex",alignItems:"center",justifyContent:"center",gap:6,transition:"all 0.2s",letterSpacing:"-0.01em"}}>
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/></svg>
                      {lang==="tr"?"PDF Raporu İndir":"Download PDF Report"}
                    </button>
                  )}
                </div>

                <div style={{marginBottom:16}}>
                  <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:8,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.sprtLabel}</div>
                  <div style={{display:"flex",justifyContent:"space-between",fontSize:9,marginBottom:5,color:C.text3}}><span style={{color:C.text3}}>{t.safe}</span><span style={{color:C.text3}}>{t.critical}</span></div>
                  <div style={{height:4,borderRadius:4,position:"relative",overflow:"visible",background:"linear-gradient(to right,rgba(26,122,60,0.25),rgba(160,82,45,0.2),rgba(192,57,43,0.3))",border:`1px solid ${C.sep}`}}>
                    {needlePct!==null&&<div style={{position:"absolute",top:"50%",transform:"translate(-50%,-50%)",left:needlePct+"%",width:3,height:14,borderRadius:2,background:needleColor,transition:"left 0.9s cubic-bezier(0.34,1.56,0.64,1)"}}/>}
                  </div>
                  <div style={{textAlign:"center",fontFamily:"'SF Mono','Menlo',monospace",fontSize:9,color:C.text3,marginTop:5}}>{lambda?`λ = ${lambda.toFixed(3)}`:"—"}</div>
                  {sprtViz?.traj?.length > 1 && (() => {
                    const A = sprtViz.A, B = sprtViz.B, pts = sprtViz.traj;
                    const W = 260, H = 92, PAD = 8;
                    const yOf = s => { const c = Math.max(-4.2, Math.min(4.2, s)); return H/2 - (c/4.2)*(H/2 - PAD); };
                    const xOf = idx => PAD + (idx/(Math.max(pts.length-1,1)))*(W-2*PAD);
                    const dPath = pts.map((p,idx)=>`${idx===0?"M":"L"}${xOf(idx).toFixed(1)},${yOf(p.S).toFixed(1)}`).join(" ");
                    return (
                      <div style={{marginTop:10}}>
                        <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{display:"block",background:C.bg2,border:`1px solid ${C.sep}`,borderRadius:8}}>
                          <line x1={PAD} x2={W-PAD} y1={yOf(B)} y2={yOf(B)} stroke="#c0392b" strokeWidth="1" strokeDasharray="4 3" opacity="0.7"/>
                          <line x1={PAD} x2={W-PAD} y1={yOf(A)} y2={yOf(A)} stroke="#1a7a3c" strokeWidth="1" strokeDasharray="4 3" opacity="0.7"/>
                          <line x1={PAD} x2={W-PAD} y1={yOf(0)} y2={yOf(0)} stroke={C.text3} strokeWidth="0.5" opacity="0.25"/>
                          <path d={dPath} fill="none" stroke={needleColor} strokeWidth="1.8" strokeLinejoin="round" strokeLinecap="round"/>
                          {pts.map((p,idx)=>(<circle key={idx} cx={xOf(idx)} cy={yOf(p.S)} r="2" fill={needleColor}/>))}
                          <text x={W-PAD} y={yOf(B)-3} textAnchor="end" fontSize="7" fill="#c0392b" fontFamily="monospace">b=+{B.toFixed(2)}</text>
                          <text x={W-PAD} y={yOf(A)+9} textAnchor="end" fontSize="7" fill="#1a7a3c" fontFamily="monospace">a={A.toFixed(2)}</text>
                        </svg>
                        <div style={{textAlign:"center",fontFamily:"'SF Mono','Menlo',monospace",fontSize:9,color:C.text3,marginTop:5}}>
                          Sₙ — {sprtViz.topKey} · S = {sprtViz.S.toFixed(2)}{sprtViz.abstained ? (lang==="tr"?" · ÇEKİMSER":" · ABSTAIN") : ""}
                        </div>
                      </div>
                    );
                  })()}
                </div>

                {doctorAlert&&(
                  <div style={{marginBottom:16}}>
                    <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:8,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.alertLabel}</div>
                    <div style={{background:C.bg2,border:`1px solid ${C.sep}`,borderRadius:10,padding:"10px 12px",fontSize:11,color:C.text,lineHeight:1.6,borderLeft:`3px solid ${C.sep}`}}>
                      {doctorAlert}
                    </div>
                  </div>
                )}

                <div>
                  <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:8,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.uncertaintyLabel}</div>
                  {t.uFlags.map(({k,label})=>{
                    const on=!!abstention[k];
                    return(
                      <div key={k} style={{display:"flex",alignItems:"center",gap:8,padding:"6px 0",borderBottom:`1px solid ${C.sep}`}}>
                        <div style={{width:5,height:5,borderRadius:"50%",flexShrink:0,background:on?C.text:"rgba(128,128,128,0.2)"}}/>
                        <div style={{fontSize:11,color:on?C.text:C.text3,flex:1,letterSpacing:"-0.01em"}}>{label}</div>
                        {on&&<div style={{fontSize:9,color:C.text3,fontWeight:500}}>{lang==="tr"?"aktif":"active"}</div>}
                      </div>
                    );
                  })}
                </div>
              </>}

              {panelTab==="diff"&&<>
                <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:14,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.diffLabel}</div>
                {diffs.length===0?(
                  <div style={{fontSize:11,color:C.text3,textAlign:"center",padding:"32px 0",lineHeight:1.6,whiteSpace:"pre-line"}}>{t.diffEmpty}</div>
                ):diffs.slice(0,6).map((d,i)=>{
                  return(
                    <div key={i} style={{marginBottom:16,paddingBottom:16,borderBottom:`1px solid ${C.sep}`}}>
                      <div style={{display:"flex",justifyContent:"space-between",alignItems:"baseline",marginBottom:6}}>
                        <div style={{fontSize:11,fontWeight:500,color:C.text,letterSpacing:"-0.01em"}}>{d.name}</div>
                        <div style={{fontSize:11,fontWeight:500,color:C.text,fontFamily:"'SF Mono','Menlo',monospace"}}>{d.pct}%</div>
                      </div>
                      <div style={{height:2,background:C.sep,borderRadius:2,overflow:"hidden"}}>
                        <div style={{height:"100%",width:d.pct+"%",background:C.text,borderRadius:2,transition:"width 0.9s ease"}}/>
                      </div>
                      <div style={{display:"flex",justifyContent:"space-between",marginTop:5}}><span style={{fontSize:9,color:C.text3,textTransform:"capitalize"}}>{d.risk}</span>{d.source&&<span style={{fontSize:8,color:C.text3,opacity:0.7}}>{d.source}</span>}</div>
                    </div>
                  );
                })}
              </>}

              {panelTab==="system"&&<>
                <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:14,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.engineLabel}</div>
                {matches.length===0?(
                  <div style={{fontSize:11,color:C.text3,textAlign:"center",padding:"32px 0",lineHeight:1.6,whiteSpace:"pre-line"}}>{t.engineEmpty}</div>
                ):matches.slice(0,5).map((m,i)=>(
                  <div key={i} style={{marginBottom:10,padding:"10px 12px",background:C.bg2,border:`1px solid ${C.sep}`,borderRadius:10}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:3}}>
                      <div style={{fontSize:11,fontWeight:500,color:C.text,letterSpacing:"-0.01em"}}>{m.name}</div>
                      {m.confirmatoryMet&&<span style={{fontSize:8,color:C.text3,fontWeight:500,letterSpacing:"0.02em"}}>CONF</span>}
                    </div>
                    <div style={{fontSize:9,color:C.text3,fontFamily:"'SF Mono','Menlo',monospace"}}>{m.triggerHits} hits · LR {m.sprt_lr} · ×{m.profileMod.toFixed(1)}</div>
                    <div style={{fontSize:9,color:C.text3,marginTop:2}}>ICD {m.icd}</div>
                  </div>
                ))}
                <div style={{marginTop:12,padding:"10px 12px",background:C.bg2,borderRadius:10,border:`1px solid ${C.sep}`}}>
                  <div style={{fontSize:9,fontWeight:500,color:C.text3,marginBottom:5,textTransform:"uppercase",letterSpacing:"0.06em"}}>{t.sourcesLabel}</div>
                  <div style={{fontSize:10,color:C.text3,lineHeight:1.8,letterSpacing:"-0.01em"}}>ADA 2025 · AHA/ACC · EULAR/ACR<br/>GINA · GOLD · MDS · NICE NG240<br/>USPSTF · WHO · ESC · IDSA</div>
                </div>
              </>}
            </div>
          </div>
        )}
      </div>

      <style>{`
        :root{--ph:${C.placeholder}}
        textarea::placeholder{color:var(--ph)!important}
        @keyframes dotBounce{0%,80%,100%{transform:translateY(0);opacity:0.3}40%{transform:translateY(-4px);opacity:1}}
        *{box-sizing:border-box;-webkit-tap-highlight-color:transparent;outline:none}
        button{outline:none!important;-webkit-appearance:none}
        button:focus,button:focus-visible,button:focus-within{outline:none!important;box-shadow:none!important}
        textarea:focus{outline:none}
        html{touch-action:manipulation}
        input,textarea,select{font-size:14px!important}
        ::-webkit-scrollbar{width:0}
      `}</style>
    </div>
  );
}
