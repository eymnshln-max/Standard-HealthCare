# Standard Health — Gemini Native

Original SHC triage/SPRT flow with Gemini-native backend proxy.

Local:

```bash
npm install
cp .env.example .env
npm run build
npm start
```

Render uses the commands in `README_DEPLOY.md`.
