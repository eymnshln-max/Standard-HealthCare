# Render deployment

Build Command:

```bash
rm -rf shc-triage-modular && unzip -q -o shc-triage-gemini-native-clean.zip && cd shc-triage-modular && corepack enable && corepack prepare pnpm@9.15.4 --activate && pnpm install --no-frozen-lockfile && pnpm run build
```

Start Command:

```bash
cd shc-triage-modular && ./node_modules/.bin/tsx server/src/index.ts
```

Environment variables:

```env
GEMINI_API_KEY=...
GEMINI_MODEL=gemini-2.5-flash
NODE_VERSION=22.12.0
NODE_ENV=production
```
