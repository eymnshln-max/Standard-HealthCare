import { Router } from "express";
import { ai } from "../services/geminiClient";

type GeminiContent = {
  role?: "user" | "model";
  parts?: Array<Record<string, unknown>>;
};

const RETRYABLE_STATUS = new Set([429, 500, 502, 503, 504]);

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function extractStatus(error: unknown): number | undefined {
  const anyErr = error as any;
  return anyErr?.status || anyErr?.code || anyErr?.response?.status;
}

function extractMessage(error: unknown): string {
  const anyErr = error as any;
  return String(anyErr?.message || anyErr?.error?.message || anyErr || "Gemini request failed");
}

function getText(response: any): string {
  if (typeof response?.text === "string") return response.text;
  const parts = response?.candidates?.[0]?.content?.parts || [];
  return parts.map((p: any) => p?.text || "").join("");
}

function normalizeContents(contents: GeminiContent[]) {
  return (contents || [])
    .filter((c) => Array.isArray(c.parts) && c.parts.length > 0)
    .map((c) => ({
      role: c.role === "model" ? "model" : "user",
      parts: c.parts,
    }));
}

async function generateWithRetry(params: any, attempts = 3) {
  let lastError: unknown;

  for (let i = 0; i < attempts; i += 1) {
    try {
      return await ai.models.generateContent(params);
    } catch (error) {
      lastError = error;
      const status = extractStatus(error);
      const message = extractMessage(error).toLowerCase();
      const retryable =
        (status && RETRYABLE_STATUS.has(Number(status))) ||
        message.includes("overload") ||
        message.includes("temporar") ||
        message.includes("timeout") ||
        message.includes("rate") ||
        message.includes("resource_exhausted");

      if (!retryable || i === attempts - 1) break;
      await sleep(1000 * (i + 1) * (status === 429 ? 3 : 2));
    }
  }

  throw lastError;
}

export const geminiRouter = Router();

geminiRouter.post("/generate", async (req, res) => {
  try {
    const {
      system,
      contents,
      maxOutputTokens = 1200,
      temperature = 0.25,
      wantsJson = false,
    } = req.body || {};

    if (!Array.isArray(contents) || contents.length === 0) {
      return res.status(400).json({ error: "contents array is required" });
    }

    const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";

    const response = await generateWithRetry({
      model,
      contents: normalizeContents(contents),
      config: {
        systemInstruction: system || undefined,
        temperature,
        maxOutputTokens,
        responseMimeType: wantsJson ? "application/json" : undefined,
      },
    });

    res.json({
      text: getText(response),
      finishReason: response?.candidates?.[0]?.finishReason,
      usageMetadata: response?.usageMetadata || null,
      model,
    });
  } catch (error) {
    const status = extractStatus(error);
    const message = extractMessage(error);
    console.error("Gemini API error:", status || "", message);
    res.status(status && Number(status) >= 400 && Number(status) < 600 ? Number(status) : 500).json({
      error: message,
    });
  }
});
